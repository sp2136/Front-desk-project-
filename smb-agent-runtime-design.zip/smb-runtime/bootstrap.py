#!/usr/bin/env python3
"""One-command setup. Standard library only -- runs on any Python 3.

    python3 bootstrap.py

Why this exists: `pytest` not being found after `pip install` is almost never
a problem with the project. It is one of three things, and all three are
invisible from the error message:

  1. zsh expands square brackets, so an unquoted `pip install -e .[dev]`
     fails with "no matches found" and installs nothing.
  2. The virtualenv is not active, so `pip` and `python3` are different
     interpreters and the package landed somewhere the shell cannot see.
  3. Python is older than 3.12 and the install was refused outright.

This script sidesteps all of it by calling the virtualenv's interpreter by its
full path and never relying on PATH or on shell quoting.
"""
from __future__ import annotations

import pathlib
import platform
import subprocess
import sys
import venv

ROOT = pathlib.Path(__file__).resolve().parent
VENV = ROOT / ".venv"
MIN_PYTHON = (3, 12)


def say(msg: str = "") -> None:
    print(msg, flush=True)


def venv_python() -> pathlib.Path:
    if platform.system() == "Windows":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def run(args: list[str], label: str) -> bool:
    say(f"  $ {' '.join(str(a) for a in args)}")
    result = subprocess.run(args, cwd=ROOT)
    if result.returncode != 0:
        say(f"\n  FAILED: {label} (exit {result.returncode})")
        return False
    return True


def check_python() -> bool:
    v = sys.version_info
    say(f"  interpreter: {sys.executable}")
    say(f"  version:     {v.major}.{v.minor}.{v.micro}")
    if (v.major, v.minor) < MIN_PYTHON:
        say()
        say(f"  This project needs Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or newer.")
        say("  It uses StrEnum and modern type syntax, so an older interpreter")
        say("  cannot import it at all -- this is not something to work around.")
        say()
        if platform.system() == "Darwin":
            say("  macOS ships an older Python. Install a current one:")
            say("    brew install python@3.13")
            say("  then run this script with it explicitly:")
            say("    /opt/homebrew/bin/python3.13 bootstrap.py")
        elif platform.system() == "Windows":
            say("  Install from https://www.python.org/downloads/ (tick")
            say('  "Add Python to PATH"), then: py -3.13 bootstrap.py')
        else:
            say("  Install a current Python, e.g.:")
            say("    sudo apt install python3.13 python3.13-venv")
            say("    python3.13 bootstrap.py")
        return False
    return True


def main() -> int:
    say("=" * 70)
    say("  SMB Agent Runtime -- setup")
    say("=" * 70)
    say()
    say("1. Checking Python")
    if not check_python():
        return 1
    say("  ok")
    say()

    say("2. Creating the virtual environment")
    if venv_python().exists():
        say(f"  already present at {VENV}")
    else:
        try:
            venv.EnvBuilder(with_pip=True, clear=False).create(VENV)
        except Exception as exc:  # noqa: BLE001
            say(f"  FAILED to create a venv: {exc}")
            if platform.system() == "Linux":
                say("  On Debian/Ubuntu this usually means the venv module is")
                say("  packaged separately: sudo apt install python3-venv")
            return 1
        say(f"  created {VENV}")
    py = venv_python()
    say()

    say("3. Installing dependencies (this takes a minute)")
    # Quoting is irrelevant here: these are argv entries, not a shell string,
    # which is the whole reason the zsh bracket problem cannot recur.
    if not run([str(py), "-m", "pip", "install", "--quiet", "--upgrade", "pip"],
               "upgrading pip"):
        return 1
    if not run([str(py), "-m", "pip", "install", "--quiet", "-e", ".[dev]"],
               "installing the project"):
        return 1
    say("  ok")
    say()

    say("4. Running the test suite")
    if not run([str(py), "-m", "pytest", "-q"], "tests"):
        say()
        say("  The install worked but tests failed. Paste the output above.")
        return 1
    say()

    activate = (".venv\\Scripts\\activate" if platform.system() == "Windows"
                else "source .venv/bin/activate")
    say("=" * 70)
    say("  Setup complete.")
    say("=" * 70)
    say()
    say("  Try these first -- neither needs an API key:")
    say(f"    {py} scripts/demo.py          # the runtime, end to end")
    say(f"    {py} scripts/eval_demo.py     # the section 11 and 2.4 gates")
    say()
    say("  To run the live server and worker, in two terminals:")
    say(f"    {activate}")
    say("    uvicorn app.main:app --port 8000")
    say(f"    {activate}")
    say("    python -m app.workers.runner")
    say()
    say("  Note: using the full interpreter path above works whether or not")
    say("  the venv is active. If `pytest` alone says 'command not found',")
    say("  the venv simply is not active -- that is all it ever means.")
    say()
    return 0


if __name__ == "__main__":
    sys.exit(main())
