-- Postgres row-level security. Control 2 of the two in app/db.py.
--
-- Apply after create_all. The application connects as smb_app, which is NOT
-- the table owner and has no BYPASSRLS, so these policies are not advisory.
-- Every policy keys on the same current_setting('app.tenant_id') that
-- TenantScope sets per job.

CREATE ROLE smb_app LOGIN;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'inbound_events','jobs','agent_runs','tool_calls','decisions',
    'outbound_messages','usage_counters','audit_log','rate_limit_buckets'
  ] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format(
      'CREATE POLICY tenant_isolation ON %I USING (tenant_id = current_setting(''app.tenant_id'', true))
       WITH CHECK (tenant_id = current_setting(''app.tenant_id'', true))', t);
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON %I TO smb_app', t);
  END LOOP;
END $$;

-- The audit log is append-only. No UPDATE, no DELETE, for anyone using the app role.
REVOKE UPDATE ON audit_log FROM smb_app;

-- Prompts are global by design (section 0: no prompt is edited per client).
GRANT SELECT ON prompts TO smb_app;
GRANT SELECT ON tenants TO smb_app;
