"""Customer-confirmed booking: no staff click, and still no agent write."""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from app.models import Offer, Reminder, Resource, Slot
from app.runtime import confirm
from app.runtime.booking import acquire_soft_lock

NOW = datetime.now(UTC).replace(microsecond=0)


@pytest.fixture
def offered(scope, session):
    scope.add(Resource(id="r1", name="Dr Shah", skills=["svc_cleaning"]))
    scope.add(Resource(id="r2", name="Dr Mehta", skills=["svc_cleaning"]))
    opts = []
    # Distinct days AND distinct hours: three options sharing an hour is the
    # ambiguity the matcher is now required to refuse, tested separately below.
    for i, (res, hours) in enumerate([("r1", 26), ("r2", 53), ("r1", 80)], start=1):
        starts = (NOW + timedelta(hours=hours)).replace(minute=0)
        scope.add(Slot(id=f"s{i}", resource_id=res, service_id=None,
                       starts_at=starts, duration_min=45))
        opts.append({"slot_id": f"s{i}", "starts_at": starts.isoformat(),
                     "resource_id": res, "resource_name": res,
                     "duration_minutes": 45})
    session.commit()
    confirm.record_offer(scope, customer_ref="+9199", options=opts,
                         service_id="svc_cleaning", now=NOW)
    session.commit()
    return opts


def test_an_ordinal_reply_books_without_any_staff_action(scope, session, offered):
    booking, match = confirm.try_confirm(scope, customer_ref="+9199", body="2", now=NOW)
    session.commit()
    assert booking is not None and match.matched
    assert booking.slot_id == "s2"
    assert booking.state == "confirmed"
    # And the reminders are already scheduled.
    assert {r.stage for r in scope.all(Reminder)} == {"T-24h", "T-2h"}


@pytest.mark.parametrize("reply", ["1", "first", "biju", "3", "teesra"])
def test_ordinals_in_several_languages(scope, session, offered, reply):
    booking, match = confirm.try_confirm(scope, customer_ref="+9199", body=reply, now=NOW)
    assert booking is not None, match.reason


def test_a_clock_time_matches_the_option_it_names(scope, session, offered):
    target = offered[1]
    hour = datetime.fromisoformat(target["starts_at"]).hour
    minute = datetime.fromisoformat(target["starts_at"]).minute
    booking, match = confirm.try_confirm(
        scope, customer_ref="+9199", body=f"{hour}:{minute:02d} works", now=NOW)
    session.commit()
    assert booking is not None and booking.slot_id == target["slot_id"]


def test_a_bare_yes_is_ambiguous_when_several_options_were_offered(scope, session, offered):
    """Booking a stranger into the wrong slot is worse than asking again."""
    booking, match = confirm.try_confirm(scope, customer_ref="+9199", body="yes", now=NOW)
    assert booking is None and not match.matched
    assert "several options" in match.reason


def test_a_bare_yes_is_enough_when_only_one_option_was_offered(scope, session, offered):
    only = [offered[0]]
    confirm.record_offer(scope, customer_ref="+9199", options=only,
                         service_id="svc_cleaning", now=NOW)
    session.commit()
    booking, match = confirm.try_confirm(scope, customer_ref="+9199", body="ha", now=NOW)
    assert booking is not None


@pytest.mark.parametrize("reply", ["maybe thursday?", "either is fine",
                                   "what about next month", "4",
                                   "thursday or friday", "might be able to do friday"])
def test_ambiguity_falls_through_to_the_agent_chain(scope, session, offered, reply):
    booking, match = confirm.try_confirm(scope, customer_ref="+9199", body=reply, now=NOW)
    assert booking is None and not match.matched


def test_options_sharing_a_clock_time_are_not_distinguished_by_it(scope, session):
    """Three slots at 10:00 on three days are not told apart by "10:00", and
    first-wins there books whichever happened to be listed first."""
    same = [
        {"slot_id": f"x{i}", "resource_id": "r1", "resource_name": "r1",
         "duration_minutes": 45,
         "starts_at": (NOW + timedelta(days=i)).replace(hour=10, minute=0).isoformat()}
        for i in (1, 2, 3)
    ]
    offer = confirm.record_offer(scope, customer_ref="+9188", options=same, now=NOW)
    session.commit()
    match = confirm.match_reply(offer, "10:00")
    assert not match.matched and "share that time" in match.reason


def test_losing_the_race_returns_no_booking_rather_than_an_error(scope, session, offered):
    """Somebody else took the slot between the offer and the reply. That is the
    race the soft lock exists to resolve, not a fault for the customer."""
    acquire_soft_lock(scope, "s1", ttl_s=600, now=NOW)
    session.commit()
    booking, match = confirm.try_confirm(scope, customer_ref="+9199", body="1", now=NOW)
    assert booking is None
    assert "slot taken" in match.reason


def test_a_confirmed_offer_cannot_be_used_twice(scope, session, offered):
    confirm.try_confirm(scope, customer_ref="+9199", body="1", now=NOW)
    session.commit()
    booking, match = confirm.try_confirm(scope, customer_ref="+9199", body="2", now=NOW)
    assert booking is None and match.reason == "no open offer"


def test_an_expired_offer_is_not_matched(scope, session, offered):
    booking, match = confirm.try_confirm(
        scope, customer_ref="+9199", body="1",
        now=NOW + timedelta(hours=confirm.OFFER_TTL_HOURS + 1))
    assert booking is None and match.reason == "no open offer"


def test_a_new_offer_supersedes_the_previous_one(scope, session, offered):
    confirm.record_offer(scope, customer_ref="+9199", options=[offered[2]],
                         service_id="svc_cleaning", now=NOW)
    session.commit()
    states = sorted(o.state for o in scope.all(Offer))
    assert states == ["open", "superseded"]


def test_matching_is_deterministic_and_never_calls_a_model(scope, session, offered):
    """A booking must not be creatable by something that can be persuaded."""
    import inspect

    src = inspect.getsource(confirm)
    for forbidden in ("complete(", "LLMProvider", "get_provider", "Pipeline"):
        assert forbidden not in src, f"confirm.py must not reach a model: {forbidden}"


def test_offers_are_tenant_scoped(scope, session, offered):
    from app.db import TenantScope
    from tests.conftest import make_tenant

    make_tenant(session, tenant_id="t_rival", tenant_name="Rival")
    rival = TenantScope(session, "t_rival")
    assert confirm.open_offer(rival, "+9199", NOW) is None


def test_an_unidentified_service_is_never_guessed(scope, session):
    """An earlier version fell back to a made-up "svc_default", which books a
    real person into a real slot for a service nobody identified -- a fabricated
    fact with a diary entry attached."""
    from app.models import Resource, Slot

    scope.add(Resource(id="rz", name="Dr Z", skills=[]))
    starts = (NOW + timedelta(hours=30)).replace(minute=0)
    scope.add(Slot(id="sz", resource_id="rz", service_id=None,
                   starts_at=starts, duration_min=45))
    session.commit()
    confirm.record_offer(
        scope, customer_ref="+9177",
        options=[{"slot_id": "sz", "starts_at": starts.isoformat(),
                  "resource_id": "rz", "resource_name": "Dr Z", "duration_minutes": 45}],
        service_id=None, now=NOW,
    )
    session.commit()

    booking, match = confirm.try_confirm(scope, customer_ref="+9177", body="1", now=NOW)
    assert booking is None
    assert "service not identified" in match.reason
