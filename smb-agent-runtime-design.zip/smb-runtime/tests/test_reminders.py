"""Deterministic reminder scheduling, section 4 / A5."""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

from app.models import Booking, Reminder, Resource, Slot
from app.runtime import reminders
from app.runtime.booking import acquire_soft_lock, commit_booking

# Anchored to the real clock, deliberately.
#
# This file used to pin NOW to an absolute date. That worked until the date
# passed, at which point a booking "72 hours ahead" of NOW was in fact days in
# the PAST, schedule_for_booking correctly scheduled nothing, and four tests
# failed on a machine whose only sin was having the right date on it. A test
# that depends on today's date is a test with an expiry, and the failure looks
# like a code regression rather than what it is.
#
# Every call below passes now=NOW explicitly, so the suite is reasoning about
# one consistent clock rather than mixing a frozen one with the system's.
NOW = datetime.now(UTC).replace(microsecond=0)


def _booking(scope, session, hours_ahead: int = 72) -> Booking:
    scope.add(Resource(id="r1", name="Dr Shah", skills=[]))
    scope.add(Slot(id="sX", resource_id="r1", service_id="svc_cleaning",
                   starts_at=NOW + timedelta(hours=hours_ahead), duration_min=45))
    session.commit()
    lock = acquire_soft_lock(scope, "sX", ttl_s=600, now=NOW)
    b = commit_booking(scope, lock, customer_ref="+919812345678",
                       service_id="svc_cleaning", now=NOW)
    session.commit()
    return b


def test_both_stages_are_scheduled_for_a_future_booking(scope, session):
    b = _booking(scope, session, hours_ahead=72)
    rows = reminders.schedule_for_booking(scope, b, now=NOW)
    session.commit()
    assert {r.stage for r in rows} == {"T-24h", "T-2h"}
    offsets = {r.stage: b.starts_at - r.due_at for r in rows}
    assert offsets["T-24h"] == timedelta(hours=24)
    assert offsets["T-2h"] == timedelta(hours=2)


def test_a_stage_already_in_the_past_is_not_scheduled(scope, session):
    """A booking made three hours out gets no T-24h reminder. Creating one and
    suppressing it later would leave a row that reads as a failure in every
    report that counts them."""
    b = _booking(scope, session, hours_ahead=3)
    rows = reminders.schedule_for_booking(scope, b, now=NOW)
    session.commit()
    assert {r.stage for r in rows} == {"T-2h"}


def test_scheduling_is_idempotent(scope, session):
    b = _booking(scope, session)
    reminders.schedule_for_booking(scope, b, now=NOW)
    session.commit()
    assert reminders.schedule_for_booking(scope, b, now=NOW) == []


def test_only_due_reminders_are_returned(scope, session):
    b = _booking(scope, session, hours_ahead=72)
    reminders.schedule_for_booking(scope, b, now=NOW)
    session.commit()
    assert reminders.due_reminders(scope, now=NOW) == []
    at_24h = b.starts_at - timedelta(hours=24)
    due = reminders.due_reminders(scope, now=at_24h)
    assert [d.stage for d in due] == ["T-24h"]


def test_a_queued_reminder_is_not_returned_again(scope, session):
    """The scheduler runs every few minutes and finds the same booking each
    time. A customer who gets the same reminder twelve times blocks the number."""
    b = _booking(scope, session, hours_ahead=72)
    reminders.schedule_for_booking(scope, b, now=NOW)
    session.commit()
    at_24h = b.starts_at - timedelta(hours=24)
    assert reminders.due_reminders(scope, now=at_24h)
    reminders.mark_queued(scope, b.id, "T-24h")
    session.commit()
    assert reminders.due_reminders(scope, now=at_24h) == []


def test_a_cancelled_booking_gets_no_reminders(scope, session):
    b = _booking(scope, session, hours_ahead=72)
    reminders.schedule_for_booking(scope, b, now=NOW)
    session.commit()
    b.state = "cancelled"
    session.commit()
    assert reminders.due_reminders(scope, now=b.starts_at - timedelta(hours=24)) == []


def test_cancelling_a_booking_drops_its_outstanding_reminders(scope, session):
    b = _booking(scope, session, hours_ahead=72)
    reminders.schedule_for_booking(scope, b, now=NOW)
    session.commit()
    assert reminders.cancel_for_booking(scope, b.id) == 2
    assert {r.state for r in scope.all(Reminder)} == {"cancelled"}


def test_word_ceilings_match_the_spec():
    assert reminders.WORD_CEILING["T-2h"] == 20
    assert reminders.WORD_CEILING["T-24h"] == 50
    assert reminders.WORD_CEILING["no_show_recovery"] == 40
    assert reminders.over_ceiling("T-2h", " ".join(["word"] * 21))
    assert not reminders.over_ceiling("T-2h", "Tomorrow 11am at the clinic.")


def test_the_reminder_payload_carries_tenant_local_time(scope, session, tenant):
    """A stored timestamp is UTC. Handing it to A5 unconverted is how a Surat
    patient is told to arrive at 4:30 in the morning."""
    from app.models import Job
    from app.workers.runner import tick_reminders

    b = _booking(scope, session, hours_ahead=72)
    reminders.schedule_for_booking(scope, b, now=NOW)
    # Make the T-24h reminder due.
    row = next(r for r in scope.all(Reminder) if r.stage == "T-24h")
    row.due_at = NOW - timedelta(minutes=1)
    session.commit()

    # Only the T-24h row is due at NOW; T-2h is still two days out.
    assert tick_reminders("test", now=NOW) == 1
    job = next(j for j in scope.all(Job) if j.agent_id == "A5")
    starts = job.payload["booking"]["starts_at"]
    assert starts.endswith("+05:30"), f"expected tenant-local time, got {starts}"


def test_no_test_pins_an_absolute_date(tmp_path):
    """Guard against the failure this file already had once.

    A fixture pinned to a calendar date works until that date passes, and then
    fails on a machine whose only fault is having the correct day on it -- while
    looking exactly like a code regression. Clocks in tests are anchored to
    datetime.now() and passed explicitly.
    """
    import pathlib
    import re

    tests_dir = pathlib.Path(__file__).resolve().parent
    pinned = re.compile(r"datetime\(\s*20\d\d\s*,")
    offenders = [
        f.name for f in sorted(tests_dir.glob("test_*.py"))
        if pinned.search(f.read_text(encoding="utf-8"))
    ]
    assert not offenders, (
        f"these test files pin an absolute date and will rot: {offenders}"
    )
