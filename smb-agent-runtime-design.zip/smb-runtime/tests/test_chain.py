"""Chain routing and the A2 pre-emption, section 4."""
from __future__ import annotations

import pytest

from app.runtime import chain
from app.schemas.agents import A1Output, A2Output


def a1(intent: str, **kw) -> A1Output:
    base = dict(intent=intent, language="en", customer={"known": False},
                confidence=0.9, escalate=False, reason=None)
    base.update(kw)
    return A1Output(**base)


def a2(level: str, **kw) -> A2Output:
    base = dict(level=level, confidence=0.9, escalate=False, reason=None)
    base.update(kw)
    return A2Output(**base)


@pytest.mark.parametrize("intent", ["book", "service_enquiry", "follow_up_existing",
                                    "reschedule"])
def test_a1_triggers_a2_for_the_specified_intents(intent):
    out = chain.next_steps("A1", a1(intent))
    assert [s.agent_id for s in out.steps] == ["A2"]
    assert out.steps[0].payload_extra["upstream_a1"]["intent"] == intent


@pytest.mark.parametrize("intent", ["price_enquiry", "location_hours", "cancel",
                                    "document_or_report", "other"])
def test_other_intents_skip_a2_but_still_get_a_reply_drafted(intent):
    """Section 4 / A4's trigger includes "any inbound that needs a textual
    answer". Someone asking opening hours gets no urgency screen and must not
    therefore fall off the end of the chain unanswered."""
    out = chain.next_steps("A1", a1(intent))
    assert [s.agent_id for s in out.steps] == ["A4"]
    assert "upstream_a2" not in out.steps[0].payload_extra


def test_spam_gets_no_reply_at_all():
    """Replying to spam is how a tenant's number gets reported."""
    assert chain.next_steps("A1", a1("spam")).steps == ()


def test_a_draft_reached_without_a2_can_never_auto_send(scope, session, tenant):
    """No a2 level on the payload means the review gate reads "not routine",
    which is correct: nothing cleared it."""
    from app.runtime.autosend import blocked_by_urgency

    out = chain.next_steps("A1", a1("location_hours"))
    assert blocked_by_urgency(out.steps[0].payload_extra.get("upstream_a2", {}).get("level"))


def test_a2_still_runs_on_a_complaint_even_though_a1_escalated():
    """A1 escalating on a complaint routes it to a human. A2 decides whether
    that human looks now or at end of shift, which is a different fact."""
    out = chain.next_steps(
        "A1", a1("complaint", escalate=True, reason="sentiment_risk",
                 raw_complaint_text="waited 50 minutes")
    )
    assert [s.agent_id for s in out.steps] == ["A2"]


def test_reschedule_is_routed_through_a2_to_reach_a3():
    """Section 4 lists reschedule in A3's trigger but not A2's, and A3 also
    requires an A2 level -- so a reschedule that skipped A2 could never reach
    A3, which is the one request that most obviously needs slot options.
    Resolved by running the safety gate."""
    assert [s.agent_id for s in chain.next_steps("A1", a1("reschedule")).steps] == ["A2"]
    out = chain.next_steps("A2", a2("routine"), upstream_intent="reschedule")
    assert [s.agent_id for s in out.steps] == ["A3"]


@pytest.mark.parametrize("intent", ["book", "reschedule"])
def test_a2_routine_routes_booking_intents_to_a3(intent):
    out = chain.next_steps("A2", a2("routine"), upstream_intent=intent)
    assert [s.agent_id for s in out.steps] == ["A3"]


@pytest.mark.parametrize("intent", ["service_enquiry", "follow_up_existing", "complaint"])
def test_non_booking_intents_skip_a3(intent):
    """A price question has no slots to propose."""
    out = chain.next_steps("A2", a2("routine"), upstream_intent=intent)
    assert [s.agent_id for s in out.steps] == ["A4"]


def test_a3_always_hands_off_to_a4_even_with_no_options():
    """A3 setting escalate with an unavailable_note still needs A4 to turn it
    into something the customer reads."""
    from app.schemas.agents import A3Output

    empty = A3Output(options=[], unavailable_note="nothing open that week",
                     confidence=0.9, escalate=True, reason="missing_fact")
    out = chain.next_steps("A3", empty)
    assert [s.agent_id for s in out.steps] == ["A4"]
    assert out.steps[0].payload_extra["upstream_a3"]["unavailable_note"]


def test_immediate_preempts_the_chain_and_alerts():
    out = chain.next_steps("A2", a2("immediate", escalate=True, reason="policy_boundary"))
    assert out.preempt is True
    assert out.alert == "immediate"
    assert out.steps == ()


def test_same_day_pages_staff_and_still_continues_the_chain():
    """A same_day case usually still needs a reply. Having one ready saves the
    person who picks it up from starting at a blank box."""
    out = chain.next_steps("A2", a2("same_day"), upstream_intent="book")
    assert [s.agent_id for s in out.steps] == ["A3"]
    assert out.alert == "same_day" and out.preempt is False


def test_a4_is_the_end_of_the_chain():
    from app.schemas.agents import A4Output

    draft = A4Output(draft="Kal saanje available che.", language="gu-Latn",
                     intent_handled="book", confidence=0.9, escalate=False)
    assert chain.next_steps("A4", draft) == chain.ChainOutcome()
