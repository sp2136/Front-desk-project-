"""Webhook ingestion, console queue and the kill switch, through HTTP."""
from __future__ import annotations

import json
import pathlib

from fastapi.testclient import TestClient

from app.config import settings
from app.main import app

ROOT = pathlib.Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "seeds" / "tenant_dentist.json").read_text())
CONTEXT = {k: v for k, v in
           json.loads((ROOT / "seeds" / "tenant_dentist_context.json").read_text()).items()
           if not k.startswith("_")}
SEED = {"config": CONFIG, "context": CONTEXT}


def seed_with(**config_overrides) -> dict:
    return {"config": {**CONFIG, **config_overrides}, "context": CONTEXT}
ADMIN = {"x-api-key": settings.admin_api_key}
CONSOLE = {"x-api-key": settings.console_api_key}


def test_healthz_reports_stage_and_provider():
    with TestClient(app) as c:
        body = c.get("/healthz").json()
        assert body["stage"] == 0


def test_onboarding_is_just_the_section_10_form():
    with TestClient(app) as c:
        r = c.post("/admin/tenants", json=SEED, headers=ADMIN)
        assert r.status_code == 201, r.text
        assert r.json()["archetype"] == "A"

        again = c.post("/admin/tenants", json=SEED, headers=ADMIN)
        assert again.status_code == 409


def test_admin_requires_a_key():
    with TestClient(app) as c:
        assert c.post("/admin/tenants", json=SEED).status_code == 401
        assert c.get("/console/t_smile_dental/queue").status_code == 401


def test_restaurant_is_refused_as_deferred():
    with TestClient(app) as c:
        payload = seed_with(tenant_id="t_food", business_type="restaurant")
        r = c.post("/admin/tenants", json=payload, headers=ADMIN)
        assert r.status_code == 422
        assert "deferred" in r.text


def test_unknown_language_code_is_refused():
    with TestClient(app) as c:
        payload = seed_with(tenant_id="t_lang", languages=["gu", "fr"])
        r = c.post("/admin/tenants", json=payload, headers=ADMIN)
        assert r.status_code == 422


def test_webhook_ingests_once_and_dedupes_the_retry():
    with TestClient(app) as c:
        c.post("/admin/tenants", json=SEED, headers=ADMIN)
        msg = {"external_id": "wamid.ABC", "sender_ref": "+919900000002",
               "body": "kaal aavi sakay? saanje 6 vagya pachi"}
        first = c.post("/webhooks/t_smile_dental/whatsapp", json=msg).json()
        assert first["accepted"] and first["job_id"]

        retry = c.post("/webhooks/t_smile_dental/whatsapp", json=msg).json()
        assert retry["accepted"] is False
        assert "already seen" in retry["reason"]


def test_webhook_on_unknown_tenant_is_404():
    with TestClient(app) as c:
        r = c.post("/webhooks/t_nope/whatsapp", json={"sender_ref": "+91", "body": "hi"})
        assert r.status_code == 404


def test_metrics_endpoint_exposes_the_section_1_4_numbers():
    with TestClient(app) as c:
        c.post("/admin/tenants", json=SEED, headers=ADMIN)
        m = c.get("/console/t_smile_dental/metrics", headers=CONSOLE).json()
        assert m["audit_chain_intact"] is True
        assert m["usage"]["token_cap_inr"] == 150
        assert m["usage"]["message_cap"] == 400
        assert m["guard"] == {"drafts_guarded": 0, "blocked_rate": None,
                              "violations_by_rule": {}}


def test_kill_switch_is_one_call_and_audited():
    with TestClient(app) as c:
        c.post("/admin/tenants", json=SEED, headers=ADMIN)
        r = c.post("/admin/tenants/t_smile_dental/kill-switch",
                   json={"engaged": True, "actor": "mann", "note": "incident"},
                   headers=ADMIN)
        assert r.json()["kill_switch"] is True
        assert c.get("/admin/tenants/t_smile_dental", headers=ADMIN).json()["kill_switch"] is True
