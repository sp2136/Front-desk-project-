from __future__ import annotations

import json
import os
import pathlib
import tempfile

os.environ.setdefault("LLM_PROVIDER", "echo")
_tmp = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"

import pytest  # noqa: E402

from app.db import SessionLocal, TenantScope, engine, init_db  # noqa: E402
from app.models import Base, Tenant  # noqa: E402
from app.runtime import tool_impls  # noqa: F401,E402
from app.schemas.tenant import TenantConfig  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parents[1]
SEED = ROOT / "seeds" / "tenant_dentist.json"
CONTEXT = ROOT / "seeds" / "tenant_dentist_context.json"


@pytest.fixture(autouse=True)
def fresh_db():
    Base.metadata.drop_all(engine)
    init_db()
    yield
    Base.metadata.drop_all(engine)


@pytest.fixture
def session():
    s = SessionLocal()
    yield s
    s.close()


def make_tenant(session, **overrides) -> TenantConfig:
    raw = json.loads(SEED.read_text())
    raw.update(overrides)
    cfg = TenantConfig(**raw)
    ctx = {k: v for k, v in json.loads(CONTEXT.read_text()).items()
           if not k.startswith("_")}
    session.add(
        Tenant(
            id=cfg.tenant_id, name=cfg.tenant_name, business_type=cfg.business_type,
            archetype=cfg.archetype.value,
            config={**cfg.model_dump(mode="json"), **ctx},
            kill_switch=cfg.kill_switch,
        )
    )
    session.commit()
    return cfg


@pytest.fixture
def tenant(session):
    return make_tenant(session, agents_enabled=["A1", "A2", "A3", "A4", "A5"])


@pytest.fixture
def scope(session, tenant):
    return TenantScope(session, tenant.tenant_id)
