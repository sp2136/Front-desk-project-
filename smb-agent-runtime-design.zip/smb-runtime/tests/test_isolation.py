"""Section 11.3, TENANT ISOLATION: "test in code, not only in prompt ...
A prompt-level refusal is not a sufficient control here."
"""
from __future__ import annotations

import pytest

from app.db import TenantScope
from app.models import Decision, PromptRow
from app.runtime.errors import TenantIsolationError
from tests.conftest import make_tenant


def test_scope_cannot_read_another_tenants_rows(session, tenant):
    other = make_tenant(session, tenant_id="t_other", tenant_name="Other Clinic")

    a = TenantScope(session, tenant.tenant_id)
    b = TenantScope(session, other.tenant_id)
    a.add(Decision(kind="queued_for_human", draft="A's draft"))
    b.add(Decision(kind="queued_for_human", draft="B's draft"))
    session.commit()

    assert [d.draft for d in a.all(Decision)] == ["A's draft"]
    assert [d.draft for d in b.all(Decision)] == ["B's draft"]


def test_scope_refuses_non_tenant_scoped_model(scope):
    with pytest.raises(TenantIsolationError):
        scope.query(PromptRow)


def test_scope_refuses_cross_tenant_write(scope):
    with pytest.raises(TenantIsolationError):
        scope.add(Decision(tenant_id="t_somebody_else", kind="queued_for_human"))


def test_scope_requires_a_tenant_id(session):
    with pytest.raises(TenantIsolationError):
        TenantScope(session, "")
