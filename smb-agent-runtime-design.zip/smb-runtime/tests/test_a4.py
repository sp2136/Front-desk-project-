"""A4 Reply Copilot, section 4 / A4, and the auto-send whitelist table."""
from __future__ import annotations

import json

import pytest

from app.runtime import autosend, queue
from app.runtime.llm import EchoProvider
from app.runtime.pipeline import Pipeline
from app.runtime.review import DecisionKind, approve, decide
from app.schemas.agents import A4Output, GuardOutput, GuardVerdict

PASS_GUARD = json.dumps({"verdict": "pass", "violations": [], "confidence": 0.9})


def a4(**kw) -> str:
    base = {"draft": "Scaling starts from 1500 and takes 45 minutes. Friday suit you?",
            "language": "en", "intent_handled": "price_enquiry",
            "facts_used": [{"claim": "price", "source": "svc_cleaning"}],
            "missing": [], "auto_send_eligible": True,
            "confidence": 0.9, "escalate": False, "reason": None, "evidence": []}
    base.update(kw)
    return json.dumps(base)


def _env(**kw) -> A4Output:
    base = dict(draft="We open at 10am. Shall I book you in?", language="en",
                intent_handled="location_hours", confidence=0.9, escalate=False,
                auto_send_eligible=True)
    base.update(kw)
    return A4Output(**base)


def _guard(verdict="pass") -> GuardOutput:
    return GuardOutput(verdict=GuardVerdict(verdict), violations=[], confidence=0.9)


# --- the contract ---------------------------------------------------------

def test_a_named_gap_forces_escalation():
    """Section 4 / A4: a missing fact means escalate and name the gap, never
    improvise around it."""
    with pytest.raises(ValueError, match="escalate is false"):
        A4Output(draft="Cleaning is available.", language="en",
                 intent_handled="price_enquiry", missing=["current price"],
                 confidence=0.9, escalate=False)


def test_a_draft_with_a_gap_is_never_auto_send_eligible():
    with pytest.raises(ValueError, match="never auto-send eligible"):
        A4Output(draft="Cleaning is available.", language="en",
                 intent_handled="price_enquiry", missing=["current price"],
                 auto_send_eligible=True, confidence=0.9, escalate=True,
                 reason="missing_fact")


def test_an_empty_draft_is_rejected_by_the_schema():
    with pytest.raises(ValueError):
        A4Output(draft="", language="en", intent_handled="book",
                 confidence=0.9, escalate=False)


# --- the pipeline ---------------------------------------------------------

def _run_a4(scope, session, provider, payload=None):
    job = queue.enqueue(scope, agent_id="A4", dedupe_key="whatsapp:a4",
                        payload={"event": {"body": "what does cleaning cost?"},
                                 **(payload or {})})
    session.commit()
    return Pipeline(provider).run(scope, job)


def test_a4_is_guarded_and_the_internal_agents_are_not(scope, session, tenant):
    """Only A4 drafts anything a customer sees, so only A4 is gated. Running
    the guard over A1's intent label would cost a call and gate nothing."""
    a1_json = json.dumps({
        "intent": "price_enquiry", "service_id": None, "service_guess": None,
        "raw_complaint_text": None, "language": "en",
        "customer": {"known": False, "id": None, "name": None},
        "time_window": {"earliest": None, "latest": None, "preferred_days": [],
                        "part_of_day": None},
        "blockers": [], "confidence": 0.9, "escalate": False, "reason": None,
        "evidence": []})
    job = queue.enqueue(scope, agent_id="A1", dedupe_key="whatsapp:a1-vs-a4",
                        payload={"event": {"body": "what does cleaning cost?"}})
    session.commit()
    a1_result = Pipeline(EchoProvider(script=[a1_json])).run(scope, job)
    assert a1_result.decision.guard_verdict is None

    a4_result = _run_a4(scope, session, EchoProvider(script=[a4(), PASS_GUARD]))
    assert a4_result.ok
    assert a4_result.decision.guard_verdict is not None


def test_the_guard_checks_the_draft_against_what_the_runtime_retrieved(
    scope, session, tenant
):
    """The seed catalogue has published_price null, so a quoted 1500 is
    unsourced and the rule layer rejects before any model is paid for."""
    result = _run_a4(scope, session, EchoProvider(script=[a4()]))
    assert result.decision.kind == DecisionKind.BLOCKED
    rules = [v["rule"] for v in result.decision.guard_violations["violations"]]
    assert "unsourced_number" in rules


def test_a_draft_with_no_unsourced_facts_passes_the_rule_layer(scope, session, tenant):
    clean = a4(draft="Happy to help. Which day suits you best?",
               intent_handled="book", facts_used=[])
    result = _run_a4(scope, session, EchoProvider(script=[clean, PASS_GUARD]))
    assert result.decision.kind == DecisionKind.QUEUED_FOR_HUMAN
    assert result.decision.draft.startswith("Happy to help")


def test_the_prompt_receives_the_three_fact_blocks(scope, session, tenant):
    seen = {}
    provider = EchoProvider(script=[a4(), PASS_GUARD],
                            on_call=lambda sy, u: seen.setdefault("user", u))
    _run_a4(scope, session, provider)
    for tag in ("<faq_answers>", "<service_facts>", "<policy_block>", "<a1_output>"):
        assert tag in seen["user"]


# --- the whitelist table --------------------------------------------------

def test_the_day_one_whitelist_matches_the_spec(tenant):
    """Section 4 / A4's table: location_hours is "Yes - from day one", and
    `book` offers options rather than confirming anything, so both ship
    enabled. price_enquiry waits on the owner confirming the catalogue, and
    complaint is never auto-sent at all."""
    assert "location_hours" in tenant.auto_send_whitelist
    assert "book" in tenant.auto_send_whitelist
    assert "price_enquiry" not in tenant.auto_send_whitelist
    assert "complaint" not in tenant.auto_send_whitelist


def test_a2_not_routine_blocks_auto_send_even_for_a_whitelisted_intent(
    scope, session, tenant
):
    cfg = tenant.model_copy(update={"auto_send_whitelist": ["location_hours"]})
    d = decide(scope, cfg, run_id=None, envelope=_env(), draft=_env().draft,
               intent="location_hours", guard=_guard(), customer_facing=True,
               a2_level="same_day")
    assert d.kind == DecisionKind.QUEUED_FOR_HUMAN


def test_a_missing_a2_level_counts_as_not_routine(scope, session, tenant):
    """A draft whose safety gate never ran has not been cleared by it."""
    cfg = tenant.model_copy(update={"auto_send_whitelist": ["location_hours"]})
    d = decide(scope, cfg, run_id=None, envelope=_env(), draft=_env().draft,
               intent="location_hours", guard=_guard(), customer_facing=True,
               a2_level=None)
    assert d.kind == DecisionKind.QUEUED_FOR_HUMAN


def test_the_agents_own_eligibility_flag_can_only_veto_never_authorise(
    scope, session, tenant
):
    cfg = tenant.model_copy(update={"auto_send_whitelist": ["location_hours"]})
    vetoed = decide(scope, cfg, run_id=None, envelope=_env(auto_send_eligible=False),
                    draft=_env().draft, intent="location_hours", guard=_guard(),
                    customer_facing=True, a2_level="routine")
    assert vetoed.kind == DecisionKind.QUEUED_FOR_HUMAN

    # And the flag being true does not authorise anything on its own: the
    # intent is not on the tenant's whitelist here.
    bare = tenant.model_copy(update={"auto_send_whitelist": []})
    d = decide(scope, bare, run_id=None, envelope=_env(auto_send_eligible=True),
               draft=_env().draft, intent="location_hours", guard=_guard(),
               customer_facing=True, a2_level="routine")
    assert d.kind == DecisionKind.QUEUED_FOR_HUMAN


# --- widening policy ------------------------------------------------------

def test_location_hours_is_eligible_from_day_one():
    assert autosend.readiness("location_hours", approved=0, resolved=0).eligible


def test_service_enquiry_needs_fifty_reviewed_drafts_at_ninety_percent():
    assert not autosend.readiness("service_enquiry", approved=49, resolved=49).eligible
    assert not autosend.readiness("service_enquiry", approved=44, resolved=50).eligible
    assert autosend.readiness("service_enquiry", approved=48, resolved=50).eligible


def test_book_needs_a_hundred_drafts_at_ninety_five_percent():
    assert not autosend.readiness("book", approved=95, resolved=100).eligible  # not > 95%
    assert autosend.readiness("book", approved=96, resolved=100).eligible


def test_price_enquiry_waits_on_the_owner_not_on_a_rate():
    assert not autosend.readiness("price_enquiry", approved=100, resolved=100).eligible
    assert autosend.readiness("price_enquiry", approved=0, resolved=0,
                              catalogue_confirmed=True).eligible


def test_policy_sensitive_and_never_intents_do_not_widen():
    for intent in ("reschedule", "cancel", "complaint"):
        assert not autosend.readiness(intent, approved=999, resolved=999).eligible


def test_drafts_still_in_the_queue_are_not_evidence():
    """Only drafts a human actually decided on count, or an unattended queue
    would argue for widening."""
    r = autosend.readiness("service_enquiry", approved=0, resolved=0)
    assert not r.eligible and r.needed_drafts == 50


# --- edit distance --------------------------------------------------------

def test_edit_distance_is_recorded_on_a_real_a4_draft(scope, session, tenant):
    clean = a4(draft="Happy to help. Which day suits you best?",
               intent_handled="book", facts_used=[])
    result = _run_a4(scope, session, EchoProvider(script=[clean, PASS_GUARD]))
    session.commit()
    row = approve(scope, result.decision.id, approver="front_desk_01",
                  sent_text="Happy to help! Which day suits you?")
    assert 0 < row.edit_distance_pct < 30


def test_a4s_intent_is_recorded_on_the_decision(scope, session, tenant):
    """A4 reports `intent_handled`, not `intent`. Recording None would mean the
    auto-send whitelist could never match an A4 draft, and the approval-rate
    counting behind "condition to widen" would have nothing to count."""
    clean = a4(draft="Happy to help. Which day suits you best?",
               intent_handled="service_enquiry", facts_used=[])
    result = _run_a4(scope, session, EchoProvider(script=[clean, PASS_GUARD]))
    assert result.decision.intent == "service_enquiry"


def test_a_whitelisted_a4_draft_can_auto_send_end_to_end(scope, session, tenant):
    from app.models import Tenant

    row = session.get(Tenant, tenant.tenant_id)
    row.config = {**row.config, "auto_send_whitelist": ["location_hours"]}
    session.commit()

    clean = a4(draft="Happy to help. Which day works for you?",
               intent_handled="location_hours", facts_used=[])
    job = queue.enqueue(scope, agent_id="A4", dedupe_key="whatsapp:ws",
                        payload={"event": {"body": "what time do you open?"},
                                 "upstream_a2": {"level": "routine"}})
    session.commit()
    result = Pipeline(EchoProvider(script=[clean, PASS_GUARD])).run(scope, job)
    assert result.decision.kind == DecisionKind.AUTO_SEND


def test_the_option_ceiling_is_per_tenant(scope, session, tenant):
    """Section 4 / A3 says three, and that holds for a clinic. A courts venue
    with 144 open hours offering three reads as "almost nothing is free"."""
    from app.schemas.agents import A3Output
    from app.schemas.envelope import apply_option_ceiling

    opts = [{"slot_id": f"s{i}", "starts_at": f"2026-11-0{i}T10:00:00+05:30",
             "resource_id": "r1", "resource_name": "Dr Shah", "duration_minutes": 45}
            for i in range(1, 7)]
    out = A3Output(options=opts, confidence=0.9, escalate=False)
    assert len(apply_option_ceiling(out, 3).options) == 3
    assert len(apply_option_ceiling(out, 6).options) == 6
    # Trimming keeps the spread A3 was told to produce, not a morning's worth.
    assert apply_option_ceiling(out, 2).options[1].slot_id == "s2"


def test_the_absolute_ceiling_still_holds_whatever_a_tenant_configures():
    """A phone message listing more than this stops being readable."""
    from app.schemas.agents import MAX_SLOT_OPTIONS_ABSOLUTE, A3Output

    too_many = [{"slot_id": f"s{i}", "starts_at": f"2026-11-{i:02d}T10:00:00+05:30",
                 "resource_id": "r1", "resource_name": "Dr Shah", "duration_minutes": 45}
                for i in range(1, MAX_SLOT_OPTIONS_ABSOLUTE + 2)]
    with pytest.raises(ValueError, match="at most"):
        A3Output(options=too_many, confidence=0.9, escalate=False)


def test_availability_summary_is_a_count_not_a_characterisation(scope, session, tenant):
    """"20 other times this week" is a fact. "Plenty of availability" is not,
    and A4 has no context block that would let it say the second."""
    from datetime import UTC, datetime, timedelta

    from app.models import Resource, Slot
    from app.runtime.booking import availability_summary

    now = datetime.now(UTC)
    scope.add(Resource(id="rr", name="Dr R", skills=["svc_cleaning"]))
    for i in range(1, 11):
        scope.add(Slot(id=f"av{i}", resource_id="rr", service_id=None,
                       starts_at=now + timedelta(hours=10 + i * 3), duration_min=45))
    session.commit()

    summary = availability_summary(scope, service_id="svc_cleaning",
                                   exclude_slot_ids={"av1", "av2", "av3"})
    assert summary["not_listed_total"] == 7
    assert summary["horizon_days"] == 7
    assert sum(summary["by_day"].values()) == 7
