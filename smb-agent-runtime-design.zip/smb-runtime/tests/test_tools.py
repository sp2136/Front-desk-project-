"""Section 1.2, Law 1: agents read widely and write nothing."""
from __future__ import annotations

import pytest

from app.runtime.errors import WriteToolRefused
from app.runtime.tools import build_toolbelt, registry, toolbelt_version


def test_write_tools_are_registered_so_the_refusal_is_testable():
    assert "commit_booking" in registry.write_tools()
    assert "create_soft_lock" in registry.write_tools()
    assert "log_event" in registry.write_tools()


@pytest.mark.parametrize("write_tool", ["commit_booking", "create_soft_lock", "log_event"])
def test_agent_cannot_be_given_a_write_tool(scope, write_tool):
    with pytest.raises(WriteToolRefused):
        build_toolbelt(["get_service_catalogue", write_tool], scope)


def test_read_tools_bind_and_record_a_tool_call(scope, session):
    from app.models import ToolCall

    belt = build_toolbelt(["get_service_catalogue"], scope, run_id=None)
    catalogue = belt["get_service_catalogue"]()
    assert [row["id"] for row in catalogue][:2] == ["svc_consult", "svc_cleaning"]
    # The seed leaves published_price null on purpose. Section 4 / A4: a missing
    # price is a missing fact to escalate on, never one to improvise around.
    assert all(row["published_price"] is None for row in catalogue)
    session.commit()
    assert len(scope.all(ToolCall)) == 1


def test_toolbelt_version_is_stable_and_order_independent():
    assert toolbelt_version(["get_service_catalogue", "search_faq"]) == toolbelt_version(
        ["search_faq", "get_service_catalogue"]
    )
    assert toolbelt_version(["search_faq"]) != toolbelt_version(["get_service_catalogue"])


def test_unknown_tool_fails_loudly(scope):
    with pytest.raises(KeyError):
        build_toolbelt(["get_moon_phase"], scope)
