"""A6 Review Requester, A7 Recurrence, A8 Analyst — sections 4/A6-A8."""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from app.models import Booking, Customer, Job, Resource, Slot, Tenant
from app.runtime import recurrence, sweeps
from app.runtime.booking import acquire_soft_lock, commit_booking
from app.schemas.agents import A6Output, A7Output, A8Output

NOW = datetime.now(UTC).replace(microsecond=0)


def _completed_booking(scope, session, *, days_ago: int = 200, notes: str = "",
                       ref: str = "+919812345678") -> Booking:
    sid = f"s{days_ago}{ref[-3:]}"
    scope.add(Resource(id="r1", name="Dr Shah", skills=[])) if not scope.all(
        Resource, Resource.id == "r1") else None
    scope.add(Slot(id=sid, resource_id="r1", service_id=None,
                   starts_at=NOW - timedelta(days=days_ago), duration_min=45))
    session.commit()
    lock = acquire_soft_lock(scope, sid, ttl_s=600, now=NOW - timedelta(days=days_ago + 1))
    b = commit_booking(scope, lock, customer_ref=ref, service_id="svc_cleaning",
                       customer_name="Mehul", now=NOW - timedelta(days=days_ago + 1))
    b.state = "completed"
    b.internal_notes = notes
    session.commit()
    return b


def _enable(session, tenant_id: str, agents: list[str], **cfg_extra) -> None:
    row = session.get(Tenant, tenant_id)
    row.config = {**row.config, "agents_enabled": agents, **cfg_extra}
    session.commit()


# --- A6: the sentiment gate ----------------------------------------------

def test_a_negative_thread_can_never_produce_a_customer_facing_draft():
    """Section 4 / A6: "An ungated review request sent to an unhappy customer
    manufactures the one-star review that would otherwise never have been
    written." The gate is in the schema, not only the prompt."""
    with pytest.raises(ValueError, match="never be asked"):
        A6Output(sentiment="negative", ask=True, route_to_owner=True,
                 confidence=0.9, escalate=False)
    with pytest.raises(ValueError, match="NO customer-facing draft"):
        A6Output(sentiment="negative", ask=False, route_to_owner=True,
                 draft="Mind leaving us a review?", confidence=0.9, escalate=False)
    with pytest.raises(ValueError, match="route_to_owner"):
        A6Output(sentiment="negative", ask=False, route_to_owner=False,
                 confidence=0.9, escalate=False)


def test_a_negative_thread_routes_to_the_owner_with_a_note():
    out = A6Output(sentiment="negative", ask=False, route_to_owner=True,
                   owner_note="Customer disputed the charge last week.",
                   confidence=0.9, escalate=True, reason="sentiment_risk")
    assert out.draft is None and out.owner_note


def test_unknown_sentiment_escalates_rather_than_guessing():
    with pytest.raises(ValueError, match="escalate=true"):
        A6Output(sentiment="unknown", ask=False, confidence=0.4, escalate=False)


def test_ask_without_a_draft_is_incoherent():
    with pytest.raises(ValueError, match="requires a draft"):
        A6Output(sentiment="positive", ask=True, confidence=0.9, escalate=False)


def test_review_asks_are_suppressed_within_ninety_days(scope, session, tenant):
    c = recurrence.get_or_create_customer(scope, "+9199")
    c.last_review_ask_at = NOW - timedelta(days=30)
    session.commit()
    assert recurrence.review_suppression(c, NOW).suppressed
    c.last_review_ask_at = NOW - timedelta(days=120)
    session.commit()
    assert not recurrence.review_suppression(c, NOW).suppressed


def test_the_sweep_does_nothing_without_a_review_link(scope, session, tenant):
    """Drafting an ask with a missing URL in it is worse than not asking."""
    _completed_booking(scope, session)
    _enable(session, tenant.tenant_id, ["A6"])
    assert sweeps.sweep_review_requests(scope, NOW) == 0


def test_the_sweep_queues_one_job_per_completed_visit(scope, session, tenant):
    b = _completed_booking(scope, session)
    _enable(session, tenant.tenant_id, ["A6"], review_link="https://example.invalid/r")
    assert sweeps.sweep_review_requests(scope, NOW) == 1
    assert [j.agent_id for j in scope.all(Job)] == ["A6"]
    # Never twice for the same visit, however often the sweep runs.
    assert sweeps.sweep_review_requests(scope, NOW) == 0
    assert scope.one_or_none(Booking, Booking.id == b.id).review_asked is True


# --- A7: suppression before the agent is ever asked -----------------------

def test_opt_out_is_absolute(scope, session, tenant):
    """Section 4 / A7: "If opt_out is true: due = false. Always. No exceptions."""
    c = recurrence.get_or_create_customer(scope, "+9199")
    c.opt_out = True
    session.commit()
    assert recurrence.nudge_suppression(c, NOW).reason == "opt_out"


def test_a_nudge_inside_forty_five_days_is_suppressed(scope, session, tenant):
    c = recurrence.get_or_create_customer(scope, "+9199")
    c.last_nudge_at = NOW - timedelta(days=20)
    session.commit()
    assert recurrence.nudge_suppression(c, NOW).reason == "too_recent"


def test_three_silent_nudges_mark_the_customer_dormant(scope, session, tenant):
    c = recurrence.get_or_create_customer(scope, "+9199")
    for i in range(3):
        c.last_nudge_at = NOW - timedelta(days=60 * (3 - i))
        recurrence.record_nudge(scope, c, NOW - timedelta(days=60 * (3 - i)))
    session.commit()
    assert c.dormant is True
    assert recurrence.nudge_suppression(c, NOW).reason == "dormant"


def test_a_reply_resets_the_dormancy_count(scope, session, tenant):
    c = recurrence.get_or_create_customer(scope, "+9199")
    c.nudge_count = 3
    c.last_nudge_reply_at = NOW - timedelta(days=1)
    c.last_nudge_at = NOW - timedelta(days=100)
    session.commit()
    assert not recurrence.nudge_suppression(c, NOW).suppressed


def test_a_service_with_no_configured_interval_is_never_due(scope, session, tenant):
    """Section 4 / A7: "never infer an interval for a service that has none
    configured." """
    _completed_booking(scope, session, days_ago=500)
    assert recurrence.due_for_recall(scope, {}, NOW) == []
    assert recurrence.due_for_recall(scope, {"svc_other": 30}, NOW) == []


def test_a_customer_past_their_interval_becomes_a_candidate(scope, session, tenant):
    _completed_booking(scope, session, days_ago=200)
    found = recurrence.due_for_recall(scope, {"svc_cleaning": 180}, NOW)
    assert len(found) == 1
    assert found[0]["service_id"] == "svc_cleaning"
    assert found[0]["days_since"] >= 180


def test_a_customer_inside_their_interval_is_not_a_candidate(scope, session, tenant):
    _completed_booking(scope, session, days_ago=30)
    assert recurrence.due_for_recall(scope, {"svc_cleaning": 180}, NOW) == []


def test_a_suppressed_nudge_carries_no_draft():
    with pytest.raises(ValueError, match="must not carry a customer-facing draft"):
        A7Output(due=False, days_since=200, draft="Come back!",
                 suppress_reason="opt_out", confidence=0.9, escalate=False)
    with pytest.raises(ValueError, match="requires a suppress_reason"):
        A7Output(due=False, days_since=200, confidence=0.9, escalate=False)


def test_the_recurrence_sweep_queues_and_records(scope, session, tenant):
    _completed_booking(scope, session, days_ago=200)
    _enable(session, tenant.tenant_id, ["A7"], recall_rules={"svc_cleaning": 180})
    assert sweeps.sweep_recurrence(scope, NOW) == 1
    c = scope.all(Customer)[0]
    assert c.nudge_count == 1 and c.last_nudge_at is not None
    # The same week's sweep does not nudge again.
    assert sweeps.sweep_recurrence(scope, NOW) == 0


# --- A8: report, never attribute ------------------------------------------

def test_the_digest_caps_actions_at_two():
    with pytest.raises(ValueError):
        A8Output(digest="x", headline_metric={"name": "a", "value": 1},
                 actions=[{"action": "a", "because_of": "m"}] * 3,
                 confidence=0.9, escalate=False)


def test_every_action_must_name_the_metric_behind_it():
    """A suggestion with no number behind it is advice, and A8 does not advise."""
    with pytest.raises(ValueError):
        A8Output(digest="x", headline_metric={"name": "a", "value": 1},
                 actions=[{"action": "do something", "because_of": ""}],
                 confidence=0.9, escalate=False)


def test_metrics_report_not_measured_rather_than_a_proxy(session, tenant):
    from app.runtime import metrics

    payload = metrics.digest_inputs(session, tenant.tenant_id, NOW)
    assert "revenue" in payload["not_measured"]
    assert "attribution of any change to any cause" in payload["not_measured"]


def test_digest_inputs_carry_current_prior_and_exceptions(session, tenant):
    from app.runtime import metrics

    payload = metrics.digest_inputs(session, tenant.tenant_id, NOW)
    assert set(payload) == {"metrics_current", "metrics_prior", "exceptions",
                            "not_measured"}
    assert "previous_week" in payload["metrics_prior"]
    assert "escalations_not_cleared" in payload["exceptions"]


def test_the_digest_sweep_is_once_per_week(scope, session, tenant):
    _enable(session, tenant.tenant_id, ["A8"])
    assert sweeps.sweep_digest(scope, NOW) == 1
    session.commit()
    assert sweeps.sweep_digest(scope, NOW) == 0
    assert sweeps.sweep_digest(scope, NOW + timedelta(days=7)) == 1


def test_run_all_skips_a_tenant_with_the_kill_switch_engaged(session, tenant):
    row = session.get(Tenant, tenant.tenant_id)
    row.config = {**row.config, "agents_enabled": ["A8"]}
    row.kill_switch = True
    session.commit()
    assert sweeps.run_all(session, NOW) == {"A6": 0, "A7": 0, "A8": 0}


def test_run_all_only_runs_enabled_agents(session, tenant):
    _enable(session, tenant.tenant_id, ["A8"])
    assert sweeps.run_all(session, NOW)["A8"] == 1
    assert sweeps.run_all(session, NOW)["A7"] == 0
