"""Section 10: "The two caps are not optional." """
from __future__ import annotations

import pytest

from app.runtime.caps import CapGuard, cost_micros
from app.runtime.errors import CapExceeded, KillSwitchEngaged
from tests.conftest import make_tenant


def test_token_cap_disables_rather_than_overspending(session, scope):
    cfg = make_tenant(session, tenant_id="t_tiny", daily_token_cap_inr=1,
                      agents_enabled=["A1"])
    from app.db import TenantScope

    tiny = TenantScope(session, "t_tiny")
    guard = CapGuard(tiny, cfg)
    guard.preflight(10, 10)
    guard.record_usage(500_000, 500_000)  # blow well past INR 1
    with pytest.raises(CapExceeded):
        guard.preflight(10, 10)
    # And it stays disabled for the rest of the day, loudly.
    snap = guard.snapshot()
    assert snap["disabled_reason"] == "token_cap"
    assert snap["disabled_at"] is not None


def test_message_cap_blocks_further_sends(session):
    cfg = make_tenant(session, tenant_id="t_msg", daily_message_cap=2,
                      agents_enabled=["A1"])
    from app.db import TenantScope

    sc = TenantScope(session, "t_msg")
    guard = CapGuard(sc, cfg)
    guard.record_message_sent(2)
    with pytest.raises(CapExceeded):
        guard.preflight(1, 1)


def test_tenant_kill_switch(session):
    cfg = make_tenant(session, tenant_id="t_dead", kill_switch=True, agents_enabled=["A1"])
    from app.db import TenantScope

    guard = CapGuard(TenantScope(session, "t_dead"), cfg)
    with pytest.raises(KillSwitchEngaged):
        guard.preflight(1, 1)


def test_global_kill_switch(monkeypatch, scope, tenant):
    import app.runtime.caps as caps

    monkeypatch.setattr(caps.settings, "global_kill_switch", True)
    with pytest.raises(KillSwitchEngaged):
        CapGuard(scope, tenant).preflight(1, 1)


def test_cost_is_integer_micros():
    assert isinstance(cost_micros(100, 100), int)


def test_cached_input_is_billed_but_cheaply():
    """Cached reads are a distinct, far cheaper line. Ignoring them -- as this
    function originally did -- means a tenant's recorded spend stops including
    most of what they actually read the moment caching is switched on."""
    fresh = cost_micros(1000, 0)
    cached = cost_micros(0, 0, cached_input_tokens=1000)
    assert 0 < cached < fresh


def test_cached_tokens_count_toward_the_cap(session, scope, tenant):
    guard = CapGuard(scope, tenant)
    guard.record_usage(0, 0, cached_input_tokens=5000)
    snap = guard.snapshot()
    assert snap["spend_inr"] > 0, "cached reads must not be free in the cap"


def test_a_message_costs_paise_not_rupees():
    """One inbound message runs roughly 7,500 input and 400 output tokens
    across the A1-A4 chain plus the guard. At Haiku rates that is a few paise;
    an earlier placeholder rate put it at nearly three rupees, which made the
    daily cap look like it allowed about fifty messages instead of thousands."""
    rupees = cost_micros(7500, 400) / 1_000_000
    assert rupees < 0.25, f"a single message should not cost Rs {rupees:.2f}"
