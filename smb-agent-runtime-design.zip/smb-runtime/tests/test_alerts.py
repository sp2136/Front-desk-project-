"""Staff alerts for A2 immediate, section 4 / A2."""
from __future__ import annotations

from app.models import OutboundMessage
from app.runtime.alerts import raise_urgency_alert
from app.schemas.agents import A2Output


def _a2() -> A2Output:
    return A2Output(level="immediate", matched_signals=["bahu dukhe che", "turat"],
                    confidence=0.95, escalate=True, reason="policy_boundary")


def test_alert_creates_a_decision_and_notifies_each_target(scope, session, tenant):
    d = raise_urgency_alert(scope, tenant, run_id=None, a2=_a2(),
                            event={"sender_ref": "+919812000032", "channel": "whatsapp"})
    session.commit()
    assert d.kind == "escalated" and d.outcome == "open"
    msgs = scope.all(OutboundMessage)
    assert len(msgs) == len(tenant.staff_alert_targets) == 1
    assert msgs[0].to_ref == "+919812000032" or msgs[0].to_ref == "+919999000001"


def test_alert_carries_no_care_instruction_and_no_drafted_reply(scope, session, tenant):
    """A2's entire output surface is a level, matched phrases and a flag,
    specifically so a UI bug cannot leak a care instruction. The alert must
    not widen that surface."""
    raise_urgency_alert(scope, tenant, run_id=None, a2=_a2(),
                        event={"sender_ref": "+91", "channel": "whatsapp"})
    session.commit()
    body = scope.all(OutboundMessage)[0].body.lower()
    for forbidden in ("rinse", "painkiller", "apply", "you should", "take ", "until"):
        assert forbidden not in body
    assert "no automated reply was sent" in body
    # The matched phrases are carried verbatim and nothing is added.
    assert "bahu dukhe che" in scope.all(OutboundMessage)[0].body


def test_alert_does_not_consume_the_customer_message_cap(scope, session, tenant):
    from app.runtime.caps import CapGuard

    raise_urgency_alert(scope, tenant, run_id=None, a2=_a2(),
                        event={"sender_ref": "+91", "channel": "whatsapp"})
    session.commit()
    assert CapGuard(scope, tenant).snapshot()["messages_sent"] == 0
