"""Dedupe and rate limiting. Section 1.1 VALIDATE column."""
from __future__ import annotations

import pytest

from app.runtime.errors import DuplicateEvent, RateLimited
from app.runtime.validate import enforce_rate_limit, load_tenant_config, persist_event
from app.schemas.events import Channel, InboundEvent


def _event(tenant_id: str, **kw) -> InboundEvent:
    base = dict(tenant_id=tenant_id, channel=Channel.WHATSAPP, sender_ref="+919900000001",
                body="kaal aavi sakay?")
    base.update(kw)
    return InboundEvent(**base)


def test_same_external_id_is_rejected_by_the_database(scope, tenant, session):
    persist_event(scope, _event(tenant.tenant_id, external_id="wamid.1"))
    session.commit()
    with pytest.raises(DuplicateEvent):
        persist_event(scope, _event(tenant.tenant_id, external_id="wamid.1"))


def test_identical_content_without_an_id_is_deduped_in_window(scope, tenant, session):
    persist_event(scope, _event(tenant.tenant_id, channel=Channel.WEB_FORM))
    session.commit()
    with pytest.raises(DuplicateEvent):
        persist_event(scope, _event(tenant.tenant_id, channel=Channel.WEB_FORM))


def test_different_body_is_not_a_duplicate(scope, tenant, session):
    persist_event(scope, _event(tenant.tenant_id, channel=Channel.WEB_FORM))
    session.commit()
    row = persist_event(scope, _event(tenant.tenant_id, channel=Channel.WEB_FORM,
                                      body="kal aavu chu"))
    assert row.id is not None


def test_rate_limit_trips(scope, tenant, monkeypatch):
    import app.runtime.validate as v

    monkeypatch.setattr(v.settings, "rate_limit_messages", 3)
    for _ in range(3):
        enforce_rate_limit(scope, "+919900000009")
    with pytest.raises(RateLimited):
        enforce_rate_limit(scope, "+919900000009")


def test_unknown_config_keys_do_not_take_a_tenant_offline(session, tenant):
    from app.models import Tenant

    row = session.get(Tenant, tenant.tenant_id)
    row.config = {**row.config, "some_legacy_key": "whatever"}
    session.commit()
    cfg = load_tenant_config(session, tenant.tenant_id)
    assert cfg.business_type == "dentist"
