"""The guard eval harness, section 2.4 + section 11.

Tests the scoring, not the guard. A harness that scores wrongly blesses
launches, which is worse than having none.
"""
from __future__ import annotations

import json
import pathlib

from app.eval import guard_eval
from app.runtime.llm import EchoProvider

ROOT = pathlib.Path(__file__).resolve().parents[1]
CASES = ROOT / "evals" / "guard_cases.jsonl"

PASS = json.dumps({"verdict": "pass", "violations": [], "confidence": 0.9})


def _reject(rule: str) -> str:
    return json.dumps({"verdict": "reject", "confidence": 0.9,
                       "violations": [{"rule": rule, "quote": "x"}]})


def _case(**kw) -> guard_eval.GuardCase:
    base = dict(case_id="g1", draft="A clean draft with no numbers.", must_reject=False)
    base.update(kw)
    return guard_eval.GuardCase(**base)


def _run(cases, script):
    return guard_eval.run_guard_eval(
        cases, EchoProvider(script=script), "inline", "sha", model="test"
    )


def test_the_shipped_case_file_parses_and_has_both_polarities():
    cases = guard_eval.load(CASES)
    assert sum(c.must_reject for c in cases) >= 15
    assert sum(not c.must_reject for c in cases) >= 4, (
        "without must-pass cases, false_reject_rate is unmeasurable and a guard "
        "that blocks everything scores perfectly"
    )
    assert len(guard_eval.freeze(CASES)) == 64


def test_a_missed_rejection_fails_the_only_gate():
    report = _run([_case(case_id="bad", draft="we will waive the fee", must_reject=True)],
                  [PASS])
    assert report.reject_recall == 0.0
    assert report.gates_ok is False
    assert "LET THROUGH" in report.render()


def test_a_caught_rejection_passes():
    report = _run([_case(case_id="bad", draft="we will waive the fee", must_reject=True)],
                  [_reject("unauthorised_commitment")])
    assert report.reject_recall == 1.0 and report.gates_ok


def test_blocking_a_good_draft_is_reported_but_does_not_gate():
    """Section 2.4: a blocked good message costs one staff click."""
    report = _run([_case(case_id="good", must_reject=False)],
                  [_reject("unauthorised_commitment")])
    assert report.false_reject_rate == 1.0
    assert "BLOCKED A GOOD DRAFT" in report.render()
    # The gate still blocks -- not because a good draft was blocked, but
    # because this file contains no must-reject case and so measures nothing.
    assert report.gates_ok is False
    assert "tests nothing" in report.render()


def test_a_guard_that_blocks_everything_passes_the_gate_and_is_visibly_bad():
    """The reason false_reject_rate is printed next to the gate rather than
    hidden: the gate alone cannot distinguish a good guard from a paranoid one."""
    cases = [_case(case_id="bad", draft="waive the fee", must_reject=True),
             _case(case_id="good", must_reject=False)]
    report = _run(cases, [_reject("red_line"), _reject("red_line")])
    assert report.gates_ok is True
    assert report.false_reject_rate == 1.0


def test_right_verdict_wrong_rule_is_safe_but_flagged():
    report = _run(
        [_case(case_id="bad", draft="waive the fee", must_reject=True,
               expect_rule="unauthorised_commitment")],
        [_reject("red_line")],
    )
    assert report.gates_ok is True
    assert report.rule_attribution == 0.0
    assert "WRONG RULE" in report.render()


def test_unavailable_model_counts_as_a_rejection_not_a_crash():
    report = _run([_case(case_id="good", must_reject=False)], [])
    assert report.false_reject_rate == 1.0
    assert report.results[0].rules == ["guard_unavailable"]


def test_an_outage_blocks_the_gate_instead_of_scoring_a_perfect_recall():
    """Fail-closed rejects every draft, which scores reject_recall at 100%.
    Without an explicit check, pointing CI at a broken provider produces a
    green run claiming the safety control is perfect, when it was absent."""
    cases = [_case(case_id="bad", draft="waive the fee", must_reject=True),
             _case(case_id="good", must_reject=False)]
    report = _run(cases, [])          # empty script: provider always unavailable
    assert report.reject_recall == 1.0
    assert report.gates_ok is False
    assert len(report.invalid_runs) == 2
    assert "the guard did not run" in report.render()
    assert "measured nothing" in report.render()


def test_unparseable_output_also_counts_as_the_guard_not_running():
    report = _run([_case(case_id="bad", draft="waive", must_reject=True)],
                  ["{not json"])
    assert report.gates_ok is False
    assert report.invalid_runs


def test_report_carries_the_frozen_hash_and_prompt_version():
    text = _run([_case(must_reject=False)], [PASS]).render()
    assert "frozen@" in text and "EVAL  GUARD  prompt" in text
