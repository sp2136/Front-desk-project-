"""The review gate and the one write path."""
from __future__ import annotations

import pytest

from app.models import Decision, OutboundMessage
from app.runtime import review
from app.runtime.caps import CapGuard
from app.runtime.review import DecisionKind


def _decision(scope, session, **kw) -> Decision:
    base = dict(kind=DecisionKind.QUEUED_FOR_HUMAN, draft="Kal 6 vagye available che.",
                outcome="open")
    base.update(kw)
    row = scope.add(Decision(**base))
    session.commit()
    return row


def test_unapproved_decision_cannot_be_sent(scope, session, tenant):
    d = _decision(scope, session)
    with pytest.raises(ValueError):
        review.enqueue_outbound(scope, CapGuard(scope, tenant), d,
                                channel="whatsapp", to_ref="+9199")


def test_approved_decision_sends_and_counts_against_the_message_cap(scope, session, tenant):
    d = _decision(scope, session)
    review.approve(scope, d.id, approver="front_desk_01")
    msg = review.enqueue_outbound(scope, CapGuard(scope, tenant), d,
                                  channel="whatsapp", to_ref="+9199")
    session.commit()
    assert isinstance(msg, OutboundMessage)
    assert CapGuard(scope, tenant).snapshot()["messages_sent"] == 1


def test_edit_distance_is_recorded(scope, session, tenant):
    d = _decision(scope, session, draft="Kal 6 vagye available che.")
    row = review.approve(scope, d.id, approver="front_desk_01",
                         sent_text="Kal 6 vagye available chhe.")
    assert 0 < row.edit_distance_pct < 20


def test_double_approval_is_refused(scope, session, tenant):
    d = _decision(scope, session)
    review.approve(scope, d.id, approver="a")
    with pytest.raises(ValueError):
        review.approve(scope, d.id, approver="b")


def test_empty_draft_is_never_sent(scope, session, tenant):
    d = _decision(scope, session, draft="   ")
    review.approve(scope, d.id, approver="a")
    with pytest.raises(ValueError):
        review.enqueue_outbound(scope, CapGuard(scope, tenant), d,
                                channel="whatsapp", to_ref="+9199")
