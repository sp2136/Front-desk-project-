"""Audit chain integrity, section 1.3."""
from __future__ import annotations

from app.models import AuditLog
from app.runtime import audit


def test_chain_verifies_and_detects_tampering(scope, session, tenant):
    for i in range(4):
        audit.record(scope, actor="runtime", action="agent_run",
                     subject_type="agent_run", subject_id=i, data={"i": i})
    session.commit()
    ok, broken = audit.verify_chain(scope)
    assert ok and broken is None

    row = scope.all(AuditLog)[2]
    row.data = {"i": "edited after the fact"}
    session.commit()
    ok, broken = audit.verify_chain(scope)
    assert not ok and broken == row.id
