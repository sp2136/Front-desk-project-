"""End-to-end pipeline behaviour, including the section 2.2 retry rule."""
from __future__ import annotations

import json

import pytest

from app.models import AgentRun
from app.prompts import A1_VERSION
from app.runtime import queue
from app.runtime.llm import EchoProvider, NullProvider
from app.runtime.pipeline import Pipeline
from app.runtime.prompts import store
from app.runtime.review import DecisionKind

A1_GOOD = json.dumps({
    "intent": "book", "service_id": "svc_cleaning", "service_guess": None,
    "raw_complaint_text": None, "language": "gu-Latn",
    "customer": {"known": False, "id": None, "name": None},
    "time_window": {"earliest": None, "latest": None, "preferred_days": [],
                    "part_of_day": "evening"},
    "blockers": [], "confidence": 0.91, "escalate": False, "reason": None, "evidence": [],
})

A1_MALFORMED = '{"intent": "book", "confidence": 3.5}'


@pytest.fixture
def no_a1_prompt():
    """Temporarily blank A1's body, to prove the empty-body guard still holds
    now that a real body ships."""
    original = store._bodies["A1"]
    store.put("A1", "0.0.0-unwritten", "", language_block=True)
    yield
    store._bodies["A1"] = original


def _job(scope, session):
    job = queue.enqueue(scope, agent_id="A1", dedupe_key="whatsapp:wamid.test",
                        payload={"event": {"body": "kaal aavi sakay?"}})
    session.commit()
    return job


def test_refuses_an_agent_with_no_prompt_body(scope, session, tenant, no_a1_prompt):
    job = _job(scope, session)
    result = Pipeline(EchoProvider(script=[A1_GOOD])).run(scope, job)
    assert result.stopped == "agent_not_enabled"
    assert "no prompt body" in result.detail


def test_agent_not_in_agents_enabled_is_refused(session):
    from app.db import TenantScope
    from tests.conftest import make_tenant

    make_tenant(session, tenant_id="t_off", agents_enabled=[])
    scope = TenantScope(session, "t_off")
    job = _job(scope, session)
    result = Pipeline(EchoProvider(script=[A1_GOOD])).run(scope, job)
    assert result.stopped == "agent_not_enabled"


def test_null_provider_stops_the_pipeline_cleanly(scope, session, tenant):
    job = _job(scope, session)
    result = Pipeline(NullProvider()).run(scope, job)
    assert result.stopped == "model_unavailable"
    # A stop is never a silent drop: it becomes a visible open decision.
    assert result.decision is not None
    assert result.decision.runtime_stop == "model_unavailable"


def test_happy_path_records_everything_section_1_4_asks_for(
    scope, session, tenant
):
    job = _job(scope, session)
    result = Pipeline(EchoProvider(script=[A1_GOOD])).run(scope, job)
    session.commit()

    assert result.ok
    assert result.envelope.intent == "book"
    run = scope.all(AgentRun)[0]
    assert run.valid
    assert run.prompt_version == A1_VERSION
    assert run.prompt_sha256 and run.toolbelt_version
    assert run.input_tokens > 0 and run.output_tokens > 0
    # A1 is internal triage: it drafts nothing, so there is nothing to approve.
    # The decision is recorded for traceability and closed immediately rather
    # than sitting in the staff queue.
    assert result.decision.kind == DecisionKind.NO_ACTION
    assert result.decision.outcome == "closed"


def test_malformed_output_retries_once_then_succeeds(scope, session, tenant):
    job = _job(scope, session)
    result = Pipeline(EchoProvider(script=[A1_MALFORMED, A1_GOOD])).run(scope, job)
    session.commit()

    assert result.ok
    runs = sorted(scope.all(AgentRun), key=lambda r: r.attempt)
    assert [r.attempt for r in runs] == [1, 2]
    assert runs[0].valid is False and runs[0].validation_error
    assert runs[1].valid is True


def test_malformed_twice_escalates(scope, session, tenant):
    job = _job(scope, session)
    result = Pipeline(EchoProvider(script=[A1_MALFORMED, A1_MALFORMED])).run(scope, job)
    assert result.stopped == "schema_invalid"


def test_low_confidence_is_escalated_by_the_runtime_not_the_prompt(
    scope, session, tenant
):
    low = json.loads(A1_GOOD)
    low["confidence"] = 0.4
    job = _job(scope, session)
    result = Pipeline(EchoProvider(script=[json.dumps(low)])).run(scope, job)
    assert result.envelope.escalate is True
    assert result.envelope.reason == "low_confidence"
    assert result.decision.kind == DecisionKind.ESCALATED


def test_complaint_can_never_be_auto_sent(scope, session, tenant):
    """Section 4 / A4 whitelist: complaint is 'Never'."""
    payload = json.loads(A1_GOOD)
    payload.update({"intent": "complaint", "escalate": True, "reason": "sentiment_risk",
                    "raw_complaint_text": "service kharab hato"})
    job = _job(scope, session)
    result = Pipeline(EchoProvider(script=[json.dumps(payload)])).run(scope, job)
    assert result.decision.kind == DecisionKind.ESCALATED
