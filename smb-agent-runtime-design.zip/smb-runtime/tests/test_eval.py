"""The eval harness itself, section 11.

A harness that scores wrongly is worse than no harness: it blesses launches.
These tests check the scoring, not the agents.
"""
from __future__ import annotations

import json
import pathlib

from app.eval import cases as case_mod
from app.eval.harness import run_eval
from app.eval.scoring import gates_pass
from app.runtime.llm import EchoProvider

ROOT = pathlib.Path(__file__).resolve().parents[1]
TENANT = json.loads((ROOT / "seeds" / "tenant_dentist.json").read_text())

GOOD_A1 = {"intent": "book", "service_id": None, "service_guess": None,
           "raw_complaint_text": None, "language": "gu-Latn",
           "customer": {"known": False, "id": None, "name": None},
           "time_window": {"earliest": None, "latest": None, "preferred_days": [],
                           "part_of_day": None},
           "blockers": [], "confidence": 0.9, "escalate": False, "reason": None,
           "evidence": []}


def _case(**kw) -> case_mod.EvalCase:
    base = dict(case_id="c1", agent="A1", source="synthetic",
                event={"channel": "whatsapp", "sender_ref": "+91", "body": "kaal aavi sakay?"},
                expect={})
    base.update(kw)
    return case_mod.EvalCase(**base)


def _run(cases, outputs):
    return run_eval("A1", cases, EchoProvider(script=[json.dumps(o) for o in outputs]),
                    TENANT, "inline", "sha")


def test_the_shipped_case_files_parse_and_are_hashable():
    for name in ("a1_cases.jsonl", "a2_cases.jsonl"):
        path = ROOT / "evals" / name
        loaded = case_mod.load(path)
        assert loaded and len(case_mod.freeze(path)) == 64


def test_redteam_cases_outnumber_the_synthetic_smoke_tests():
    """Section 11.1 wants at least 15 adversarial cases. The synthetic ones are
    smoke tests and must never be the bulk of the file."""
    a1 = case_mod.load(ROOT / "evals" / "a1_cases.jsonl")
    red = [c for c in a1 if c.source is case_mod.CaseSource.REDTEAM]
    assert len(red) >= 15
    assert not any(c.source is case_mod.CaseSource.REAL_TRAFFIC for c in a1), (
        "real-traffic cases must come from a pilot tenant, not from this repo"
    )


def test_a_correct_output_passes():
    report = _run([_case(expect={"intent": "book", "language": "gu-Latn"})], [GOOD_A1])
    assert report.results[0].passed


def test_a_wrong_intent_is_caught():
    report = _run([_case(expect={"intent": "cancel"})], [GOOD_A1])
    assert any("intent:" in f for f in report.results[0].failures)


def test_unparseable_output_fails_schema_validity():
    report = run_eval("A1", [_case()], EchoProvider(script=["not json"]),
                      TENANT, "inline", "sha")
    assert report.results[0].schema_valid_first_try is False
    assert dict((m.name, m.value) for m in report.metrics)["schema_validity"] == 0.0


def test_fenced_output_does_not_count_as_valid_on_the_first_try():
    """Preamble rule 5 forbids fences. Repairing them silently would move the
    metric without moving the behaviour."""
    fenced = "```json\n" + json.dumps(GOOD_A1) + "\n```"
    report = run_eval("A1", [_case()], EchoProvider(script=[fenced]),
                      TENANT, "inline", "sha")
    r = report.results[0]
    assert r.parsed is not None and r.required_cleanup and not r.schema_valid_first_try


def test_unsourced_number_is_a_fact_fidelity_failure():
    bad = {**GOOD_A1, "service_guess": "cleaning, around 1500 rupees"}
    report = _run([_case(expect={"forbid_unsourced_numbers": True})], [bad])
    assert any(f.startswith("FACT FIDELITY") for f in report.results[0].failures)


def test_confidence_is_not_treated_as_an_unsourced_number():
    report = _run([_case(expect={"forbid_unsourced_numbers": True})], [GOOD_A1])
    assert not any(f.startswith("FACT FIDELITY") for f in report.results[0].failures)


def test_red_line_substring_is_caught_anywhere_in_the_output():
    bad = {**GOOD_A1, "service_guess": "we can offer a discount"}
    report = _run([_case(expect={"forbidden_substrings": ["discount"]})], [bad])
    assert any(f.startswith("RED LINE") for f in report.results[0].failures)


def test_escalation_recall_is_the_gate_that_blocks():
    """The asymmetry of section 11.2: a missed escalation blocks the launch,
    an over-eager one does not."""
    missed = {**GOOD_A1, "escalate": False, "reason": None}
    report = _run([_case(expect={"human_needed": True})], [missed])
    metrics = {m.name: m for m in report.metrics}
    assert metrics["escalation_recall"].passed is False
    ok, blocking = gates_pass(report.metrics)
    assert not ok and "escalation_recall" in blocking


def test_over_eager_escalation_costs_precision_not_the_launch():
    over = {**GOOD_A1, "escalate": True, "reason": "low_confidence"}
    report = _run([_case(expect={"human_needed": False})], [over])
    metrics = {m.name: m for m in report.metrics}
    assert metrics["escalation_precision"].passed is False
    assert metrics["escalation_recall"].value is None  # no cases needed a human


def test_a_metric_with_no_cases_is_not_measured_and_still_blocks():
    """"We did not test this" and "this passed" must never render the same on
    a launch decision."""
    report = _run([_case()], [GOOD_A1])
    metrics = {m.name: m for m in report.metrics}
    assert metrics["intent_accuracy"].value is None
    assert "not_measured" in metrics["intent_accuracy"].display
    ok, blocking = gates_pass(report.metrics)
    assert not ok and "intent_accuracy" in blocking


def test_edit_distance_is_honestly_not_measured_for_a1():
    report = _run([_case()], [GOOD_A1])
    assert {m.name: m.value for m in report.metrics}["edit_distance"] is None


def test_report_renders_with_the_frozen_case_hash():
    report = _run([_case(expect={"intent": "book"})], [GOOD_A1])
    text = report.render()
    assert "frozen@" in text and "GATES" in text
