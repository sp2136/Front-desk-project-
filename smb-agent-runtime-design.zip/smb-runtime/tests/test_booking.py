"""Soft locks, booking commits, and the concurrency §1.3 is about.

"Two concurrent bookings must collide at the database, not in a prompt."
"""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from app.models import Resource, Slot
from app.runtime.booking import (
    SlotUnavailable,
    acquire_soft_lock,
    available_slots,
    commit_booking,
    release_soft_lock,
    sweep_expired_locks,
)

# Anchored to the real clock. Every call in this file passes now=NOW, so a
# pinned date survived longer here than in test_reminders.py -- but it is the
# same trap, and the point of removing it is that it cannot be sprung by a
# future test that forgets the argument.
NOW = datetime.now(UTC).replace(microsecond=0)


@pytest.fixture
def slots(scope, session):
    scope.add(Resource(id="r1", name="Dr Shah", skills=["svc_cleaning"]))
    scope.add(Resource(id="r2", name="Dr Mehta", skills=["svc_cleaning"]))
    scope.add(Resource(id="r3", name="Dr Rao", skills=["svc_whitening"]))
    made = []
    for i, (res, hours) in enumerate(
        [("r1", 4), ("r1", 28), ("r2", 5), ("r2", 30)], start=1
    ):
        made.append(scope.add(Slot(
            id=f"s{i}", resource_id=res, service_id="svc_cleaning",
            starts_at=NOW + timedelta(hours=hours), duration_min=45,
        )))
    session.commit()
    return made


def test_availability_lists_open_slots(scope, slots):
    assert {s.id for s in available_slots(scope, service_id="svc_cleaning", now=NOW)} == {
        "s1", "s2", "s3", "s4"
    }


def test_a_resource_without_the_skill_is_not_offered(scope, session, slots):
    """A slot is a time on a resource's calendar; whether it can take a given
    service depends on that resource's skills."""
    scope.add(Slot(id="s9", resource_id="r3", service_id=None,
                   starts_at=NOW + timedelta(hours=6), duration_min=45))
    session.commit()
    cleaning = {s.id for s in available_slots(scope, service_id="svc_cleaning", now=NOW)}
    whitening = {s.id for s in available_slots(scope, service_id="svc_whitening", now=NOW)}
    assert "s9" not in cleaning
    assert whitening == {"s9"}


def test_two_concurrent_acquires_collide_at_the_database(scope, session, slots):
    """The decisive test. One conditional UPDATE each; the affected-row count
    is the answer, so there is no read-then-write window to race through."""
    first = acquire_soft_lock(scope, "s1", ttl_s=600, now=NOW)
    session.commit()
    with pytest.raises(SlotUnavailable):
        acquire_soft_lock(scope, "s1", ttl_s=600, now=NOW)
    assert first.token


def test_a_locked_slot_disappears_from_availability(scope, session, slots):
    acquire_soft_lock(scope, "s1", ttl_s=600, now=NOW)
    session.commit()
    assert "s1" not in {s.id for s in available_slots(scope, now=NOW)}


def test_an_expired_lock_returns_the_slot_without_any_sweeper(scope, session, slots):
    """A customer who stops replying must not hold a slot off the market."""
    acquire_soft_lock(scope, "s1", ttl_s=60, now=NOW)
    session.commit()
    later = NOW + timedelta(minutes=5)
    assert "s1" in {s.id for s in available_slots(scope, now=later)}
    # And another caller can take it.
    assert acquire_soft_lock(scope, "s1", ttl_s=600, now=later).token


def test_releasing_a_lock_frees_the_slot(scope, session, slots):
    lock = acquire_soft_lock(scope, "s2", ttl_s=600, now=NOW)
    session.commit()
    assert release_soft_lock(scope, lock) is True
    assert "s2" in {s.id for s in available_slots(scope, now=NOW)}


def test_commit_turns_a_lock_into_a_booking(scope, session, slots):
    lock = acquire_soft_lock(scope, "s1", ttl_s=600, now=NOW)
    booking = commit_booking(scope, lock, customer_ref="+919812345678",
                             customer_name="Mehul", language="gu-Latn", now=NOW)
    session.commit()
    assert booking.state == "confirmed" and booking.visit_count == 1
    assert scope.one_or_none(Slot, Slot.id == "s1").booking_id == booking.id
    assert "s1" not in {s.id for s in available_slots(scope, now=NOW)}


def test_an_expired_lock_cannot_be_committed(scope, session, slots):
    """Checked in the UPDATE's WHERE clause, so a lock that expired a
    millisecond ago cannot be committed by a caller who read it just before."""
    lock = acquire_soft_lock(scope, "s1", ttl_s=60, now=NOW)
    session.commit()
    with pytest.raises(SlotUnavailable):
        commit_booking(scope, lock, customer_ref="+91", now=NOW + timedelta(minutes=5))


def test_a_stale_token_cannot_commit_somebody_elses_slot(scope, session, slots):
    lock = acquire_soft_lock(scope, "s1", ttl_s=60, now=NOW)
    session.commit()
    later = NOW + timedelta(minutes=5)
    acquire_soft_lock(scope, "s1", ttl_s=600, now=later)   # someone else takes it
    session.commit()
    with pytest.raises(SlotUnavailable):
        commit_booking(scope, lock, customer_ref="+91", now=later)


def test_a_booked_slot_can_never_be_relocked(scope, session, slots):
    lock = acquire_soft_lock(scope, "s1", ttl_s=600, now=NOW)
    commit_booking(scope, lock, customer_ref="+91", now=NOW)
    session.commit()
    far = NOW + timedelta(days=1)
    with pytest.raises(SlotUnavailable):
        acquire_soft_lock(scope, "s1", ttl_s=600, now=far)


def test_visit_count_increments_for_a_returning_customer(scope, session, slots):
    for slot_id in ("s1", "s3"):
        lock = acquire_soft_lock(scope, slot_id, ttl_s=600, now=NOW)
        b = commit_booking(scope, lock, customer_ref="+919812345678", now=NOW)
        session.commit()
    assert b.visit_count == 2


def test_sweeper_is_tidiness_not_correctness(scope, session, slots):
    acquire_soft_lock(scope, "s1", ttl_s=60, now=NOW)
    session.commit()
    later = NOW + timedelta(minutes=5)
    # Already available before any sweep runs.
    assert "s1" in {s.id for s in available_slots(scope, now=later)}
    assert sweep_expired_locks(scope, now=later) == 1
    assert sweep_expired_locks(scope, now=later) == 0


def test_locks_are_tenant_scoped(scope, session, slots):
    from app.db import TenantScope
    from tests.conftest import make_tenant

    make_tenant(session, tenant_id="t_rival", tenant_name="Rival Clinic")
    rival = TenantScope(session, "t_rival")
    # The rival cannot see or lock another tenant's slot.
    assert available_slots(rival, now=NOW) == []
    with pytest.raises(SlotUnavailable):
        acquire_soft_lock(rival, "s1", ttl_s=600, now=NOW)


def test_a_service_agnostic_slot_needs_a_service_at_commit(scope, session, slots):
    """A slot is a time on a calendar; a booking is a time plus the service
    being performed. Defaulting the service would mean guessing."""
    scope.add(Slot(id="s10", resource_id="r1", service_id=None,
                   starts_at=NOW + timedelta(hours=8), duration_min=45))
    session.commit()
    lock = acquire_soft_lock(scope, "s10", ttl_s=600, now=NOW)
    with pytest.raises(ValueError, match="explicit service_id"):
        commit_booking(scope, lock, customer_ref="+91", now=NOW)
    b = commit_booking(scope, lock, customer_ref="+91",
                       service_id="svc_cleaning", now=NOW)
    assert b.service_id == "svc_cleaning"


def test_committing_a_booking_records_the_customer(scope, session, slots):
    """A booking is the moment the business learns a customer exists. Without
    a customer record, A7's recall sweep iterates an empty table and finds
    nobody due -- indistinguishable from "nobody needs a nudge"."""
    from app.models import Customer

    lock = acquire_soft_lock(scope, "s1", ttl_s=600, now=NOW)
    commit_booking(scope, lock, customer_ref="+919812345678",
                   service_id="svc_cleaning", customer_name="Mehul",
                   language="gu-Latn", now=NOW)
    session.commit()
    c = scope.all(Customer)[0]
    assert c.customer_ref == "+919812345678"
    assert c.name == "Mehul" and c.language == "gu-Latn"
    assert c.opt_out is False


def test_availability_can_be_sampled_across_days(scope, session):
    """Taking the first N slots chronologically is not the same as showing what
    is open: a venue with 24 open hours a day returns two and a half days
    inside a flat limit, so A3 is told to spread across days while being handed
    almost one day."""
    from app.models import Resource, Slot
    from app.runtime.tool_impls import get_availability

    scope.add(Resource(id="rw", name="Court 1", skills=["svc_court_hire"]))
    for day in range(1, 6):
        for hour in range(8, 20):
            scope.add(Slot(
                id=f"w{day}-{hour}", resource_id="rw", service_id=None,
                starts_at=(NOW + timedelta(days=day)).replace(
                    hour=hour, minute=0, second=0),
                duration_min=60))
    session.commit()

    flat = get_availability(scope, service_id="svc_court_hire", limit=12)
    spread = get_availability(scope, service_id="svc_court_hire", limit=12,
                              per_day=2, horizon_days=10)
    days_flat = {s["starts_at"][:10] for s in flat}
    days_spread = {s["starts_at"][:10] for s in spread}
    # The exact day count under a flat limit depends on the timezone boundary,
    # so the claim under test is the comparison, not an absolute.
    assert len(days_spread) > len(days_flat), (
        f"sampling must span more days than a flat limit "
        f"({len(days_spread)} vs {len(days_flat)})"
    )
    assert len(days_spread) >= 5, "sampling must reach across the horizon"
    assert len(spread) <= 12, "the limit still caps the total"
