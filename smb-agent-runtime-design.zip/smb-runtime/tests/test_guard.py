"""The guard pass, section 2.4.

The asymmetry under test throughout: "A blocked good message costs one staff
click. A sent bad message costs the client relationship."
"""
from __future__ import annotations

import json

from app.runtime.guard import (
    allowed_scripts,
    deterministic_guard,
    model_guard,
    run_guard,
    scripts_in,
)
from app.runtime.llm import EchoProvider, NullProvider
from app.runtime.review import DecisionKind, decide
from app.runtime.sourcefacts import SourceFacts
from app.schemas.agents import GuardOutput, GuardVerdict
from app.schemas.envelope import Envelope

FACTS = SourceFacts().add(
    "service_catalogue",
    [{"id": "svc_cleaning", "name": "Scaling and polishing", "duration_min": 45,
      "published_price": 1500, "price_qualifier": "starting from"}],
)
PASS_JSON = json.dumps({"verdict": "pass", "violations": [], "confidence": 0.9})


def _ok(**kw) -> Envelope:
    base = dict(confidence=0.9, escalate=False, reason=None)
    base.update(kw)
    return Envelope(**base)


# --- rule layer -----------------------------------------------------------

def test_unsourced_number_is_rejected_with_an_actionable_quote():
    out = deterministic_guard("Cleaning is 2500 rupees, takes 45 minutes.", FACTS)
    assert out.verdict is GuardVerdict.REJECT
    v = next(v for v in out.violations if v.rule == "unsourced_number")
    # The quote is the whole sentence, not the bare digits: a reviewer should
    # not have to search the draft for what went wrong.
    assert "2500" in v.quote and "Cleaning is" in v.quote


def test_a_sourced_number_passes_the_rule_layer():
    out = deterministic_guard("Scaling starts from 1500 and takes 45 minutes.", FACTS)
    assert out.verdict is GuardVerdict.PASS
    # A rule-layer pass is deliberately low confidence: it clears a narrow set
    # of conditions and says nothing about the rest.
    assert out.confidence == 0.5


def test_credential_request_over_a_messaging_channel_is_rejected():
    out = deterministic_guard("Please send your aadhaar number here to confirm.", FACTS)
    assert any(v.rule == "credential_request" for v in out.violations)


def test_internal_information_is_rejected():
    out = deterministic_guard("Our cost price on this is lower, so we can help.", FACTS)
    assert any(v.rule == "internal_information" for v in out.violations)


def test_script_outside_the_tenant_languages_is_rejected():
    out = deterministic_guard("Здравствуйте, запишитесь на приём", FACTS,
                              languages=["gu", "gu-Latn", "en"])
    assert any(v.rule == "wrong_language" for v in out.violations)


def test_gujarati_script_passes_for_a_tenant_that_configured_it():
    out = deterministic_guard("કાલે સાંજે આવી શકાય", FACTS, languages=["gu", "en"])
    assert out.verdict is GuardVerdict.PASS


def test_roman_script_gujarati_is_not_mistaken_for_a_foreign_script():
    """gu-Latn is Latin script. Treating it as foreign would reject most of the
    traffic this product exists to handle."""
    out = deterministic_guard("kaal saanje aavi sakay", FACTS, languages=["gu-Latn"])
    assert out.verdict is GuardVerdict.PASS


def test_script_detection_and_allowed_scripts():
    assert scripts_in("hello કાલે नमस्ते") == {"LATIN", "GUJARATI", "DEVANAGARI"}
    assert allowed_scripts(["gu", "hi-Latn"]) == {"GUJARATI", "LATIN"}
    assert scripts_in("1500 — 45% (!)") == set()   # digits and punctuation ignored


# --- model layer ----------------------------------------------------------

def test_an_unavailable_guard_rejects_rather_than_waving_through():
    # No digits in the draft, so the rule layer passes and the model layer is
    # actually reached -- which is what this test is about.
    out = run_guard(NullProvider(), "Kal saanje available che.", FACTS, [], ["gu-Latn"])
    assert out.verdict is GuardVerdict.REJECT
    assert out.violations[0].rule == "guard_unavailable"


def test_unparseable_guard_output_rejects():
    out = run_guard(EchoProvider(script=["not json at all"]),
                    "Kal available che.", FACTS, [], ["gu-Latn"])
    assert out.verdict is GuardVerdict.REJECT
    assert out.violations[0].rule == "guard_output_unparseable"


def test_the_model_sees_the_draft_facts_and_red_lines():
    seen = {}
    provider = EchoProvider(script=[PASS_JSON],
                            on_call=lambda sy, u: seen.update(system=sy, user=u))
    run_guard(provider, "Scaling starts from 1500.", FACTS,
              ["no_clinical_advice"], ["en"])
    assert "<draft>" in seen["user"] and "<source_facts>" in seen["user"]
    assert "no_clinical_advice" in seen["user"]
    assert "release gate" in seen["system"]


def test_the_guard_prompt_carries_no_envelope_contract():
    """The guard returns no envelope. Appending section 2.2's contract would
    contradict its own OUTPUT block and invite it to emit escalate/evidence."""
    seen = {}
    EchoProvider(script=[PASS_JSON], on_call=lambda sy, u: seen.update(system=sy))
    out = model_guard(EchoProvider(script=[PASS_JSON],
                                   on_call=lambda sy, u: seen.update(system=sy)),
                      "fine", FACTS, [], ["en"])
    assert out.verdict is GuardVerdict.PASS
    assert "escalate" not in seen["system"]
    assert "You never send, book, cancel" not in seen["system"]


def test_rule_layer_short_circuits_before_paying_for_the_model():
    """Arithmetic already proved the number is unsourced; a second opinion adds
    nothing. The echo script is empty, so a model call would raise."""
    out = run_guard(EchoProvider(script=[]), "It costs 9999.", FACTS, [], ["en"])
    assert out.verdict is GuardVerdict.REJECT
    assert out.violations[0].rule == "unsourced_number"


# --- the invariant --------------------------------------------------------

def test_a_whitelisted_draft_with_no_guard_verdict_falls_back_to_a_human(
    scope, session, tenant
):
    """Section 2.4: the guard sits between ANY draft and ANY customer-facing
    send. Turning the guard off buys human review, never ungated sending."""
    cfg = tenant.model_copy(update={"guard_pass_required_for": ["none"],
                                    "auto_send_whitelist": ["location_hours"]})
    d = decide(scope, cfg, run_id=None, envelope=_ok(),
               draft="We open at 10am.", intent="location_hours",
               guard=None, customer_facing=True)
    assert d.kind == DecisionKind.QUEUED_FOR_HUMAN


def test_a_guard_pass_lets_a_whitelisted_draft_auto_send(scope, session, tenant):
    cfg = tenant.model_copy(update={"auto_send_whitelist": ["location_hours"]})
    g = GuardOutput(verdict=GuardVerdict.PASS, violations=[], confidence=0.9)
    d = decide(scope, cfg, run_id=None, envelope=_ok(),
               draft="We open at 10am.", intent="location_hours",
               guard=g, customer_facing=True, a2_level="routine")
    assert d.kind == DecisionKind.AUTO_SEND


def test_a_guard_reject_blocks_even_a_whitelisted_intent(scope, session, tenant):
    cfg = tenant.model_copy(update={"auto_send_whitelist": ["location_hours"]})
    g = GuardOutput(verdict=GuardVerdict.REJECT, confidence=1.0,
                    violations=[{"rule": "unsourced_number", "quote": "2500"}])
    d = decide(scope, cfg, run_id=None, envelope=_ok(),
               draft="We open at 10am and cleaning is 2500.", intent="location_hours",
               guard=g, customer_facing=True, a2_level="routine")
    assert d.kind == DecisionKind.BLOCKED
    assert d.guard_verdict == "reject"
    assert d.guard_violations["violations"][0]["rule"] == "unsourced_number"


# --- source facts ---------------------------------------------------------

def test_empty_source_facts_makes_every_number_unsourced():
    out = deterministic_guard("Come at 6pm. It costs 500.", SourceFacts())
    assert out.verdict is GuardVerdict.REJECT
    # Two separate sentences, so two distinct things for a reviewer to fix.
    assert len([v for v in out.violations if v.rule == "unsourced_number"]) == 2


def test_several_unsourced_numbers_in_one_sentence_are_one_violation():
    """One sentence to fix is one row in the queue, not three."""
    out = deterministic_guard("We are open 10:00 to 19:00 tomorrow.", SourceFacts())
    assert len(out.violations) == 1


def test_source_facts_are_the_runtime_s_retrievals_not_the_agent_s_claims():
    """An agent that invents a price also invents the evidence line for it, so
    checking a draft against its own evidence array is circular."""
    facts = SourceFacts().add("faq", [{"id": "faq_1", "answer": "We open at 10am"}])
    assert "faq_1" in facts.render()
    assert deterministic_guard("We open at 10am.", facts).verdict is GuardVerdict.PASS
