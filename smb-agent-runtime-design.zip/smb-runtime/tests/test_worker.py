"""The worker loop: lease, run, chain, release."""
from __future__ import annotations

import json

from app.db import SessionLocal, TenantScope
from app.models import Decision, Job
from app.runtime import queue
from app.runtime.llm import EchoProvider
from app.runtime.pipeline import Pipeline
from app.workers.runner import run_once

A1_GOOD = json.dumps({
    "intent": "book", "service_id": "svc_cleaning", "service_guess": None,
    "raw_complaint_text": None, "language": "gu-Latn",
    "customer": {"known": False, "id": None, "name": None},
    "time_window": {"earliest": None, "latest": None, "preferred_days": [], "part_of_day": None},
    "blockers": [], "confidence": 0.9, "escalate": False, "reason": None, "evidence": [],
})
A3_GOOD = json.dumps({
    "options": [{"slot_id": "s1", "starts_at": "2026-10-20T18:00:00+05:30",
                 "resource_id": "r1", "resource_name": "Dr Shah",
                 "duration_minutes": 45}],
    "unavailable_note": None,
    "confidence": 0.9, "escalate": False, "reason": None, "evidence": [],
})
A4_GOOD = json.dumps({
    "draft": "Kal saanje chhe to 6 vagye aavi shako. Chalse?",
    "language": "gu-Latn", "intent_handled": "book", "facts_used": [],
    "missing": [], "auto_send_eligible": False,
    "confidence": 0.88, "escalate": False, "reason": None, "evidence": [],
})
A2_GOOD = json.dumps({
    "level": "routine", "matched_signals": [], "confidence": 0.88,
    "escalate": False, "reason": None, "evidence": [],
})


def test_idempotent_enqueue(scope, session, tenant):
    first = queue.enqueue(scope, agent_id="A1", dedupe_key="whatsapp:x1")
    session.commit()
    second = queue.enqueue(scope, agent_id="A1", dedupe_key="whatsapp:x1")
    assert first is not None and second is None


def test_worker_runs_the_full_a1_a2_a3_a4_chain(scope, session, tenant):
    queue.enqueue(scope, agent_id="A1", dedupe_key="whatsapp:chain",
                  payload={"event": {"body": "kaal aavi sakay?"}})
    session.commit()

    # A4's draft reaches the guard, which has no model here and so fails
    # closed -- the correct behaviour, and why the script needs no guard entry.
    pipeline = Pipeline(EchoProvider(script=[A1_GOOD, A2_GOOD, A3_GOOD, A4_GOOD]))
    assert run_once("w1", pipeline) == 1   # A1
    assert run_once("w1", pipeline) == 1   # chained A2
    assert run_once("w1", pipeline) == 1   # chained A3 (intent is book)
    assert run_once("w1", pipeline) == 1   # chained A4
    assert run_once("w1", pipeline) == 0   # queue drained

    s = SessionLocal()
    sc = TenantScope(s, tenant.tenant_id)
    jobs = {j.agent_id: j.state for j in sc.all(Job)}
    decisions = [(d.kind, d.outcome) for d in sc.all(Decision)]
    s.close()
    assert jobs == {"A1": "done", "A2": "done", "A3": "done", "A4": "done"}
    # The A4 draft is blocked rather than queued: no guard model is attached,
    # so the gate rejects. Section 2.4, default to reject when uncertain.
    assert ("blocked", "open") in decisions


def test_a_failing_job_is_retried_not_dropped(scope, session, tenant):
    queue.enqueue(scope, agent_id="A1", dedupe_key="whatsapp:boom")
    session.commit()

    class Boom(Pipeline):
        def run(self, scope, job):
            raise RuntimeError("provider exploded")

    assert run_once("w1", Boom(EchoProvider(script=[]))) == 1
    s = SessionLocal()
    sc = TenantScope(s, tenant.tenant_id)
    job = sc.all(Job)[0]
    s.close()
    assert job.state == "retry"
    assert "provider exploded" in job.last_error
