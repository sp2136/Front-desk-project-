"""Staff alerts.

Section 4 / A2: for level `immediate`, "The system will stop the automated
chain and alert staff. Do not draft any reply."

An alert is a staff-facing artefact, so it is not subject to the guard pass and
carries no customer-facing text. It deliberately contains no drafted reply and
no interpretation of the message -- only the level, the matched phrases
verbatim, and a pointer to the thread. A2's whole output surface is a level, a
list of phrases and a flag precisely so that a UI bug cannot leak a care
instruction, and the alert must not widen that surface.
"""
from __future__ import annotations

from app.models import Decision, OutboundMessage
from app.runtime import audit
from app.runtime.review import DecisionKind
from app.schemas.agents import A2Output
from app.schemas.tenant import TenantConfig


def raise_urgency_alert(scope, cfg: TenantConfig, *, run_id: int | None,
                        a2: A2Output, event: dict) -> Decision:
    """Record a priority decision and queue a staff notification."""
    signals = ", ".join(a2.matched_signals[:4]) or "no phrase recorded"
    body = (
        f"PRIORITY [{a2.level.value}] - {cfg.tenant_name}\n"
        f"From: {event.get('sender_ref', 'unknown')}\n"
        f"Channel: {event.get('channel', 'unknown')}\n"
        f"Signals: {signals}\n"
        f"Open the thread and respond directly. No automated reply was sent."
    )

    decision = scope.add(
        Decision(
            run_id=run_id,
            kind=DecisionKind.ESCALATED,
            intent="urgency_alert",
            escalation_reason=a2.reason.value if a2.reason else None,
            outcome="open",
        )
    )
    scope.flush()

    for target in cfg.staff_alert_targets:
        scope.add(
            OutboundMessage(
                decision_id=decision.id,
                channel=cfg.staff_alert_channel,
                to_ref=target,
                body=body,
                state="queued",
            )
        )
    scope.flush()

    audit.record(
        scope, actor="runtime", action="urgency_alert", subject_type="decision",
        subject_id=decision.id,
        data={
            "level": a2.level.value,
            "matched_signals": a2.matched_signals,
            "targets": len(cfg.staff_alert_targets),
        },
    )
    return decision
