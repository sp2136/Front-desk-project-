"""Metrics the application computes for A8, and for both dashboards.

Section 4 / A8: "Use ONLY numbers present in metrics_current / metrics_prior.
Never compute a ratio that is not given."

That rule only works if the application computes every ratio the digest might
want. Anything absent here is something A8 must report as not measured, which
is why `not_measured` is produced by this module rather than left to the model
to notice -- a model asked to spot its own blind spots will not.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

from sqlalchemy import func, select

from app.models import (
    AgentRun,
    Booking,
    Decision,
    InboundEventRow,
    Job,
    OutboundMessage,
    Reminder,
    Slot,
)


def _count(session, model, *conditions) -> int:
    stmt = select(func.count()).select_from(model)
    for c in conditions:
        stmt = stmt.where(c)
    return session.execute(stmt).scalar_one()


def _median(values: list[float]) -> float | None:
    if not values:
        return None
    vs = sorted(values)
    mid = len(vs) // 2
    return vs[mid] if len(vs) % 2 else (vs[mid - 1] + vs[mid]) / 2


@dataclass
class Window:
    label: str
    start: datetime
    end: datetime


def window_metrics(session, tenant_id: str, w: Window) -> dict:
    """Everything measurable for one tenant over one time window."""
    s, e = w.start, w.end
    in_window = lambda col: (col >= s, col < e)  # noqa: E731

    enquiries = _count(session, InboundEventRow, InboundEventRow.tenant_id == tenant_id,
                       *in_window(InboundEventRow.received_at))
    decisions = _count(session, Decision, Decision.tenant_id == tenant_id,
                       *in_window(Decision.created_at))
    approved = _count(session, Decision, Decision.tenant_id == tenant_id,
                      Decision.outcome == "approved", *in_window(Decision.created_at))
    rejected = _count(session, Decision, Decision.tenant_id == tenant_id,
                      Decision.outcome == "rejected", *in_window(Decision.created_at))
    blocked = _count(session, Decision, Decision.tenant_id == tenant_id,
                     Decision.kind == "blocked", *in_window(Decision.created_at))
    escalated = _count(session, Decision, Decision.tenant_id == tenant_id,
                       Decision.kind == "escalated", *in_window(Decision.created_at))
    open_now = _count(session, Decision, Decision.tenant_id == tenant_id,
                      Decision.outcome == "open")
    sent = _count(session, OutboundMessage, OutboundMessage.tenant_id == tenant_id,
                  *in_window(OutboundMessage.created_at))
    bookings = _count(session, Booking, Booking.tenant_id == tenant_id,
                      *in_window(Booking.created_at))
    no_shows = _count(session, Booking, Booking.tenant_id == tenant_id,
                      Booking.state == "no_show", *in_window(Booking.starts_at))
    completed = _count(session, Booking, Booking.tenant_id == tenant_id,
                       Booking.state == "completed", *in_window(Booking.starts_at))
    cancelled = _count(session, Booking, Booking.tenant_id == tenant_id,
                       Booking.state == "cancelled", *in_window(Booking.starts_at))

    edits = list(session.execute(
        select(Decision.edit_distance_pct).where(
            Decision.tenant_id == tenant_id,
            Decision.edit_distance_pct.isnot(None),
            *in_window(Decision.created_at))
    ).scalars().all())

    runs = _count(session, AgentRun, AgentRun.tenant_id == tenant_id,
                  *in_window(AgentRun.created_at))
    invalid = _count(session, AgentRun, AgentRun.tenant_id == tenant_id,
                     AgentRun.valid.is_(False), *in_window(AgentRun.created_at))
    tokens_in = session.execute(
        select(func.coalesce(func.sum(AgentRun.input_tokens), 0)).where(
            AgentRun.tenant_id == tenant_id, *in_window(AgentRun.created_at))
    ).scalar_one()
    tokens_out = session.execute(
        select(func.coalesce(func.sum(AgentRun.output_tokens), 0)).where(
            AgentRun.tenant_id == tenant_id, *in_window(AgentRun.created_at))
    ).scalar_one()
    latency = list(session.execute(
        select(AgentRun.latency_ms).where(
            AgentRun.tenant_id == tenant_id, AgentRun.valid.is_(True),
            *in_window(AgentRun.created_at))
    ).scalars().all())

    resolved = approved + rejected
    empty_slots = _count(session, Slot, Slot.tenant_id == tenant_id,
                         Slot.booking_id.is_(None), *in_window(Slot.starts_at))

    return {
        "window": w.label,
        "from": s.isoformat(),
        "to": e.isoformat(),
        "enquiries": enquiries,
        "drafts_produced": decisions,
        "approved": approved,
        "rejected": rejected,
        "blocked_by_guard": blocked,
        "escalated": escalated,
        "open_now": open_now,
        "messages_sent": sent,
        "bookings_made": bookings,
        "completed": completed,
        "cancelled": cancelled,
        "no_shows": no_shows,
        "approval_rate": round(approved / resolved, 3) if resolved else None,
        "median_edit_distance_pct": _median([float(x) for x in edits]),
        "agent_runs": runs,
        "schema_rejects": invalid,
        "schema_validity": round(1 - invalid / runs, 3) if runs else None,
        "tokens_in": int(tokens_in),
        "tokens_out": int(tokens_out),
        "median_latency_ms": _median([float(x) for x in latency]),
        "slots_left_empty": empty_slots,
    }


def exceptions_for(session, tenant_id: str) -> dict:
    """Section 4 / A8's "what leaked" section. Counts only, never prose."""
    unanswered = _count(session, Decision, Decision.tenant_id == tenant_id,
                        Decision.outcome == "open")
    stalled = _count(session, Decision, Decision.tenant_id == tenant_id,
                     Decision.outcome == "open", Decision.runtime_stop.isnot(None))
    dead_jobs = _count(session, Job, Job.tenant_id == tenant_id, Job.state == "dead")
    failed_sends = _count(session, OutboundMessage, OutboundMessage.tenant_id == tenant_id,
                          OutboundMessage.state == "failed")
    missed_reminders = _count(session, Reminder, Reminder.tenant_id == tenant_id,
                              Reminder.state == "scheduled",
                              Reminder.due_at < datetime.now(tz=None).astimezone())
    no_shows = _count(session, Booking, Booking.tenant_id == tenant_id,
                      Booking.state == "no_show")
    return {
        "escalations_not_cleared": unanswered,
        "chain_stopped_unanswered": stalled,
        "jobs_abandoned": dead_jobs,
        "failed_sends": failed_sends,
        "reminders_overdue": missed_reminders,
        "no_shows": no_shows,
    }


# Metrics the spec's digest might reach for and that nothing here computes.
# Reported to A8 explicitly so it says "not being measured yet" rather than
# substituting a proxy, which section 4 / A8 forbids.
NOT_MEASURED = [
    "revenue",
    "booking conversion rate from enquiry",
    "customer satisfaction",
    "repeat-visit rate",
    "attribution of any change to any cause",
]


def digest_inputs(session, tenant_id: str, now: datetime) -> dict:
    """The three blocks A8 receives."""
    week = timedelta(days=7)
    current = Window("this week", now - week, now)
    prior = Window("previous week", now - 2 * week, now - week)
    four = Window("previous 4 weeks", now - 5 * week, now - week)
    return {
        "metrics_current": window_metrics(session, tenant_id, current),
        "metrics_prior": {
            "previous_week": window_metrics(session, tenant_id, prior),
            "four_week_window": window_metrics(session, tenant_id, four),
        },
        "exceptions": exceptions_for(session, tenant_id),
        "not_measured": NOT_MEASURED,
    }
