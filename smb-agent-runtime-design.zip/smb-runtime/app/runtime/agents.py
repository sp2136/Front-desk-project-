"""Agent registry. One entry per agent in the spec, declared the way section 0
specifies: job, trigger, tools, output contract, latency budget.

WHY TOOLS ARE PRE-FETCHED, NOT CALLED BY THE MODEL

Each agent here makes exactly one model call. The runtime resolves the agent's
declared tools first and injects the results as labelled context blocks; the
model never drives a tool loop. That is a deliberate narrowing:

  Latency. A1's budget is under 3 seconds because it sits in a live
  conversation. A tool loop costs a round trip per call and makes the budget a
  hope rather than a property.

  Auditability. Section 1.3 wants the tool calls on the run record. Pre-fetch
  means the audit row lists exactly what the agent saw, every time, instead of
  whatever it chose to look up.

  Cost. Pre-fetched context is a stable prefix and caches; a loop does not.

The price is that an agent cannot follow a hunch and look something up. For
classifiers like A1 and A2 that is not a loss. Revisit it for E2, where a spec
normaliser genuinely benefits from iterative lookup against the synonym map.
"""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from app.schemas.agents import (
    A1Output,
    A2Output,
    A3Output,
    A4Output,
    A5Output,
    A6Output,
    A7Output,
    A8Output,
)
from app.schemas.envelope import Envelope


@dataclass(frozen=True)
class Prefetch:
    """A read tool whose result becomes a named context block in the user turn."""

    tool: str
    block: str
    args: Callable[[dict], dict] = field(default=lambda event: {})


@dataclass(frozen=True)
class AgentSpec:
    agent_id: str
    job: str
    archetype: str
    output_model: type[Envelope]
    prefetch: tuple[Prefetch, ...] = ()
    latency_budget_ms: int = 5000
    customer_facing: bool = False
    stage: int = 0
    model: str | None = None          # None -> settings.default_model
    max_tokens: int = 1024
    language_block: bool = True

    @property
    def tools(self) -> tuple[str, ...]:
        return tuple(p.tool for p in self.prefetch)


REGISTRY: dict[str, AgentSpec] = {
    "A1": AgentSpec(
        agent_id="A1",
        job="Classify one inbound message and extract the booking-relevant entities",
        archetype="A",
        output_model=A1Output,
        prefetch=(
            Prefetch("get_service_catalogue", "service_catalogue"),
            Prefetch("find_customer_by_phone", "customer_record",
                     lambda event: {"phone": event.get("sender_ref", "")}),
        ),
        latency_budget_ms=3000,  # section 4 / A1: in the path of a live conversation
        customer_facing=False,
        stage=1,
        max_tokens=800,
    ),
    "A2": AgentSpec(
        agent_id="A2",
        job="Decide whether this needs a human within minutes",
        archetype="A",
        output_model=A2Output,
        prefetch=(),  # section 4 / A2: "None -- classification only, no lookups"
        latency_budget_ms=2000,
        customer_facing=False,
        stage=1,
        max_tokens=400,
        language_block=False,
    ),
    "A3": AgentSpec(
        agent_id="A3",
        job="Turn a time preference into two or three real, bookable options",
        archetype="A",
        output_model=A3Output,
        prefetch=(
            # get_availability is "the ONLY source of truth for what is open".
            # The window comes from A1's time_window where it gave one; the
            # runtime, not the agent, decides how wide the default window is,
            # because A3 is told never to widen a window on its own.
            # Sampled across the week rather than the next 60 slots in order.
            # A venue open 24 hours a day returns two and a half days inside a
            # flat limit, which is why A3 kept offering three morning slots on
            # consecutive days while 117 other times sat unseen.
            Prefetch("get_availability", "availability",
                     lambda event: {"limit": 40, "per_day": 4, "horizon_days": 10}),
            Prefetch("get_resource_list", "resources"),
            Prefetch("get_policy_block", "policy_block"),
        ),
        latency_budget_ms=4000,
        customer_facing=False,   # returns slot ids, not prose
        stage=4,
        max_tokens=700,
        language_block=False,
    ),
    "A5": AgentSpec(
        agent_id="A5",
        job="Compose one appointment reminder",
        archetype="A",
        output_model=A5Output,
        # Timing, recipient and channel eligibility are decided by
        # runtime/reminders.py. A5 is handed the booking it is writing about.
        prefetch=(Prefetch("get_policy_block", "policy_block"),),
        latency_budget_ms=4000,
        customer_facing=True,
        stage=4,
        max_tokens=400,
    ),
    "A6": AgentSpec(
        agent_id="A6",
        job="Decide whether to ask for a review, and draft the ask",
        archetype="A",
        output_model=A6Output,
        prefetch=(Prefetch("get_policy_block", "policy_block"),),
        latency_budget_ms=4000,
        customer_facing=True,
        stage=5,
        max_tokens=500,
    ),
    "A7": AgentSpec(
        agent_id="A7",
        job="Decide whether a customer is due a return visit, and draft the nudge",
        archetype="A",
        output_model=A7Output,
        prefetch=(Prefetch("get_policy_block", "policy_block"),),
        latency_budget_ms=4000,
        customer_facing=True,
        stage=5,
        max_tokens=500,
    ),
    "A8": AgentSpec(
        agent_id="A8",
        job="Write the weekly operating summary for the owner",
        archetype="A",
        output_model=A8Output,
        prefetch=(),      # every number is supplied by runtime/metrics.py
        latency_budget_ms=15000,   # a weekly cron; nobody is waiting on it
        # The owner is not a customer, so the guard's red lines about prices and
        # commitments do not apply -- but the fabrication risk is higher here
        # than anywhere, so A8 still goes through the gate. Its facts are the
        # metrics blocks, and an invented number has nowhere to hide.
        customer_facing=True,
        stage=5,
        max_tokens=900,
        language_block=True,
    ),
    "A4": AgentSpec(
        agent_id="A4",
        job="Draft one customer-facing reply from approved facts",
        archetype="A",
        output_model=A4Output,
        prefetch=(
            # search_faq is queried with the customer's own words. Section 4 /
            # A4 requires every fact to come from one of these blocks, so the
            # retrieval quality here is the ceiling on the draft's quality.
            Prefetch("search_faq", "faq_answers",
                     lambda event: {"query": event.get("body", ""), "top_k": 5}),
            Prefetch("get_service_catalogue", "service_facts"),
            Prefetch("get_policy_block", "policy_block"),
        ),
        # Not in the live conversation path the way A1 is -- a draft waits for
        # a human at stage 3 -- but staff watch the queue, so keep it short.
        latency_budget_ms=6000,
        customer_facing=True,
        stage=3,
        max_tokens=600,
    ),
}


def get(agent_id: str) -> AgentSpec:
    if agent_id not in REGISTRY:
        raise KeyError(
            f"unknown agent '{agent_id}'. Registered: {sorted(REGISTRY)}. "
            "Declare it in app/runtime/agents.py before enabling it for a tenant."
        )
    return REGISTRY[agent_id]
