"""The pipeline of section 1.1:

  EVENT -> VALIDATE -> AGENT -> REVIEW -> EXECUTE
                 \\______ escalation / retry ______/

One runtime serves all fourteen business types. What differs per tenant is
configuration, not code and not prompts.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from zoneinfo import ZoneInfo

from pydantic import ValidationError

from app.config import settings
from app.models import AgentRun, Decision, Job
from app.runtime import agents, audit, review
from app.runtime import guard as guard_mod
from app.runtime.caps import CapGuard
from app.runtime.errors import (
    AgentNotEnabled,
    ModelUnavailable,
    RuntimeStop,
    SchemaInvalid,
)
from app.runtime.llm import LLMProvider
from app.runtime.prompts import build_user_message
from app.runtime.prompts import store as prompt_store
from app.runtime.sourcefacts import SourceFacts
from app.runtime.tools import build_toolbelt, toolbelt_version
from app.runtime.validate import load_tenant_config
from app.schemas.agents import GuardOutput
from app.schemas.envelope import Envelope, apply_option_ceiling, apply_threshold
from app.schemas.tenant import TenantConfig

# Conservative preflight estimate. Deliberately generous: under-estimating means
# the cap is crossed before it is checked, which defeats the point.
PREFLIGHT_INPUT_TOKENS = 2500
PREFLIGHT_OUTPUT_TOKENS = 600


@dataclass
class PipelineResult:
    agent_id: str
    envelope: Envelope | None = None
    decision: Decision | None = None
    stopped: str | None = None
    detail: str | None = None
    runs: list[int] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.stopped is None


class Pipeline:
    def __init__(self, provider: LLMProvider) -> None:
        self._provider = provider
        self._facts = SourceFacts()

    # ------------------------------------------------------------------
    def run(self, scope, job: Job) -> PipelineResult:
        cfg = load_tenant_config(scope.session, scope.tenant_id)
        spec = agents.get(job.agent_id)
        result = PipelineResult(agent_id=job.agent_id)

        try:
            self._preconditions(cfg, spec)
            cap = CapGuard(scope, cfg)
            cap.preflight(PREFLIGHT_INPUT_TOKENS, PREFLIGHT_OUTPUT_TOKENS)
            envelope, run_id = self._call_agent(scope, cfg, spec, job, cap)
            result.envelope = envelope
            result.runs.append(run_id)
        except RuntimeStop as stop:
            result.stopped = stop.kind
            result.detail = str(stop)
            audit.record(
                scope, actor="runtime", action="pipeline_stopped", subject_type="job",
                subject_id=job.id,
                data={"agent_id": job.agent_id, "kind": stop.kind, "detail": str(stop)},
            )
            # A stop is not a silent drop. It becomes a Decision so it shows up
            # on the exceptions list A8 reports, and so an operator can see the
            # customer who did not get an answer.
            result.decision = scope.add(
                Decision(run_id=None, kind=review.DecisionKind.ESCALATED,
                         runtime_stop=stop.kind, outcome="open")
            )
            scope.flush()
            return result

        guard_result = self._maybe_guard(scope, cfg, spec, envelope)
        result.decision = review.decide(
            scope, cfg,
            run_id=run_id,
            envelope=envelope,
            draft=getattr(envelope, "draft", None),
            intent=self._intent_of(envelope),
            a2_level=(job.payload.get("upstream_a2") or {}).get("level"),
            a2_required=job.payload.get("a2_required", True),
            offered_options=(job.payload.get("upstream_a3") or {}).get("options"),
            offered_service_id=(
                (job.payload.get("upstream_a1") or {}).get("service_id")
                or cfg.default_service_id
            ),
            guard=guard_result,
            customer_facing=spec.customer_facing,
        )
        return result

    # ------------------------------------------------------------------
    def _preconditions(self, cfg: TenantConfig, spec: agents.AgentSpec) -> None:
        if spec.agent_id not in cfg.agents_enabled:
            raise AgentNotEnabled(
                f"agent {spec.agent_id} is not in agents_enabled for {cfg.tenant_id}"
            )
        if cfg.archetype.value != spec.archetype:
            raise AgentNotEnabled(
                f"agent {spec.agent_id} belongs to archetype {spec.archetype}; "
                f"tenant {cfg.tenant_id} is archetype {cfg.archetype.value}"
            )
        if not prompt_store.has_body(spec.agent_id):
            raise AgentNotEnabled(
                f"agent {spec.agent_id} has no prompt body yet (stage {spec.stage} work)"
            )

    def _system_context(self, cfg: TenantConfig) -> dict:
        """Values substituted into the SYSTEM prompt. Configuration only.

        {{event}} and {{history}} appear in preamble rule 3 as the names of the
        data the model must not obey. They resolve to the literal tag names
        used in the user turn, so the rule points at the real blocks.
        """
        now_local = datetime.now(UTC).astimezone(ZoneInfo(cfg.timezone))
        return {
            "tenant_name": cfg.tenant_name,
            "business_type": cfg.business_type,
            "city": cfg.city,
            "today": now_local.date().isoformat(),
            "languages": json.dumps(cfg.languages),
            "escalation_threshold": cfg.escalation_threshold,
            "max_slot_options": cfg.max_slot_options,
            "event": "<event>",
            "history": "<history>",
        }

    def _user_message(self, scope, cfg: TenantConfig, spec: agents.AgentSpec, job: Job,
                      run_id: int) -> tuple[str, SourceFacts]:
        """Per-call DATA. Pre-fetches the agent's declared read tools.

        Returns the user message AND the source facts, because the guard must
        be checked against what the runtime retrieved, not against what the
        agent later claims it used.
        """
        event = job.payload.get("event", {})
        blocks: dict[str, object] = {
            "event": event,
            "history": job.payload.get("history", []),
        }
        facts = SourceFacts()

        belt = build_toolbelt(list(spec.tools), scope, run_id)
        for pf in spec.prefetch:
            value = belt[pf.tool](**pf.args(event))
            blocks[pf.block] = value
            facts.add(pf.block, value)

        if spec.agent_id == "A2":
            blocks["a1_output"] = job.payload.get("upstream_a1", {})
            blocks["business_type"] = cfg.business_type
            blocks["urgency_keywords"] = cfg.urgency_keywords

        if spec.agent_id == "A3":
            blocks["a1_output"] = job.payload.get("upstream_a1", {})
            blocks["max_slot_options"] = cfg.max_slot_options
            blocks["customer_record"] = job.payload.get("customer_record")
            # Availability is the only source of truth for what is open, so it
            # is a fact the guard will later check any draft against.
            facts.add("availability", blocks.get("availability"))

        if spec.agent_id == "A5":
            blocks["booking"] = job.payload.get("booking", {})
            blocks["customer"] = job.payload.get("customer", {})
            blocks["reminder_stage"] = job.payload.get("reminder_stage", "")
            # Every detail in a reminder must be copied exactly from the
            # booking, so the booking is the fact set.
            facts.add("booking", blocks["booking"])
            facts.add("customer", blocks["customer"])

        if spec.agent_id == "A6":
            blocks["booking"] = job.payload.get("booking", {})
            blocks["internal_notes"] = job.payload.get("internal_notes") or ""
            blocks["review_link"] = job.payload.get("review_link") or ""
            blocks["prior_asks"] = job.payload.get("prior_asks", {})
            facts.add("booking", blocks["booking"])
            facts.add("review_link", blocks["review_link"])

        if spec.agent_id == "A7":
            blocks["customer"] = job.payload.get("customer", {})
            blocks["visit_history"] = job.payload.get("visit_history", [])
            blocks["recall_rules"] = cfg.recall_rules
            blocks["contact_history"] = job.payload.get("contact_history", {})
            blocks["opt_out"] = job.payload.get("opt_out", False)
            facts.add("visit_history", blocks["visit_history"])
            facts.add("recall_rules", cfg.recall_rules)

        if spec.agent_id == "A8":
            blocks["metrics_current"] = job.payload.get("metrics_current", {})
            blocks["metrics_prior"] = job.payload.get("metrics_prior", {})
            blocks["exceptions"] = job.payload.get("exceptions", {})
            # Every number A8 may use. An invented one has nowhere to hide.
            facts.add("metrics_current", blocks["metrics_current"])
            facts.add("metrics_prior", blocks["metrics_prior"])
            facts.add("exceptions", blocks["exceptions"])

        if spec.agent_id == "A4":
            blocks["a1_output"] = job.payload.get("upstream_a1", {})
            summary = job.payload.get("availability_summary")
            if cfg.availability_summary and summary:
                blocks["availability_summary"] = summary
                facts.add("availability_summary", summary)
            a3 = job.payload.get("upstream_a3", {}) or {}
            blocks["a3_options"] = a3.get("options", [])
            if a3.get("unavailable_note"):
                blocks["a3_options"] = {
                    "options": a3.get("options", []),
                    "unavailable_note": a3["unavailable_note"],
                }
            # A3's options are retrieved availability, so they are facts the
            # draft may rely on. A1's and A2's outputs are judgments about the
            # message, not facts about the business, and are deliberately NOT
            # added to the fact set the guard checks the draft against.
            facts.add("a3_options", blocks["a3_options"])

        return build_user_message(**blocks), facts

    def _call_agent(self, scope, cfg: TenantConfig, spec: agents.AgentSpec, job: Job,
                    cap: CapGuard) -> tuple[Envelope, int]:
        """One model call, validated, with exactly one retry on schema failure.

        Section 2.2: "The runtime validates against JSON Schema, rejects on
        failure, retries once with the error text appended, and escalates on
        second failure."

        The retry appends the validation error to the USER turn, not the system
        prompt: the system prompt must stay byte-identical across calls or its
        cache entry is lost and its hash stops identifying the version.
        """
        assembled = prompt_store.assemble(spec.agent_id, self._system_context(cfg))
        if assembled.unresolved:
            raise AgentNotEnabled(
                f"agent {spec.agent_id} prompt has unresolved placeholders "
                f"{list(assembled.unresolved)}; a context field is missing"
            )
        belt_version = toolbelt_version(list(spec.tools))
        model = spec.model or settings.default_model
        base_user: str | None = None
        last_error: str | None = None

        for attempt in (1, 2):
            run = scope.add(
                AgentRun(
                    job_id=job.id, agent_id=spec.agent_id, attempt=attempt,
                    prompt_id=assembled.prompt_id, prompt_version=assembled.version,
                    prompt_sha256=assembled.sha256, toolbelt_version=belt_version,
                )
            )
            scope.flush()

            if base_user is None:
                base_user, facts = self._user_message(scope, cfg, spec, job, run.id)
                self._facts = facts
            user = base_user if attempt == 1 else (
                f"{base_user}\n\n<validation_error>\nYour previous response failed "
                f"schema validation with these errors. Return corrected JSON only.\n"
                f"{last_error}\n</validation_error>\n"
            )

            started = time.perf_counter()
            try:
                llm = self._provider.complete(
                    assembled.text, user, max_tokens=spec.max_tokens, model=model
                )
            except ModelUnavailable:
                run.validation_error = "model_unavailable"
                scope.flush()
                raise

            run.model = llm.model
            run.input_tokens = llm.input_tokens
            run.output_tokens = llm.output_tokens
            run.latency_ms = int((time.perf_counter() - started) * 1000)
            run.raw_output = llm.text
            cap.record_usage(llm.input_tokens, llm.output_tokens,
                             llm.cached_input_tokens)

            try:
                envelope = spec.output_model.model_validate_json(llm.text)
            except ValidationError as exc:
                run.valid = False
                last_error = json.dumps(exc.errors(include_url=False), default=str)[:4000]
                run.validation_error = last_error
                scope.flush()
                audit.record(
                    scope, actor="runtime", action="schema_rejected", subject_type="agent_run",
                    subject_id=run.id,
                    data={"agent_id": spec.agent_id, "attempt": attempt},
                )
                continue

            envelope = apply_threshold(envelope, cfg.escalation_threshold)
            envelope = apply_option_ceiling(envelope, cfg.max_slot_options)
            run.valid = True
            run.parsed_output = envelope.model_dump(mode="json")
            scope.flush()

            audit.record(
                scope, actor="runtime", action="agent_run", subject_type="agent_run",
                subject_id=run.id,
                data={
                    "agent_id": spec.agent_id,
                    "attempt": attempt,
                    "prompt_version": assembled.version,
                    "prompt_sha256": assembled.sha256[:16],
                    "toolbelt_version": belt_version,
                    "model": llm.model,
                    "input_tokens": llm.input_tokens,
                    "cached_input_tokens": llm.cached_input_tokens,
                    "output_tokens": llm.output_tokens,
                    "latency_ms": run.latency_ms,
                    "over_latency_budget": run.latency_ms > spec.latency_budget_ms,
                    "required_cleanup": llm.required_cleanup,
                    "confidence": envelope.confidence,
                    "escalate": envelope.escalate,
                },
            )
            return envelope, run.id

        raise SchemaInvalid(
            f"agent {spec.agent_id} failed schema validation twice: {last_error}"
        )

    def _maybe_guard(self, scope, cfg: TenantConfig, spec: agents.AgentSpec,
                     envelope: Envelope) -> GuardOutput | None:
        draft = getattr(envelope, "draft", None)
        if not draft or not cfg.guard_required(spec.customer_facing):
            return None
        return guard_mod.run_guard(
            self._provider, draft, getattr(self, "_facts", SourceFacts()),
            cfg.red_lines, cfg.languages,
        )

    @staticmethod
    def _intent_of(envelope: Envelope) -> str | None:
        """A1 reports `intent`; A4 reports `intent_handled`.

        Reading only `intent` meant every A4 decision was recorded with no
        intent at all -- so the auto-send whitelist could never match one, and
        the approval-rate counting behind "condition to widen" had nothing to
        count. The whitelist would have looked like it was working, because
        everything correctly went to a human; it just would never have widened,
        for a reason no report would have shown.
        """
        intent = getattr(envelope, "intent", None) or getattr(
            envelope, "intent_handled", None
        )
        return str(intent) if intent is not None else None
