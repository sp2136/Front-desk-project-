"""Runtime exceptions.

Each of these maps to a distinct operational response, which is why they are not
one generic RuntimeError. The audit log records the class name.
"""
from __future__ import annotations


class RuntimeStop(Exception):
    """Base: the pipeline stopped without producing a customer-facing artefact."""

    kind = "runtime_stop"


class KillSwitchEngaged(RuntimeStop):
    kind = "kill_switch"


class AgentNotEnabled(RuntimeStop):
    kind = "agent_not_enabled"


class CapExceeded(RuntimeStop):
    kind = "cap_exceeded"


class RateLimited(RuntimeStop):
    kind = "rate_limited"


class DuplicateEvent(RuntimeStop):
    kind = "duplicate_event"


class SchemaInvalid(RuntimeStop):
    kind = "schema_invalid"


class GuardRejected(RuntimeStop):
    kind = "guard_rejected"


class ModelUnavailable(RuntimeStop):
    kind = "model_unavailable"


class TenantIsolationError(Exception):
    """Raised when a query would cross a tenant boundary.

    This is never caught and never retried. It is a defect, and §11.3 says it must
    be impossible at the tool layer rather than refused at the prompt layer.
    """

    kind = "tenant_isolation"


class WriteToolRefused(Exception):
    """An agent tried to resolve a tool marked as a write. Law 1 of §1.2."""

    kind = "write_tool_refused"
