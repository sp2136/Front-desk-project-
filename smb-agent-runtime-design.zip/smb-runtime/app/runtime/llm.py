"""Model providers.

Stage 1 attaches a real model. The interface takes a SYSTEM prompt and a USER
message separately -- see runtime/prompts.py for why that split is a safety
property and not a stylistic one.

Providers:
  NullProvider      raises. Still the default, so an un-configured deployment
                    cannot quietly start spending.
  EchoProvider      scripted. Drives the tests and the eval harness offline.
  AnthropicProvider the real one.
"""
from __future__ import annotations

import os
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Protocol

from app.config import settings
from app.runtime.errors import ModelUnavailable

_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*(.*?)\s*```\s*$", re.DOTALL)


@dataclass(frozen=True)
class LLMResult:
    text: str
    model: str
    input_tokens: int
    output_tokens: int
    latency_ms: int
    cached_input_tokens: int = 0
    # True when the raw output needed de-fencing before it would parse.
    # Recorded rather than hidden: section 11.2 gates schema validity at 100%,
    # and silently repairing output would inflate that number into a lie.
    required_cleanup: bool = False
    stop_reason: str | None = None


def strip_fences(text: str) -> tuple[str, bool]:
    """Preamble rule 5 forbids markdown fences. Models sometimes emit them
    anyway. Strip, and report that we had to."""
    m = _FENCE_RE.match(text)
    if m:
        return m.group(1), True
    return text, False


class LLMProvider(Protocol):
    name: str

    def complete(self, system: str, user: str, *, max_tokens: int = 1024,
                 model: str | None = None, temperature: float = 0.0) -> LLMResult: ...


class NullProvider:
    name = "null"

    def complete(self, system: str, user: str, *, max_tokens: int = 1024,
                 model: str | None = None, temperature: float = 0.0) -> LLMResult:
        raise ModelUnavailable(
            "LLM_PROVIDER=null. Set LLM_PROVIDER=echo for tests, or 'anthropic' "
            "with ANTHROPIC_API_KEY set -- but only once the agent's eval case "
            "file passes its gates (section 11.2)."
        )


@dataclass
class EchoProvider:
    """Scripted responses in order, or a callable keyed on the user message."""

    name: str = "echo"
    script: list[str] = field(default_factory=list)
    responder: Callable[[str, str], str] | None = None
    on_call: Callable[[str, str], None] | None = None
    _i: int = 0

    def complete(self, system: str, user: str, *, max_tokens: int = 1024,
                 model: str | None = None, temperature: float = 0.0) -> LLMResult:
        started = time.perf_counter()
        if self.on_call:
            self.on_call(system, user)
        if self.responder is not None:
            text = self.responder(system, user)
        else:
            if self._i >= len(self.script):
                raise ModelUnavailable("echo script exhausted")
            text = self.script[self._i]
            self._i += 1
        cleaned, cleanup = strip_fences(text)
        return LLMResult(
            text=cleaned,
            model=model or "echo-1",
            input_tokens=max(1, (len(system) + len(user)) // 4),
            output_tokens=max(1, len(cleaned) // 4),
            latency_ms=int((time.perf_counter() - started) * 1000),
            required_cleanup=cleanup,
            stop_reason="end_turn",
        )


class AnthropicProvider:
    """Real calls.

    Two choices worth naming:

    temperature=0 by default. A1 and A2 are classifiers. Sampling variety in a
    classifier shows up as a flapping eval score and as two customers with the
    same message getting different urgency levels, which is indefensible when
    the business is a clinic.

    The system prompt is marked for caching. It is ~5k characters, identical
    across every call for a tenant, and re-sending it uncached on every inbound
    message is most of the token bill at the volumes Archetype A produces.
    """

    name = "anthropic"

    def __init__(self, api_key: str | None = None) -> None:
        try:
            import anthropic
        except ImportError as exc:  # pragma: no cover - dependency guard
            raise ModelUnavailable(
                "the 'anthropic' package is not installed; pip install -e '.[llm]'"
            ) from exc
        key = api_key or os.getenv("ANTHROPIC_API_KEY")
        if not key:
            raise ModelUnavailable("ANTHROPIC_API_KEY is not set")
        self._client = anthropic.Anthropic(api_key=key, max_retries=2, timeout=30.0)

    def complete(self, system: str, user: str, *, max_tokens: int = 1024,
                 model: str | None = None, temperature: float = 0.0) -> LLMResult:
        import anthropic

        started = time.perf_counter()
        try:
            resp = self._client.messages.create(
                model=model or settings.default_model,
                max_tokens=max_tokens,
                temperature=temperature,
                system=[{"type": "text", "text": system,
                         "cache_control": {"type": "ephemeral"}}],
                messages=[{"role": "user", "content": user}],
            )
        except anthropic.APIStatusError as exc:
            raise ModelUnavailable(f"anthropic API error {exc.status_code}: {exc}") from exc
        except anthropic.APIConnectionError as exc:
            raise ModelUnavailable(f"anthropic connection error: {exc}") from exc

        text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
        cleaned, cleanup = strip_fences(text)
        usage = resp.usage
        return LLMResult(
            text=cleaned,
            model=resp.model,
            input_tokens=getattr(usage, "input_tokens", 0),
            output_tokens=getattr(usage, "output_tokens", 0),
            cached_input_tokens=getattr(usage, "cache_read_input_tokens", 0) or 0,
            latency_ms=int((time.perf_counter() - started) * 1000),
            required_cleanup=cleanup,
            stop_reason=resp.stop_reason,
        )


def get_provider() -> LLMProvider:
    from app.runtime.stub_provider import StubProvider

    return {"null": NullProvider, "echo": EchoProvider, "stub": StubProvider,
            "anthropic": AnthropicProvider}[settings.llm_provider]()
