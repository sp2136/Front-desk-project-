"""Suppression rules for A6 and A7, enforced before the agent is called.

Section 4 / A7: "If opt_out is true: due = false. Always. No exceptions."
Section 4 / A6: "asked within 90 days -> ask = false".

Both prompts state their rules, and both schemas enforce what they can. This
module is the third layer, and the one that actually decides: it filters the
candidate list so the agent is never even asked about a customer it must not
contact.

The ordering matters. If the model decides suppression, then a prompt
regression sends a nudge to someone who opted out -- which is a legal problem
in most jurisdictions and a trust problem in all of them. If the application
decides, the worst a regression can do is draft something nobody sends.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from sqlalchemy import select

from app.models import Booking, Customer

# Section 4 / A7.
MIN_DAYS_BETWEEN_NUDGES = 45
MAX_SILENT_NUDGES = 3
# Section 4 / A6.
MIN_DAYS_BETWEEN_REVIEW_ASKS = 90


@dataclass(frozen=True)
class Suppression:
    suppressed: bool
    reason: str | None = None


def get_or_create_customer(scope, customer_ref: str, *, name: str | None = None,
                           language: str = "en") -> Customer:
    row = scope.one_or_none(Customer, Customer.customer_ref == customer_ref)
    if row is None:
        row = scope.add(Customer(customer_ref=customer_ref, name=name, language=language))
        scope.flush()
    elif name and not row.name:
        row.name = name
        scope.flush()
    return row


def nudge_suppression(customer: Customer, now: datetime | None = None) -> Suppression:
    """Whether A7 may contact this customer at all."""
    now = now or datetime.now(customer.last_nudge_at.tzinfo if customer.last_nudge_at
                              else None)
    if customer.opt_out:
        return Suppression(True, "opt_out")
    if customer.dormant:
        return Suppression(True, "dormant")
    if customer.nudge_count >= MAX_SILENT_NUDGES and customer.last_nudge_reply_at is None:
        return Suppression(True, "dormant")
    if customer.last_nudge_at is not None:
        gap = (now - customer.last_nudge_at).days
        if gap < MIN_DAYS_BETWEEN_NUDGES:
            return Suppression(True, "too_recent")
    return Suppression(False)


def review_suppression(customer: Customer, now: datetime) -> Suppression:
    """Whether A6 may ask this customer for a review."""
    if customer.opt_out:
        return Suppression(True, "opt_out")
    if customer.last_review_ask_at is not None:
        gap = (now - customer.last_review_ask_at).days
        if gap < MIN_DAYS_BETWEEN_REVIEW_ASKS:
            return Suppression(True, "asked_within_90_days")
    return Suppression(False)


def record_nudge(scope, customer: Customer, now: datetime) -> None:
    customer.nudge_count += 1
    customer.last_nudge_at = now
    if customer.nudge_count >= MAX_SILENT_NUDGES and customer.last_nudge_reply_at is None:
        customer.dormant = True
    scope.flush()


def record_review_ask(scope, customer: Customer, now: datetime) -> None:
    customer.last_review_ask_at = now
    scope.flush()


def visit_history(scope, customer_ref: str) -> list[dict]:
    """Completed visits, newest first. The input A7 reasons over."""
    rows = scope.session.execute(
        select(Booking)
        .where(Booking.tenant_id == scope.tenant_id,
               Booking.customer_ref == customer_ref,
               Booking.state == "completed")
        .order_by(Booking.starts_at.desc())
    ).scalars().all()
    return [
        {"booking_id": b.id, "service_id": b.service_id,
         "date": b.starts_at.date().isoformat(), "resource_id": b.resource_id}
        for b in rows
    ]


def due_for_recall(scope, recall_rules: dict, now: datetime) -> list[dict]:
    """Candidates A7 should be asked about.

    Application-side due calculation, deliberately. A7 is asked to confirm and
    draft, not to be the only thing standing between a customer and an
    unwanted message. A service with no configured interval produces no
    candidate at all -- section 4 / A7: "never infer an interval for a service
    that has none configured."
    """
    candidates: list[dict] = []
    for customer in scope.all(Customer):
        if nudge_suppression(customer, now).suppressed:
            continue
        history = visit_history(scope, customer.customer_ref)
        if not history:
            continue
        seen: set[str] = set()
        for visit in history:            # newest first, so the first hit is the latest
            service_id = visit["service_id"]
            if service_id in seen:
                continue
            seen.add(service_id)
            rule = recall_rules.get(service_id)
            if rule is None:
                continue
            days = rule["days"] if isinstance(rule, dict) else rule
            since = (now.date() - datetime.fromisoformat(visit["date"]).date()).days
            if since >= int(days):
                candidates.append({
                    "customer_ref": customer.customer_ref,
                    "service_id": service_id,
                    "days_since": since,
                    "interval_days": int(days),
                })
    return candidates
