"""Stage 0 tool implementations.

The appendix lists the full contract set. Stage 0 implements the SHARED block
and registers the Archetype A reads as explicit NotImplemented stubs, so that
an agent spec naming a tool that does not exist fails at registration time
rather than at 3am in front of a customer.

The WRITE tools are registered too -- with writes=True -- precisely so that
build_toolbelt has something to refuse. Registering them is how the refusal
becomes testable.
"""
from __future__ import annotations

from app.models import Booking, Resource
from app.runtime.tools import registry

# --------------------------------------------------------------------------
# SHARED
# --------------------------------------------------------------------------


@registry.register("get_policy_block", version="1", description="Tenant policy block")
def get_policy_block(scope) -> dict:
    from app.models import Tenant

    tenant = scope.session.get(Tenant, scope.tenant_id)
    return (tenant.config or {}).get("policy_block", {}) if tenant else {}


@registry.register("find_customer_by_phone", version="1", description="customer | null")
def find_customer_by_phone(scope, phone: str) -> dict | None:
    # Stage 0: no customer table yet. Returns null rather than fabricating one,
    # which is the behaviour A1 is specified to handle (customer_record = null).
    _ = (scope, phone)
    return None


@registry.register("get_service_catalogue", version="1", description="approved services")
def get_service_catalogue(scope) -> list[dict]:
    from app.models import Tenant

    tenant = scope.session.get(Tenant, scope.tenant_id)
    return (tenant.config or {}).get("service_catalogue", []) if tenant else []


@registry.register("search_faq", version="1", description="owner-approved answers only")
def search_faq(scope, query: str, top_k: int = 5) -> list[dict]:
    from app.models import Tenant

    tenant = scope.session.get(Tenant, scope.tenant_id)
    corpus = (tenant.config or {}).get("faq_corpus", []) if tenant else []
    # Naive term overlap at stage 0. Replaced by a real retriever at stage 3;
    # the contract is what matters now, not the ranking.
    terms = {t for t in query.lower().split() if len(t) > 2}
    scored = []
    for row in corpus:
        text = f"{row.get('question','')} {row.get('answer','')}".lower()
        hits = sum(1 for t in terms if t in text)
        if hits:
            scored.append((hits, row))
    scored.sort(key=lambda p: -p[0])
    return [r for _, r in scored[:top_k]]


# --------------------------------------------------------------------------
# ARCHETYPE A reads
# --------------------------------------------------------------------------


@registry.register("get_availability", version="1", archetypes="A",
                   description="open slots in a window -- the only source of truth")
def get_availability(scope, service_id: str | None = None, resource_id: str | None = None,
                     from_iso: str | None = None, to_iso: str | None = None,
                     limit: int = 30, per_day: int | None = None,
                     horizon_days: int | None = None) -> list[dict]:
    """Section 4 / A3: "the ONLY source of truth for what is open".

    Expired locks are treated as open here, so a customer who stopped replying
    does not hold a slot off the market.

    `per_day` exists because taking the first N slots chronologically is not
    the same as showing what is open. A venue with 24 open hours a day returns
    two and a half days inside a 60-row limit, so A3 is asked to "spread across
    days" while being handed almost one day -- and it offers three morning
    slots because that is all it can see. Sampling a few per day across the
    horizon costs the same tokens and spans the week.
    """
    from datetime import UTC, datetime
    from zoneinfo import ZoneInfo

    from app.models import Tenant
    from app.runtime.booking import available_slots

    def _parse(v):
        return datetime.fromisoformat(v) if v else None

    from datetime import timedelta

    start = _parse(from_iso)
    end = _parse(to_iso)
    if end is None and horizon_days:
        end = (start or datetime.now(UTC)) + timedelta(days=horizon_days)

    rows = available_slots(
        scope, service_id=service_id, resource_id=resource_id,
        from_dt=start, to_dt=end,
        # Over-fetch when sampling, so each day has candidates to sample from.
        limit=limit * 8 if per_day else limit,
    )
    names = {r.id: r.name for r in scope.all(Resource)}

    # Timestamps are stored in UTC and emitted in the TENANT'S timezone. The
    # only source of truth for what is open must speak in the clinic's own
    # time, or a 10:00 Surat appointment reaches the patient as 04:30 -- which
    # is not a formatting nit, it is someone told to arrive in the night.
    tenant = scope.session.get(Tenant, scope.tenant_id)
    zone = ZoneInfo((tenant.config or {}).get("timezone", "Asia/Kolkata"))

    if per_day:
        seen: dict[str, int] = {}
        sampled = []
        for slot in rows:
            key = slot.starts_at.astimezone(zone).date().isoformat()
            if seen.get(key, 0) >= per_day:
                continue
            seen[key] = seen.get(key, 0) + 1
            sampled.append(slot)
            if len(sampled) >= limit:
                break
        rows = sampled

    return [
        {
            "slot_id": s.id,
            "starts_at": s.starts_at.astimezone(zone).isoformat(),
            "resource_id": s.resource_id,
            "resource_name": names.get(s.resource_id, s.resource_id),
            "service_id": s.service_id,
            "duration_minutes": s.duration_min,
        }
        for s in rows
    ]


@registry.register("get_resource_list", version="1", archetypes="A",
                   description="practitioners / stylists / bays with skills")
def get_resource_list(scope) -> list[dict]:
    return [
        {"id": r.id, "name": r.name, "skills": r.skills}
        for r in scope.all(Resource) if r.active
    ]


@registry.register("get_booking", version="1", archetypes="A",
                   description="one booking by id")
def get_booking(scope, booking_id: int) -> dict | None:
    from zoneinfo import ZoneInfo

    from app.models import Tenant

    row = scope.one_or_none(Booking, Booking.id == booking_id)
    if row is None:
        return None
    names = {r.id: r.name for r in scope.all(Resource)}
    tenant = scope.session.get(Tenant, scope.tenant_id)
    zone = ZoneInfo((tenant.config or {}).get("timezone", "Asia/Kolkata"))
    return {
        "booking_id": row.id, "service_id": row.service_id,
        "starts_at": row.starts_at.astimezone(zone).isoformat(),
        "duration_minutes": row.duration_min,
        "resource_id": row.resource_id,
        "resource_name": names.get(row.resource_id, row.resource_id),
        "state": row.state,
    }


@registry.register("get_visit_history", version="0", archetypes="A",
                   description="stub until stage 5")
def get_visit_history(scope, customer_id: str) -> list[dict]:
    raise NotImplementedError("get_visit_history lands at stage 5 with A7")


# --------------------------------------------------------------------------
# WRITES -- application code only. Never resolvable into a toolbelt.
# --------------------------------------------------------------------------


@registry.register("log_event", version="1", writes=True, description="runtime only")
def log_event(scope, payload: dict) -> None:
    raise NotImplementedError("runtime-only write; invoked by the audit writer, not a tool")


# These two are registered with writes=True so that build_toolbelt has
# something to refuse. The real implementations live in runtime/booking.py and
# are called by application code; an agent can never resolve either one.


@registry.register("create_soft_lock", version="1", writes=True, archetypes="A")
def create_soft_lock(scope, slot_id: str, ttl_s: int) -> None:
    raise NotImplementedError(
        "write path: call app.runtime.booking.acquire_soft_lock from application code"
    )


@registry.register("commit_booking", version="1", writes=True, archetypes="A")
def commit_booking(scope, lock_id: str) -> None:
    raise NotImplementedError(
        "write path: call app.runtime.booking.commit_booking from application code"
    )
