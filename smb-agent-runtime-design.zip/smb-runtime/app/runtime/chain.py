"""Chain routing for Archetype A, section 4.

    inbound --> A1 Triage --> A2 Urgency --+-(urgent)--> HUMAN NOW
                                           |
                                           +-(routine)-> A3 Slot Proposer

Stage 1 builds the first two links and the pre-emption between them. A3 onward
raise no route yet, which is why `next_steps` returns nothing for A2 routine
rather than pretending.

The routing lives here rather than in the worker so that it is testable without
a queue, and so that adding archetype B does not mean editing the worker loop.
"""
from __future__ import annotations

from dataclasses import dataclass

from app.schemas.agents import A2Output, Intent, UrgencyLevel
from app.schemas.envelope import Envelope

# Section 4 / A2 trigger: "Every A1 output where intent is book,
# service_enquiry, complaint or follow_up_existing".
A2_TRIGGER_INTENTS = frozenset(
    {Intent.BOOK, Intent.SERVICE_ENQUIRY, Intent.COMPLAINT, Intent.FOLLOW_UP_EXISTING,
     # RESCHEDULE is not in A2's trigger list in section 4, but A3's trigger is
     # "A1 intent = book OR RESCHEDULE, A2 level = routine or same_day". Those
     # two clauses cannot both hold: a reschedule that skips A2 has no level,
     # so A3 could never run for it, and a reschedule is precisely the request
     # that needs slot options. Resolved by running the safety gate -- the
     # cautious direction, and the one section 4 / A2 says to be wrong in.
     Intent.RESCHEDULE}
)

# Section 4 / A3 trigger: "A1 intent = book or reschedule, A2 level = routine
# or same_day". Both halves are required.
A3_TRIGGER_INTENTS = frozenset({Intent.BOOK, Intent.RESCHEDULE})

# Section 4 / A4 trigger: "After A1/A2/A3, OR ANY INBOUND THAT NEEDS A TEXTUAL
# ANSWER". Intents outside A2_TRIGGER_INTENTS still need a reply -- someone
# asking opening hours gets no urgency screening and must not therefore fall
# off the end of the chain unanswered. They route straight to A4.
#
# Spam is the one intent that needs no reply at all, and replying to it is how
# a tenant's number gets reported.
NO_REPLY_INTENTS = frozenset({Intent.SPAM})


@dataclass(frozen=True)
class ChainStep:
    agent_id: str
    payload_extra: dict


@dataclass(frozen=True)
class ChainOutcome:
    steps: tuple[ChainStep, ...] = ()
    preempt: bool = False
    alert: str | None = None


def next_steps(agent_id: str, envelope: Envelope,
               upstream_intent: str | None = None) -> ChainOutcome:
    """Route one completed agent run.

    `upstream_intent` is A1's classification, carried forward because A2's own
    output deliberately contains no intent field -- section 4 / A2 strips every
    field that could be rendered to a customer, and the routing needs the
    intent without A2 having to carry it.
    """
    if agent_id == "A1":
        intent = getattr(envelope, "intent", None)
        if intent in NO_REPLY_INTENTS:
            return ChainOutcome()
        if intent not in A2_TRIGGER_INTENTS:
            # Needs an answer but not an urgency screen. Straight to A4, with
            # no a2 level -- which the review gate reads as "not routine" and
            # therefore never auto-sends. Correct: nothing cleared it.
            return ChainOutcome(
                steps=(ChainStep("A4", {
                    "upstream_a1": envelope.model_dump(mode="json"),
                    # Recorded so the review gate can tell "not screened because
                    # this intent never needed screening" from "should have been
                    # screened and was not".
                    "a2_required": False,
                }),)
            )
        # A2 runs even when A1 escalated. A1 escalating on a complaint sends the
        # item to a human queue; A2 decides whether that human needs to look
        # now or at the end of the shift, and those are different facts. Running
        # the safety gate anyway is the cautious direction, which is the
        # direction section 4 / A2 says to be wrong in.
        return ChainOutcome(
            steps=(ChainStep("A2", {"upstream_a1": envelope.model_dump(mode="json")}),)
        )

    if agent_id == "A2":
        assert isinstance(envelope, A2Output)
        if envelope.level is UrgencyLevel.IMMEDIATE:
            # "The system will stop the automated chain and alert staff."
            return ChainOutcome(preempt=True, alert="immediate")
        a2_payload = {"upstream_a2": envelope.model_dump(mode="json")}
        intent = (upstream_intent or "")

        # A3 runs only where both halves of its trigger hold. Everything else
        # that needs an answer goes straight to A4 -- a price question has no
        # slots to propose.
        nxt = "A3" if intent in {i.value for i in A3_TRIGGER_INTENTS} else "A4"

        if envelope.level is UrgencyLevel.SAME_DAY:
            # Staff are paged, and the work still proceeds: a same_day case
            # usually still needs a reply, and having one ready saves the
            # person who picks it up from starting from a blank box.
            return ChainOutcome(steps=(ChainStep(nxt, a2_payload),), alert="same_day")
        return ChainOutcome(steps=(ChainStep(nxt, a2_payload),))

    if agent_id == "A3":
        # Options or not, A4 drafts the reply. When A3 found nothing it sets
        # escalate and writes unavailable_note, and A4 turning that into "I
        # could not find anything that week, shall I look further out?" is more
        # use to the customer than silence.
        return ChainOutcome(
            steps=(ChainStep("A4", {
                "upstream_a3": envelope.model_dump(mode="json"),
                # The worker attaches availability_summary here; the envelope
                # cannot carry it, because A3Output forbids extra fields and
                # the count is a runtime fact rather than an agent claim.
            }),)
        )

    return ChainOutcome()
