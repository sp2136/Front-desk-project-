"""Turning a customer's reply into a booking, with no staff involvement.

THE POINT OF THIS MODULE

A3 proposes options, A4 writes them into a message, the message goes out. Then
the customer replies "2" or "friday works" -- and without this, the only way
that becomes a booking is a person reading the thread and clicking. That is the
front-desk work the archetype exists to remove, and leaving it in makes the
whole system a slower way to do what WhatsApp already did.

WHAT IT DOES NOT CHANGE

The agent still writes nothing. Section 4 / A3: "You never reserve, confirm or
hold anything." Section 1.2 Law 1: "There is exactly one write path and it is
application code." This IS that path. The matching below is deterministic
string and index comparison -- not a model call -- so a booking can never be
created by something that was persuaded to create one.

The customer is the one who authorises it. "No human intervention" here means
no STAFF intervention; the person whose appointment it is still has to say yes,
and that reply is the authorisation the soft lock is committed against.

MATCHING IS DELIBERATELY NARROW

An ordinal ("2"), the option's own time, or an unambiguous day name. Anything
else -- "maybe thursday?", "either is fine", two options named at once -- does
not match, and falls through to the normal agent chain where a person sees it.
A wrong match books a stranger into the wrong slot, so ambiguity resolves to
"not a confirmation" every time.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from sqlalchemy import desc

from app.models import Booking, Offer
from app.runtime import audit, reminders
from app.runtime.booking import SlotUnavailable, acquire_soft_lock, commit_booking

OFFER_TTL_HOURS = 48

_DAYS = ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday")
_ORDINALS = {
    "1": 0, "first": 0, "one": 0, "pehla": 0, "pehlu": 0,
    "2": 1, "second": 1, "two": 1, "biju": 1, "dusra": 1,
    "3": 2, "third": 2, "three": 2, "trija": 2, "teesra": 2,
}
_AFFIRMATIVE = ("yes", "ok", "okay", "sure", "confirm", "confirmed", "done", "please",
                "ha", "haa", "chalse", "theek", "thik", "barabar", "ji")

# Words that mean the customer is still deciding. A day name or a clock time
# inside a hedged sentence is a question, not an acceptance -- "maybe thursday?"
# and "thursday" look nearly identical to a regex and mean opposite things, so
# hedged text is excluded from the fuzzy matchers entirely. Ordinals survive,
# because "2?" is still a choice.
_HEDGES = ("maybe", "perhaps", "might", "possibly", "not sure", "either", " or ",
           "what about", "can i instead", "shayad", "kadach", "?")


@dataclass(frozen=True)
class Confirmation:
    matched: bool
    option: dict | None = None
    offer_id: int | None = None
    reason: str = ""


def record_offer(scope, *, customer_ref: str, options: list[dict],
                 decision_id: int | None = None, service_id: str | None = None,
                 now: datetime | None = None) -> Offer | None:
    """Called when a message containing slot options actually goes out."""
    if not options:
        return None
    now = now or datetime.now(UTC)
    # Supersede any earlier open offer: only the most recent set of options was
    # actually put in front of this customer.
    for prior in scope.all(Offer, Offer.customer_ref == customer_ref,
                           Offer.state == "open"):
        prior.state = "superseded"
    row = scope.add(Offer(
        customer_ref=customer_ref, decision_id=decision_id, service_id=service_id,
        options=options, state="open",
        expires_at=now + timedelta(hours=OFFER_TTL_HOURS),
    ))
    scope.flush()
    return row


def open_offer(scope, customer_ref: str, now: datetime | None = None) -> Offer | None:
    now = now or datetime.now(UTC)
    return scope.session.execute(
        scope.query(Offer)
        .where(Offer.customer_ref == customer_ref, Offer.state == "open",
               Offer.expires_at > now)
        .order_by(desc(Offer.id)).limit(1)
    ).scalars().first()


def match_reply(offer: Offer, body: str) -> Confirmation:
    """Deterministic match of a reply against the options that were offered."""
    options = list(offer.options or [])
    if not options:
        return Confirmation(False, reason="offer had no options")

    text = body.strip().lower()
    if not text:
        return Confirmation(False, reason="empty reply")

    # A bare yes is only unambiguous when there was exactly one option.
    if text in _AFFIRMATIVE or text.rstrip("!.") in _AFFIRMATIVE:
        if len(options) == 1:
            return Confirmation(True, options[0], offer.id, "affirmative, single option")
        return Confirmation(False, reason="affirmative but several options offered")

    # Ordinal: "2", "second", "biju".
    for token in re.findall(r"[a-z0-9]+", text):
        if token in _ORDINALS:
            idx = _ORDINALS[token]
            if idx < len(options):
                return Confirmation(True, options[idx], offer.id, f"ordinal {token}")
            return Confirmation(False, reason=f"ordinal {token} out of range")

    if any(h in text for h in _HEDGES):
        return Confirmation(False, reason="reply is hedged or a question")

    # Day name, but only when exactly one option falls on that day.
    named = [d for d in _DAYS if d in text or d[:3] in re.findall(r"[a-z]+", text)]
    if len(named) == 1:
        day = named[0]
        hits = [o for o in options if _weekday_of(o.get("starts_at", "")) == day]
        if len(hits) == 1:
            return Confirmation(True, hits[0], offer.id, f"day name {day}")
        if len(hits) > 1:
            return Confirmation(False, reason=f"{len(hits)} options on {day}")
    elif len(named) > 1:
        return Confirmation(False, reason="more than one day named")

    # The option's own clock time. Collected across ALL options rather than
    # returning the first hit: three options at the same hour on three
    # different days are not distinguished by the hour, and first-wins there
    # books whichever happened to be listed first.
    clock_hits = [o for o in options if _mentions_time(text, o.get("starts_at", ""))]
    if len(clock_hits) == 1:
        return Confirmation(True, clock_hits[0], offer.id, "clock time")
    if len(clock_hits) > 1:
        return Confirmation(
            False, reason=f"{len(clock_hits)} options share that time")

    return Confirmation(False, reason="no unambiguous option in the reply")


def _mentions_time(text: str, iso: str) -> bool:
    try:
        dt = datetime.fromisoformat(iso)
    except (ValueError, TypeError):
        return False
    hour12 = dt.hour % 12 or 12
    forms = {
        f"{dt.hour}:{dt.minute:02d}",
        f"{dt.hour:02d}:{dt.minute:02d}",
        f"{hour12}:{dt.minute:02d}",
    }
    if dt.minute == 0:
        suffix = "am" if dt.hour < 12 else "pm"
        forms |= {f"{hour12}{suffix}", f"{hour12} {suffix}"}
    return any(f in text for f in forms)


def _weekday_of(iso: str) -> str | None:
    try:
        return _DAYS[datetime.fromisoformat(iso).weekday()]
    except (ValueError, TypeError, IndexError):
        return None


def try_confirm(scope, *, customer_ref: str, body: str, customer_name: str | None = None,
                language: str = "en", now: datetime | None = None
                ) -> tuple[Booking | None, Confirmation]:
    """Match a reply and, if it matches, book it. Returns (booking, match).

    A failed lock is not an error the customer caused: somebody else took the
    slot between the offer and the reply, which is exactly the race the soft
    lock exists to resolve. It returns no booking and the message falls through
    to the agent chain, where A3 proposes fresh options.
    """
    now = now or datetime.now(UTC)
    offer = open_offer(scope, customer_ref, now)
    if offer is None:
        return None, Confirmation(False, reason="no open offer")

    match = match_reply(offer, body)
    if not match.matched or not match.option:
        return None, match

    slot_id = match.option.get("slot_id")

    # The service must be known. An earlier version fell back to a made-up
    # "svc_default", which books a real person into a real slot for a service
    # nobody identified -- a fabricated fact with a diary entry attached, which
    # is worse than any invented price. If A1 could not name the service, this
    # is not a confirmation we can close: it goes to a person.
    service_id = offer.service_id or match.option.get("service_id")
    if not service_id:
        return None, Confirmation(
            False, reason="service not identified; a person must confirm what was booked"
        )

    try:
        lock = acquire_soft_lock(scope, slot_id, ttl_s=120, now=now)
        booking = commit_booking(
            scope, lock, customer_ref=customer_ref, service_id=service_id,
            customer_name=customer_name, language=language, now=now,
        )
    except SlotUnavailable as exc:
        audit.record(scope, actor="app", action="confirm_lost_race",
                     subject_type="offer", subject_id=offer.id,
                     data={"slot_id": slot_id, "detail": str(exc)})
        return None, Confirmation(False, reason=f"slot taken: {exc}")

    offer.state = "confirmed"
    reminders.schedule_for_booking(scope, booking, now=now)
    scope.flush()
    audit.record(scope, actor="customer", action="booking_confirmed_by_customer",
                 subject_type="booking", subject_id=booking.id,
                 data={"offer_id": offer.id, "matched_on": match.reason,
                       "slot_id": slot_id})
    return booking, match
