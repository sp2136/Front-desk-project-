"""Source facts: what a draft is allowed to have been built from.

Section 2.4 asks the guard to reject any number that "does not appear in SOURCE
FACTS", which means SOURCE FACTS has to be a real, assembled artefact rather
than a gesture. Stage 1 passed the agent's own `evidence` array, which is
circular: an agent that invents a price also invents the evidence line for it.

So the facts are assembled by the RUNTIME from what it actually retrieved --
the catalogue rows it pre-fetched, the FAQ answers it looked up, the slot
options a proposer returned, the policy block. The agent does not get to
contribute to the set its output is checked against.

The agent's `evidence` is still recorded, and is still useful: it is how you
find out whether an agent cites its sources honestly. It is just not the
yardstick.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field


@dataclass
class SourceFacts:
    """Everything the runtime retrieved for this call, in one place."""

    blocks: dict[str, object] = field(default_factory=dict)

    def add(self, name: str, value: object) -> SourceFacts:
        if value not in (None, [], {}):
            self.blocks[name] = value
        return self

    def render(self) -> str:
        if not self.blocks:
            # An empty fact set is not an error, but it does mean every number
            # in the draft is unsourced -- which is exactly what the guard
            # should conclude.
            return "(no facts were retrieved for this call)"
        return json.dumps(self.blocks, ensure_ascii=False, default=str, indent=1)

    def as_text(self) -> str:
        return self.render()

    def numeric_vocabulary(self) -> set[str]:
        """Every number a draft may legitimately contain, given these facts.

        The naive version of this -- scanning the rendered JSON for digits --
        rejects correct drafts, because facts carry timestamps as
        "2026-10-16T18:00:00+05:30" while a front desk writes "Fri 16 Oct,
        6:00 PM". The 6 is not literally in the facts, and neither is an hour
        written without its leading zero.

        So timestamps are expanded into the forms a human would actually write:
        24-hour and 12-hour, with and without a leading zero, plus the day and
        month numbers. Leading zeros are stripped throughout, so "04" and "4"
        compare equal.

        This keeps the rule aimed at what it is for -- an invented price, an
        invented duration, an invented lead time -- instead of firing on every
        correctly-rendered appointment time, which is how a safety control
        teaches staff to ignore it.
        """
        import re
        from datetime import datetime

        blob = self.render()
        vocab: set[str] = set()

        for raw in re.findall(r"\d[\d,]*(?:\.\d+)?", blob):
            vocab.add(raw.replace(",", "").lstrip("0") or "0")

        for iso in re.findall(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?[^\"\s]*", blob):
            try:
                dt = datetime.fromisoformat(iso)
            except ValueError:
                continue
            hour12 = dt.hour % 12 or 12
            for part in (dt.year, dt.month, dt.day, dt.hour, dt.minute, hour12):
                vocab.add(str(part).lstrip("0") or "0")
            # "6:30" and "18:30" as written, minutes zero-padded as a human would.
            vocab.add(f"{hour12}:{dt.minute:02d}".lstrip("0"))
            vocab.add(f"{dt.hour}:{dt.minute:02d}".lstrip("0"))
            vocab.add(f"{dt.hour:02d}:{dt.minute:02d}".lstrip("0"))

        return vocab


def from_job_context(job_payload: dict, prefetched: dict | None = None,
                     policy_block: dict | None = None) -> SourceFacts:
    """Build the fact set from what the pipeline retrieved for this job."""
    facts = SourceFacts()
    for name, value in (prefetched or {}).items():
        facts.add(name, value)
    facts.add("policy_block", policy_block)
    # Upstream agent outputs count as facts only where they carry retrieved
    # data: A3's slot options are real availability, A1's intent is a judgment.
    upstream = job_payload.get("upstream_a3", {})
    if upstream:
        facts.add("slot_options", upstream.get("options"))
    return facts
