"""Spend and volume caps, and the kill switch.

Section 10: "A per-tenant daily token cap and message cap, each of which
disables the agent rather than continuing to spend, is what stops a prompt loop
or a spam flood from turning into a bill you cannot pass on. Set them before the
first client, not after the first incident."

Two properties worth being deliberate about:

  Preflight, not postflight. The cap is checked before the model call using a
  conservative estimate. Checking afterwards means the call that breaches the
  cap has already been paid for, and a loop breaches it many times before anyone
  notices.

  Disable loudly. Breaching the cap writes disabled_at and disabled_reason and
  emits an audit row. A tenant silently going dark is worse than a bill, because
  the value proposition is that nothing goes unanswered.
"""
from __future__ import annotations

from datetime import UTC, datetime
from zoneinfo import ZoneInfo

from app.config import settings
from app.models import UsageCounter
from app.runtime.errors import CapExceeded, KillSwitchEngaged
from app.schemas.tenant import TenantConfig


def tenant_day(cfg: TenantConfig, now: datetime | None = None) -> str:
    """Counters roll over at the tenant's local midnight, not UTC. A Surat
    clinic's day ends at 00:00 IST; a UTC rollover would reset caps at 05:30
    local and make the digest in A8 disagree with the owner's own sense of
    'today'."""
    now = now or datetime.now(UTC)
    return now.astimezone(ZoneInfo(cfg.timezone)).strftime("%Y-%m-%d")


def cost_micros(input_tokens: int, output_tokens: int,
                cached_input_tokens: int = 0) -> int:
    """Cost of one call, in micro-rupees.

    Cached input is billed separately and far cheaper. The API reports it as a
    distinct field precisely because it is not the same thing as fresh input,
    and the earlier version of this function ignored it entirely -- so once
    prompt caching was switched on, a tenant's recorded spend simply stopped
    including most of what they actually read. Undercounting a cap is the one
    direction that matters, because the cap is what stands between a prompt
    loop and a bill.
    """
    return (
        input_tokens * settings.input_token_micros
        + output_tokens * settings.output_token_micros
        + cached_input_tokens * settings.cache_read_token_micros
    )


class CapGuard:
    def __init__(self, scope, cfg: TenantConfig) -> None:
        self._scope = scope
        self._cfg = cfg
        self._day = tenant_day(cfg)

    def _counter(self) -> UsageCounter:
        row = self._scope.one_or_none(UsageCounter, UsageCounter.day == self._day)
        if row is None:
            row = self._scope.add(UsageCounter(day=self._day))
            self._scope.flush()
        return row

    def check_kill_switch(self) -> None:
        if settings.global_kill_switch:
            raise KillSwitchEngaged("global kill switch is engaged")
        if self._cfg.kill_switch:
            raise KillSwitchEngaged(f"kill switch engaged for tenant {self._cfg.tenant_id}")

    def preflight(self, estimated_input: int, estimated_output: int) -> None:
        """Raise before spending if this call would cross either cap."""
        self.check_kill_switch()
        row = self._counter()

        if row.disabled_at is not None:
            raise CapExceeded(
                f"tenant {self._cfg.tenant_id} disabled for {self._day}: {row.disabled_reason}"
            )

        cap_micros = self._cfg.daily_token_cap_inr * 1_000_000
        projected = row.cost_micros + cost_micros(estimated_input, estimated_output)
        if projected > cap_micros:
            self._disable(row, "token_cap")
            raise CapExceeded(
                f"token cap INR {self._cfg.daily_token_cap_inr}/day would be exceeded "
                f"({projected / 1_000_000:.2f} projected)"
            )

        if row.messages_sent >= self._cfg.daily_message_cap:
            self._disable(row, "message_cap")
            raise CapExceeded(f"message cap {self._cfg.daily_message_cap}/day reached")

    def _disable(self, row: UsageCounter, reason: str) -> None:
        row.disabled_at = datetime.now(UTC)
        row.disabled_reason = reason
        self._scope.flush()

    def record_usage(self, input_tokens: int, output_tokens: int,
                     cached_input_tokens: int = 0) -> UsageCounter:
        row = self._counter()
        row.input_tokens += input_tokens + cached_input_tokens
        row.output_tokens += output_tokens
        row.cost_micros += cost_micros(input_tokens, output_tokens, cached_input_tokens)
        self._scope.flush()
        return row

    def record_message_sent(self, n: int = 1) -> UsageCounter:
        row = self._counter()
        row.messages_sent += n
        self._scope.flush()
        return row

    def snapshot(self) -> dict:
        row = self._counter()
        cap_micros = self._cfg.daily_token_cap_inr * 1_000_000
        return {
            "day": self._day,
            "spend_inr": round(row.cost_micros / 1_000_000, 4),
            "token_cap_inr": self._cfg.daily_token_cap_inr,
            "pct_of_token_cap": round(100 * row.cost_micros / cap_micros, 1),
            "messages_sent": row.messages_sent,
            "message_cap": self._cfg.daily_message_cap,
            "disabled_at": row.disabled_at,
            "disabled_reason": row.disabled_reason,
        }
