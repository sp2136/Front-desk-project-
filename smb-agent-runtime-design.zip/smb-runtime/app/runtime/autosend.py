"""The auto-send whitelist and the conditions to widen it. Section 4 / A4.

| Intent              | Auto-send at launch? | Condition to widen                 |
|---------------------|----------------------|------------------------------------|
| location_hours      | Yes                  | From day one - zero risk, high vol |
| service_enquiry     | Yes, from FAQ only   | Approval rate > 90% over 50 drafts |
| book (options)      | No                   | Approval rate > 95% over 100       |
| price_enquiry       | No                   | Only once the owner confirms the   |
|                     |                      | catalogue is current               |
| reschedule / cancel | No                   | Policy-sensitive; human indefinitely|
| complaint           | Never                | -                                  |
| Anything A2 != routine | Never             | -                                  |

TWO THINGS THIS FILE RESOLVES

Section 12 stage 3 says "A4 Reply Copilot, HUMAN-APPROVE ONLY", while the
table above says location_hours auto-sends from day one. Those are not in
conflict: §12 is the build order and the table is the target state. Stage 3
ships with every tenant's whitelist EMPTY. The table is how you widen
afterwards, once drafts exist to measure.

And "Condition to widen" is prose in the spec, which means in practice it
becomes a judgment call made by whoever is in a hurry. `readiness()` turns it
into a number the console can show, so widening is a decision with evidence
rather than a feeling about how things have been going.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class WidenRule(StrEnum):
    DAY_ONE = "day_one"
    APPROVAL_RATE = "approval_rate"
    OWNER_CONFIRMS_CATALOGUE = "owner_confirms_catalogue"
    NEVER = "never"
    HUMAN_INDEFINITELY = "human_indefinitely"


@dataclass(frozen=True)
class WidenPolicy:
    intent: str
    rule: WidenRule
    min_approval_rate: float | None = None
    min_drafts: int | None = None
    note: str = ""


POLICY: dict[str, WidenPolicy] = {
    "location_hours": WidenPolicy(
        "location_hours", WidenRule.DAY_ONE,
        note="zero risk, high volume"),
    "service_enquiry": WidenPolicy(
        "service_enquiry", WidenRule.APPROVAL_RATE, 0.90, 50,
        note="only if answered wholly from FAQ"),
    "book": WidenPolicy(
        "book", WidenRule.APPROVAL_RATE, 0.95, 100,
        note="offering options, never confirming"),
    "price_enquiry": WidenPolicy(
        "price_enquiry", WidenRule.OWNER_CONFIRMS_CATALOGUE,
        note="requires the owner to confirm the catalogue is current"),
    "reschedule": WidenPolicy(
        "reschedule", WidenRule.HUMAN_INDEFINITELY, note="policy-sensitive"),
    "cancel": WidenPolicy(
        "cancel", WidenRule.HUMAN_INDEFINITELY, note="policy-sensitive"),
    "complaint": WidenPolicy("complaint", WidenRule.NEVER),
}

# Section 4 / A4, final row: "Anything where A2 != routine | Never".
NEVER_AUTO_SEND_UNLESS_ROUTINE = True


@dataclass(frozen=True)
class Readiness:
    intent: str
    eligible: bool
    reason: str
    approval_rate: float | None = None
    drafts: int = 0
    needed_drafts: int | None = None


def readiness(intent: str, *, approved: int, resolved: int,
              catalogue_confirmed: bool = False) -> Readiness:
    """Has this intent earned auto-send yet?

    `resolved` counts drafts a human actually decided on. Drafts still sitting
    in the queue are not evidence of anything, and counting them would let an
    unattended queue argue for widening.
    """
    policy = POLICY.get(intent)
    if policy is None:
        return Readiness(intent, False, "no widening policy for this intent")

    if policy.rule is WidenRule.NEVER:
        return Readiness(intent, False, "never auto-sent")
    if policy.rule is WidenRule.HUMAN_INDEFINITELY:
        return Readiness(intent, False, f"human indefinitely ({policy.note})")
    if policy.rule is WidenRule.DAY_ONE:
        return Readiness(intent, True, f"eligible from day one ({policy.note})")
    if policy.rule is WidenRule.OWNER_CONFIRMS_CATALOGUE:
        return Readiness(
            intent, catalogue_confirmed,
            "catalogue confirmed current by the owner" if catalogue_confirmed
            else "blocked until the owner confirms the catalogue is current",
        )

    rate = (approved / resolved) if resolved else None
    if resolved < (policy.min_drafts or 0):
        return Readiness(
            intent, False,
            f"{resolved} of {policy.min_drafts} drafts reviewed so far",
            approval_rate=rate, drafts=resolved,
            needed_drafts=(policy.min_drafts or 0) - resolved,
        )
    if rate is None or rate <= (policy.min_approval_rate or 1.0):
        return Readiness(
            intent, False,
            f"approval rate {rate:.0%} does not clear "
            f"{policy.min_approval_rate:.0%}",
            approval_rate=rate, drafts=resolved,
        )
    return Readiness(
        intent, True,
        f"approval rate {rate:.0%} over {resolved} drafts clears "
        f"{policy.min_approval_rate:.0%}",
        approval_rate=rate, drafts=resolved,
    )


def blocked_by_urgency(a2_level: str | None, a2_required: bool = True) -> bool:
    """Final row of the table: "Anything where A2 != routine | Never".

    `a2_required` distinguishes two situations that an earlier version of this
    function collapsed, with a consequence worth spelling out.

      A2 ran and returned same_day or immediate -> blocked. Obviously.
      A2 was never triggered for this intent    -> NOT blocked.

    A2's trigger covers book, service_enquiry, complaint, follow_up_existing
    and reschedule. Someone asking opening hours gets no urgency screen at all,
    so their draft has no level -- and treating a missing level as "not
    routine" meant location_hours could never auto-send. That is the one intent
    section 4 / A4 marks "Yes - from day one", so the reading that blocked it
    made a specified behaviour unreachable, which is how you know the reading
    was wrong rather than cautious.

    An intent that SHOULD have been screened and has no level is still blocked:
    that is a chain fault, not an exemption.
    """
    if not NEVER_AUTO_SEND_UNLESS_ROUTINE:
        return False
    if a2_level is not None:
        return a2_level != "routine"
    return a2_required
