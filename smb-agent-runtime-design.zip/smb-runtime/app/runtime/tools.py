"""Tool registry and scoping.

Section 1.2, Law 1: "Agents read widely and write nothing. There is exactly one
write path and it is application code."

The enforcement is structural, not textual. Tools declare writes=True; the
agent-facing resolver (build_toolbelt) raises WriteToolRefused rather than
returning them. An agent therefore cannot call a write tool even if its prompt
were corrupted into trying -- the callable is not in its belt.

Every tool receives a TenantScope as its first argument and has no other route
to the database, which is how the appendix's "all are tenant-scoped at the data
layer, never by prompt instruction" is satisfied.
"""
from __future__ import annotations

import hashlib
import json
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from app.models import ToolCall
from app.runtime.errors import WriteToolRefused


@dataclass(frozen=True)
class ToolSpec:
    name: str
    version: str
    fn: Callable[..., Any]
    writes: bool = False
    archetypes: frozenset[str] = field(default_factory=frozenset)
    description: str = ""

    @property
    def shared(self) -> bool:
        return not self.archetypes


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, ToolSpec] = {}

    def register(
        self,
        name: str,
        version: str = "1",
        *,
        writes: bool = False,
        archetypes: str | None = None,
        description: str = "",
    ) -> Callable:
        def deco(fn: Callable) -> Callable:
            if name in self._tools:
                raise ValueError(f"tool already registered: {name}")
            self._tools[name] = ToolSpec(
                name=name,
                version=version,
                fn=fn,
                writes=writes,
                archetypes=frozenset(archetypes or ""),
                description=description,
            )
            return fn

        return deco

    def get(self, name: str) -> ToolSpec:
        if name not in self._tools:
            raise KeyError(f"unknown tool: {name}")
        return self._tools[name]

    def names(self) -> list[str]:
        return sorted(self._tools)

    def write_tools(self) -> list[str]:
        return sorted(n for n, t in self._tools.items() if t.writes)


registry = ToolRegistry()


class BoundTool:
    """A read-only tool bound to one tenant scope and one agent run.

    Calling it records a ToolCall row. The result is hashed into result_ref so
    the audit log can prove which bytes the agent saw without storing a second
    copy of potentially sensitive rows.
    """

    def __init__(self, spec: ToolSpec, scope, run_id: int | None) -> None:
        self._spec = spec
        self._scope = scope
        self._run_id = run_id

    @property
    def name(self) -> str:
        return self._spec.name

    def __call__(self, **kwargs: Any) -> Any:
        started = time.perf_counter()
        result = self._spec.fn(self._scope, **kwargs)
        latency_ms = int((time.perf_counter() - started) * 1000)
        payload = json.dumps(result, default=str, sort_keys=True)
        self._scope.add(
            ToolCall(
                run_id=self._run_id,
                tool_name=self._spec.name,
                tool_version=self._spec.version,
                args=kwargs,
                result_ref=hashlib.sha256(payload.encode()).hexdigest()[:32],
                    row_count=(
                    len(result) if isinstance(result, list)
                    else (0 if result is None else 1)
                ),
                latency_ms=latency_ms,
            )
        )
        return result


def build_toolbelt(
    tool_names: list[str], scope, run_id: int | None = None
) -> dict[str, BoundTool]:
    """Resolve an agent's declared tools into callables. Refuses writes."""
    belt: dict[str, BoundTool] = {}
    for name in tool_names:
        spec = registry.get(name)
        if spec.writes:
            raise WriteToolRefused(
                f"tool '{name}' is marked as a write and can never be given to an agent; "
                "writes belong to application code (spec section 1.2, Law 1)"
            )
        belt[name] = BoundTool(spec, scope, run_id)
    return belt


def toolbelt_version(tool_names: list[str]) -> str:
    """Section 1.4: tool version on every call. One hash over the whole belt so a
    single field in agent_runs pins every tool the call could have reached."""
    material = ";".join(f"{n}@{registry.get(n).version}" for n in sorted(tool_names))
    return hashlib.sha256(material.encode()).hexdigest()[:16]
