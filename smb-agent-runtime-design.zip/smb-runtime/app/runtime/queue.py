"""Database-backed job queue with idempotency keys.

Section 1.3: "Models are non-deterministic; delivery must not be." Hence
idempotency keys on enqueue and leases rather than deletes on claim.

Deliberately not Redis or SQS at stage 0. One fewer moving part to operate,
transactional with the event insert, and the interface below is narrow enough
that swapping the backend later touches this file only. Revisit when a single
Postgres cannot keep up, which for fourteen pilot tenants it will.
"""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import and_, or_, select, update
from sqlalchemy.exc import IntegrityError

from app.config import settings
from app.models import Job


def make_idempotency_key(tenant_id: str, agent_id: str, dedupe_key: str) -> str:
    """One job per (tenant, agent, source event). A retried webhook or a
    double-fired cron produces the same key and the insert is rejected."""
    return f"{tenant_id}:{agent_id}:{dedupe_key}"


def enqueue(scope, *, agent_id: str, dedupe_key: str, event_id: int | None = None,
            payload: dict | None = None, delay_seconds: int = 0) -> Job | None:
    """Returns the Job, or None if this exact job already exists."""
    key = make_idempotency_key(scope.tenant_id, agent_id, dedupe_key)
    job = Job(
        agent_id=agent_id,
        event_id=event_id,
        idempotency_key=key,
        payload=payload or {},
        available_at=datetime.now(UTC) + timedelta(seconds=delay_seconds),
    )
    scope.add(job)
    try:
        scope.flush()
    except IntegrityError:
        scope.session.rollback()
        return None
    return job


def claim(session, worker_id: str, limit: int = 1) -> list[Job]:
    """Lease the next claimable jobs across all tenants.

    Not tenant-scoped, by design: the worker is infrastructure and must see the
    whole queue to pick work. It immediately constructs a per-job TenantScope
    before touching anything else, and that is where isolation starts.
    """
    now = datetime.now(UTC)
    lease_until = now + timedelta(seconds=settings.job_lease_seconds)

    candidates = session.execute(
        select(Job.id)
        .where(
            and_(
                Job.state.in_(["pending", "retry"]),
                Job.available_at <= now,
                or_(Job.locked_until.is_(None), Job.locked_until < now),
            )
        )
        .order_by(Job.available_at)
        .limit(limit)
        .with_for_update(skip_locked=True)
        if session.bind.dialect.name == "postgresql"
        else select(Job.id)
        .where(
            and_(
                Job.state.in_(["pending", "retry"]),
                Job.available_at <= now,
                or_(Job.locked_until.is_(None), Job.locked_until < now),
            )
        )
        .order_by(Job.available_at)
        .limit(limit)
    ).scalars().all()

    if not candidates:
        return []

    session.execute(
        update(Job)
        .where(Job.id.in_(candidates))
        .values(state="running", locked_by=worker_id, locked_until=lease_until,
                attempts=Job.attempts + 1)
    )
    session.commit()
    return list(session.execute(select(Job).where(Job.id.in_(candidates))).scalars().all())


def complete(session, job_id: int, state: str, error: str | None = None) -> None:
    session.execute(
        update(Job)
        .where(Job.id == job_id)
        .values(state=state, locked_by=None, locked_until=None, last_error=error)
    )
    session.commit()


def fail(session, job: Job, error: str) -> str:
    """Retry with linear backoff until max_job_attempts, then park as 'dead'.

    Parked, not dropped. A dead job is an unanswered customer and belongs on the
    exceptions list that A8 reports, not in a log file nobody reads.
    """
    if job.attempts >= settings.max_job_attempts:
        complete(session, job.id, "dead", error)
        return "dead"
    retry_at = datetime.now(UTC) + timedelta(seconds=30 * job.attempts)
    session.execute(
        update(Job)
        .where(Job.id == job.id)
        .values(state="retry", available_at=retry_at, locked_by=None,
                locked_until=None, last_error=error)
    )
    session.commit()
    return "retry"
