"""Append-only, hash-chained audit log.

Section 1.3 lists the required contents: prompt version, tool calls, tokens,
latency, approver, outcome. "Without this you cannot tell a prompt regression
from a traffic change."

The chain is per tenant. Each row hashes its own contents plus the previous
row's hash, so a row cannot be edited or removed without breaking verification.
This costs one extra read per write and buys the ability to answer "prove what
you sent in my name", which in a referral market is the only question that ever
really matters.

Two details that are easy to get wrong and expensive to discover later:

  The hash is computed BEFORE the insert, not after. Writing the row first and
  hashing second leaves a window in which an unhashed row exists, and on a
  NOT NULL column it simply fails.

  Timestamps are normalised through _iso(). SQLite does not preserve tzinfo
  across a round trip, so a naive datetime read back from the database would
  hash differently from the aware one that was written, and every chain would
  appear broken. Naive values are therefore read as UTC.
"""
from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime

from sqlalchemy import desc, select

from app.models import AuditLog


def _iso(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%S.%f")


def _digest(tenant_id: str, at: datetime, actor: str, action: str, subject_type: str,
            subject_id: str, data: dict, prev_hash: str) -> str:
    material = json.dumps(
        {
            "tenant_id": tenant_id,
            "at": _iso(at),
            "actor": actor,
            "action": action,
            "subject_type": subject_type,
            "subject_id": subject_id,
            "data": data,
            "prev_hash": prev_hash,
        },
        sort_keys=True,
        default=str,
    )
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def _head_hash(scope) -> str:
    last = scope.session.execute(
        select(AuditLog)
        .where(AuditLog.tenant_id == scope.tenant_id)
        .order_by(desc(AuditLog.id))
        .limit(1)
    ).scalars().first()
    return last.hash if last else ""


def record(scope, *, actor: str, action: str, subject_type: str, subject_id: str,
           data: dict | None = None) -> AuditLog:
    data = data or {}
    at = datetime.now(UTC)
    prev_hash = _head_hash(scope)
    row = AuditLog(
        at=at,
        actor=actor,
        action=action,
        subject_type=subject_type,
        subject_id=str(subject_id),
        data=data,
        prev_hash=prev_hash,
        hash=_digest(scope.tenant_id, at, actor, action, subject_type,
                     str(subject_id), data, prev_hash),
    )
    scope.add(row)
    scope.flush()
    return row


def verify_chain(scope) -> tuple[bool, int | None]:
    """Recompute the chain. Returns (ok, first_broken_row_id).

    Run this nightly. A break is either tampering or a bug in a migration, and
    both are things to hear about from your own cron rather than from a client.
    """
    rows = scope.session.execute(
        select(AuditLog).where(AuditLog.tenant_id == scope.tenant_id).order_by(AuditLog.id)
    ).scalars().all()
    prev = ""
    for row in rows:
        expected = _digest(
            row.tenant_id, row.at, row.actor, row.action, row.subject_type,
            row.subject_id, row.data, prev,
        )
        if row.prev_hash != prev or row.hash != expected:
            return False, row.id
        prev = row.hash
    return True, None
