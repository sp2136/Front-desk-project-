"""The guard pass, section 2.4.

TWO LAYERS, AND WHY

  deterministic_guard  Regex and Unicode checks. Free, runs on every draft,
                       never has an opinion it cannot justify with a span.
  model_guard          The section 2.4 release gate. Catches what rules cannot:
                       an unauthorised commitment phrased politely, advice
                       dressed as description, a red line crossed obliquely.

The deterministic layer covers only the conditions that are script-robust.
That is a deliberate limit, not laziness. Pattern-matching "guaranteed" or
"we will refund" works in English and fails completely on Roman-script
Gujarati, where the same commitment is "pakka karish" or anything else the
writer chose. A rule that fires on English and sleeps on Gujarati is worse
than no rule: it produces a false sense of coverage on exactly the traffic
that matters most here. So the semantic conditions belong to the model, and
the rules keep to what Unicode and arithmetic can settle.

THE ASYMMETRY (section 2.4, mirror of the escalation asymmetry in 11.2)

  "A blocked good message costs one staff click. A sent bad message costs
   the client relationship."

Therefore: reject recall is the gate, false-reject rate is merely reported;
an unavailable guard rejects rather than waving through; and unparseable
guard output rejects.
"""
from __future__ import annotations

import json
import re
import unicodedata

from app.config import settings
from app.prompts.guard import GUARD_VERSION
from app.runtime.errors import ModelUnavailable
from app.runtime.llm import LLMProvider
from app.runtime.prompts import store
from app.runtime.sourcefacts import SourceFacts
from app.schemas.agents import GuardOutput, GuardVerdict, GuardViolation

# A decimal point counts only when digits follow, so a sentence-final full stop
# is not absorbed into the number.
_NUMBER_RE = re.compile(r"\d[\d,]*(?:\.\d+)?")

# Section 2.4: "asks for a document, ID, card number or password over a
# messaging channel". These are nouns, not verbs, so they survive translation
# better than a commitment phrase would -- "aadhaar" is "aadhaar" in every
# script used here. Still English-leaning; the model guard is the real control.
_CREDENTIAL_TERMS = (
    "aadhaar", "aadhar", "pan card", "pan number", "card number", "cvv",
    "otp", "password", "upi pin", "atm pin", "account number", "ifsc",
    "passport number", "licence number", "license number",
)

# Internal information that must never reach a customer-facing draft.
_INTERNAL_TERMS = (
    "cost price", "our cost", "margin", "markup", "profit on", "staff note",
    "internal note", "wholesale price", "purchase price",
)

# language code -> the script its text is written in
_SCRIPT_FOR_LANG = {
    "gu": "GUJARATI", "hi": "DEVANAGARI", "en": "LATIN",
    "gu-Latn": "LATIN", "hi-Latn": "LATIN",
}


def _numbers(text: str) -> set[str]:
    """Numbers in a draft, leading zeros stripped so 04 and 4 compare equal."""
    out = set()
    for m in _NUMBER_RE.finditer(text):
        raw = m.group(0).replace(",", "")
        out.add(raw.lstrip("0") or "0")
    # A time written "6:30" is one claim, not two, so match it whole as well.
    for m in re.finditer(r"\d{1,2}:\d{2}", text):
        out.add(m.group(0).lstrip("0"))
    return out


def scripts_in(text: str) -> set[str]:
    """Scripts present in a string, ignoring digits, punctuation and spacing.

    Unicode name prefixes are used rather than codepoint ranges because the
    ranges are easy to get subtly wrong and this is a safety check.
    """
    found: set[str] = set()
    for ch in text:
        if not ch.isalpha():
            continue
        try:
            name = unicodedata.name(ch)
        except ValueError:
            continue
        head = name.split(" ")[0]
        if head in ("LATIN", "GUJARATI", "DEVANAGARI", "ARABIC", "BENGALI",
                    "TAMIL", "TELUGU", "CYRILLIC", "GREEK", "HAN", "HIRAGANA",
                    "KATAKANA", "HANGUL", "THAI", "HEBREW"):
            found.add(head)
    return found


def allowed_scripts(languages: list[str]) -> set[str]:
    return {_SCRIPT_FOR_LANG[lang] for lang in languages if lang in _SCRIPT_FOR_LANG}


def _spans(draft: str, needle: str) -> str:
    """Return the sentence containing a match, so the violation is actionable.

    Section 2.4 wants a quote. A rule that reports only its own name leaves the
    reviewer searching the draft for what went wrong.
    """
    low = draft.lower()
    i = low.find(needle.lower())
    if i < 0:
        return needle
    start = max(0, low.rfind(".", 0, i) + 1)
    end = low.find(".", i)
    end = len(draft) if end < 0 else end + 1
    return draft[start:end].strip()


def deterministic_guard(draft: str, facts: SourceFacts | str,
                        languages: list[str] | None = None) -> GuardOutput:
    """Rule layer. Script-robust checks only; see the module docstring."""
    # SourceFacts expands timestamps into the forms a human writes; a bare
    # string has no structure to expand, so it is scanned as-is.
    sourced = (facts.numeric_vocabulary() if isinstance(facts, SourceFacts)
               else _numbers(str(facts)))
    violations: list[GuardViolation] = []

    for n in sorted(_numbers(draft) - sourced):
        violations.append(GuardViolation(rule="unsourced_number", quote=_spans(draft, n)))

    low = draft.lower()
    for term in _CREDENTIAL_TERMS:
        if term in low:
            violations.append(
                GuardViolation(rule="credential_request", quote=_spans(draft, term))
            )
            break

    for term in _INTERNAL_TERMS:
        if term in low:
            violations.append(
                GuardViolation(rule="internal_information", quote=_spans(draft, term))
            )
            break

    if languages:
        stray = scripts_in(draft) - allowed_scripts(languages)
        for script in sorted(stray):
            violations.append(GuardViolation(rule="wrong_language", quote=script.lower()))

    if violations:
        # One sentence quoting three unsourced numbers is one thing to fix, not
        # three. Deduping on (rule, quote) keeps the staff queue readable.
        seen: set[tuple[str, str]] = set()
        unique = []
        for v in violations:
            key = (v.rule, v.quote)
            if key not in seen:
                seen.add(key)
                unique.append(v)
        return GuardOutput(verdict=GuardVerdict.REJECT, violations=unique, confidence=1.0)
    # Confidence 0.5 on a pass is honest: these rules clear a narrow set of
    # conditions and say nothing about the rest. The model guard decides.
    return GuardOutput(verdict=GuardVerdict.PASS, violations=[], confidence=0.5)


def _guard_system(languages: list[str]) -> str:
    return store.assemble("GUARD", {"languages": json.dumps(languages)}).text


def model_guard(provider: LLMProvider, draft: str, facts: SourceFacts | str,
                red_lines: list[str], languages: list[str]) -> GuardOutput:
    """Section 2.4's release gate. Fails closed in every failure mode."""
    source_text = facts.as_text() if isinstance(facts, SourceFacts) else str(facts)
    user = (
        f"<draft>\n{draft}\n</draft>\n"
        f"<source_facts>\n{source_text}\n</source_facts>\n"
        f"<red_lines>\n{json.dumps(red_lines)}\n</red_lines>\n"
    )
    try:
        result = provider.complete(
            _guard_system(languages), user,
            max_tokens=400, model=settings.guard_model, temperature=0.0,
        )
    except ModelUnavailable:
        # An absent gate is maximal uncertainty, and 2.4 says default to reject
        # when uncertain. No guard must never mean no check.
        return GuardOutput(
            verdict=GuardVerdict.REJECT,
            violations=[GuardViolation(rule="guard_unavailable", quote="")],
            confidence=1.0,
        )
    try:
        return GuardOutput.model_validate_json(result.text)
    except Exception:
        return GuardOutput(
            verdict=GuardVerdict.REJECT,
            violations=[
                GuardViolation(rule="guard_output_unparseable", quote=result.text[:200])
            ],
            confidence=1.0,
        )


def run_guard(provider: LLMProvider, draft: str, facts: SourceFacts | str,
              red_lines: list[str], languages: list[str]) -> GuardOutput:
    """Rules first (free), model second (cheap). Either may reject.

    The rule layer short-circuits: if arithmetic has already proven the draft
    quotes a number nobody supplied, there is nothing a second opinion can add
    and no reason to pay for one.
    """
    pre = deterministic_guard(draft, facts, languages)
    if pre.verdict is GuardVerdict.REJECT:
        return pre

    verdict = model_guard(provider, draft, facts, red_lines, languages)
    # Carry the rule layer's findings forward even on a model pass, so the
    # violation-rule distribution in the console counts both layers.
    return verdict


GUARD_PROMPT_VERSION = GUARD_VERSION
