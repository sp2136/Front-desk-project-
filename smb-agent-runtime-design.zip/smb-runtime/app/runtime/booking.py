"""The booking write path. Application code only -- never an agent tool.

Section 4 / A3: "Writes | None. App takes a soft lock with TTL, then commits on
confirmation."

Section 1.3: "Availability and locking | Database constraint + soft lock with
TTL | Two concurrent bookings must collide at the database, not in a prompt."

ACQUISITION IS ONE CONDITIONAL UPDATE

    UPDATE slots SET lock_token = ?, lock_expires_at = ?
     WHERE id = ? AND tenant_id = ?
       AND booking_id IS NULL
       AND (lock_token IS NULL OR lock_expires_at < now)

The affected-row count IS the answer: 1 means this caller holds the lock, 0
means somebody else got there first or the slot is already booked. There is no
read-then-write window for two callers to race through, which is what a
check-availability-then-lock implementation leaves open -- and that window is
exactly wide enough for a model call to sit in, which is how two customers end
up offered and then granted the same slot.

WHY A TTL RATHER THAN A PERMANENT HOLD

A customer who is offered three options and then stops replying must not take a
slot off the market forever. The lock expires and the slot returns to
availability with no cleanup job required: every query that matters treats an
expired lock as absent. A sweeper exists for tidiness, not for correctness.
"""
from __future__ import annotations

import secrets
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from sqlalchemy import and_, or_, update

from app.models import Booking, Resource, Slot
from app.runtime import audit

DEFAULT_TTL_SECONDS = 600


class SlotUnavailable(Exception):
    """The slot is booked, or another caller holds a live lock on it."""


@dataclass(frozen=True)
class SoftLock:
    slot_id: str
    token: str
    expires_at: datetime


def available_slots(scope, *, service_id: str | None = None,
                    from_dt: datetime | None = None, to_dt: datetime | None = None,
                    resource_id: str | None = None, now: datetime | None = None,
                    limit: int = 50) -> list[Slot]:
    """Open slots. An expired lock counts as open, with no sweeper required."""
    now = now or datetime.now(UTC)
    stmt = scope.query(Slot).where(
        Slot.booking_id.is_(None),
        or_(Slot.lock_token.is_(None), Slot.lock_expires_at < now),
    )
    if service_id:
        # Either the slot is pre-committed to this service, or it is open and
        # the resource can do it. The skill check happens in Python because
        # Resource.skills is a JSON array, and querying inside one portably
        # across SQLite and Postgres is not worth the obscurity at this scale.
        stmt = stmt.where(or_(Slot.service_id == service_id, Slot.service_id.is_(None)))
    if resource_id:
        stmt = stmt.where(Slot.resource_id == resource_id)
    if from_dt:
        stmt = stmt.where(Slot.starts_at >= from_dt)
    if to_dt:
        stmt = stmt.where(Slot.starts_at <= to_dt)
    # Over-fetch when a skill filter will follow, so the limit applies to what
    # the caller can actually be offered rather than to what SQL happened to
    # return before filtering.
    stmt = stmt.order_by(Slot.starts_at).limit(limit * 4 if service_id else limit)

    rows = list(scope.session.execute(stmt).scalars().all())
    if service_id:
        skilled = {
            r.id for r in scope.all(Resource)
            if r.active and (not r.skills or service_id in r.skills)
        }
        rows = [row for row in rows if row.resource_id in skilled][:limit]
    return rows


def acquire_soft_lock(scope, slot_id: str, ttl_s: int = DEFAULT_TTL_SECONDS,
                      now: datetime | None = None) -> SoftLock:
    """Take a TTL lock on one slot. Raises SlotUnavailable if someone else has it."""
    now = now or datetime.now(UTC)
    token = secrets.token_urlsafe(16)
    expires = now + timedelta(seconds=ttl_s)

    result = scope.session.execute(
        update(Slot)
        .where(
            and_(
                Slot.id == slot_id,
                Slot.tenant_id == scope.tenant_id,
                Slot.booking_id.is_(None),
                or_(Slot.lock_token.is_(None), Slot.lock_expires_at < now),
            )
        )
        .values(lock_token=token, lock_expires_at=expires)
    )
    if result.rowcount != 1:
        raise SlotUnavailable(f"slot {slot_id} is booked or already locked")

    scope.flush()
    audit.record(scope, actor="app", action="soft_lock_acquired", subject_type="slot",
                 subject_id=slot_id, data={"ttl_s": ttl_s, "expires_at": expires.isoformat()})
    return SoftLock(slot_id=slot_id, token=token, expires_at=expires)


def release_soft_lock(scope, lock: SoftLock) -> bool:
    result = scope.session.execute(
        update(Slot)
        .where(Slot.id == lock.slot_id, Slot.tenant_id == scope.tenant_id,
               Slot.lock_token == lock.token)
        .values(lock_token=None, lock_expires_at=None)
    )
    scope.flush()
    return result.rowcount == 1


def commit_booking(scope, lock: SoftLock, *, customer_ref: str,
                   service_id: str | None = None,
                   customer_name: str | None = None, language: str = "en",
                   now: datetime | None = None) -> Booking:
    """Turn a live lock into a booking. The lock token is the authorisation.

    Checking the token and the expiry in the UPDATE's WHERE clause rather than
    in Python means a lock that expired a millisecond ago cannot be committed by
    a caller who read it a millisecond before that.

    `service_id` is required when the slot itself is service-agnostic, which is
    the normal case: a slot is a time on a resource's calendar, and a booking is
    a time plus the service being performed in it. Defaulting it to something
    would mean guessing what the customer booked.
    """
    now = now or datetime.now(UTC)
    slot = scope.one_or_none(Slot, Slot.id == lock.slot_id)
    if slot is None:
        raise SlotUnavailable(f"unknown slot {lock.slot_id}")

    booked_service = service_id or slot.service_id
    if not booked_service:
        raise ValueError(
            f"slot {slot.id} is not bound to a service, so commit_booking needs "
            "an explicit service_id"
        )

    # A booking is the moment the business learns this customer exists, so the
    # customer record is created here. Without it, A7's recall sweep iterates
    # an empty table and nobody is ever found due -- which looks exactly like
    # "no one needs a nudge" and is in fact "we never wrote anyone down".
    from app.runtime.recurrence import get_or_create_customer

    get_or_create_customer(scope, customer_ref, name=customer_name, language=language)

    prior = len(scope.all(Booking, Booking.customer_ref == customer_ref))
    booking = scope.add(
        Booking(
            slot_id=slot.id, service_id=booked_service, resource_id=slot.resource_id,
            starts_at=slot.starts_at, duration_min=slot.duration_min,
            customer_ref=customer_ref, customer_name=customer_name,
            language=language, visit_count=prior + 1, state="confirmed",
        )
    )
    scope.flush()

    result = scope.session.execute(
        update(Slot)
        .where(
            and_(
                Slot.id == lock.slot_id,
                Slot.tenant_id == scope.tenant_id,
                Slot.lock_token == lock.token,
                Slot.lock_expires_at >= now,
                Slot.booking_id.is_(None),
            )
        )
        .values(booking_id=booking.id, lock_token=None, lock_expires_at=None)
    )
    if result.rowcount != 1:
        scope.session.rollback()
        raise SlotUnavailable(
            f"lock on slot {lock.slot_id} is expired or no longer held"
        )

    scope.flush()
    audit.record(scope, actor="app", action="booking_committed", subject_type="booking",
                 subject_id=booking.id,
                 data={"slot_id": slot.id, "starts_at": slot.starts_at.isoformat(),
                       "visit_count": booking.visit_count})
    return booking


def sweep_expired_locks(scope, now: datetime | None = None) -> int:
    """Tidiness, not correctness: availability already ignores expired locks."""
    now = now or datetime.now(UTC)
    result = scope.session.execute(
        update(Slot)
        .where(Slot.tenant_id == scope.tenant_id, Slot.lock_token.isnot(None),
               Slot.lock_expires_at < now)
        .values(lock_token=None, lock_expires_at=None)
    )
    scope.flush()
    return result.rowcount


def availability_summary(scope, *, service_id: str | None, exclude_slot_ids: set[str],
                         now: datetime | None = None, horizon_days: int = 7) -> dict:
    """Counts of open times NOT already offered, for A4 to cite verbatim.

    Section 4 / A4 permits no fact that is not in a context block, so "we have
    other times free" needs a number behind it or it cannot be said at all.
    This produces the number. It is a count, never a characterisation: "20
    other times this week" is a fact, "plenty of availability" is not, and the
    A4 prompt forbids the second.
    """
    now = now or datetime.now(UTC)
    rows = available_slots(
        scope, service_id=service_id, from_dt=now,
        to_dt=now + timedelta(days=horizon_days), now=now, limit=500,
    )
    remaining = [s for s in rows if s.id not in exclude_slot_ids]
    by_day: dict[str, int] = {}
    for slot in remaining:
        key = slot.starts_at.date().isoformat()
        by_day[key] = by_day.get(key, 0) + 1
    return {
        "not_listed_total": len(remaining),
        "horizon_days": horizon_days,
        "days_with_availability": len(by_day),
        "by_day": by_day,
    }
