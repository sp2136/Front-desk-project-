"""The VALIDATE column of section 1.1: identity, consent, dedupe, tenant ctx,
rate limit. All of it before a model is ever reached, because every one of these
is cheaper and more reliable as code than as a prompt instruction.
"""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy.exc import IntegrityError

from app.config import settings
from app.models import InboundEventRow, RateLimitBucket, Tenant
from app.runtime.errors import DuplicateEvent, RateLimited
from app.schemas.events import InboundEvent
from app.schemas.tenant import TenantConfig


def load_tenant_config(session, tenant_id: str) -> TenantConfig:
    tenant = session.get(Tenant, tenant_id)
    if tenant is None:
        raise KeyError(f"unknown tenant: {tenant_id}")
    cfg = dict(tenant.config or {})
    cfg.setdefault("tenant_id", tenant.id)
    cfg.setdefault("tenant_name", tenant.name)
    cfg.setdefault("business_type", tenant.business_type)
    cfg.setdefault("archetype", tenant.archetype)
    cfg["kill_switch"] = tenant.kill_switch
    # Unknown keys are dropped rather than passed through: TenantConfig forbids
    # extras, and a stale key in a JSON blob should not take a tenant offline.
    known = set(TenantConfig.model_fields)
    return TenantConfig(**{k: v for k, v in cfg.items() if k in known})


def persist_event(scope, event: InboundEvent) -> InboundEventRow:
    """Insert the event, letting the unique constraint decide duplication.

    The check-then-insert version of this function has a race that produces
    double replies under concurrent webhook delivery -- which WhatsApp does
    retry. Section 1.3: concurrent work must collide at the database.
    """
    row = InboundEventRow(
        channel=event.channel,
        external_id=event.external_id,
        dedupe_key=event.dedupe_key(),
        sender_ref=event.sender_ref,
        body=event.body,
        payload=event.raw,
        received_at=event.received_at,
    )
    scope.add(row)
    try:
        scope.flush()
    except IntegrityError as exc:
        scope.session.rollback()
        raise DuplicateEvent(f"event already seen: {event.dedupe_key()}") from exc

    if event.external_id is None:
        _enforce_content_dedupe_window(scope, row)
    return row


def _enforce_content_dedupe_window(scope, row: InboundEventRow) -> None:
    """For channels with no stable message id, an identical body inside the
    window is a duplicate -- a double-tapped web form, a retried IVR callback."""
    cutoff = row.received_at - timedelta(seconds=settings.dedupe_window_seconds)
    prior = scope.all(
        InboundEventRow,
        InboundEventRow.dedupe_key == row.dedupe_key,
        InboundEventRow.id != row.id,
        InboundEventRow.received_at >= cutoff,
    )
    if prior:
        raise DuplicateEvent(f"identical content within dedupe window: {row.dedupe_key}")


def enforce_rate_limit(scope, sender_ref: str, now: datetime | None = None) -> int:
    """Per-sender inbound cap. Protects the token cap from a single hostile or
    looping sender, and returns the current count so the console can show it."""
    now = now or datetime.now(UTC)
    window = settings.rate_limit_window_seconds
    bucket_start = datetime.fromtimestamp(
        (int(now.timestamp()) // window) * window, tz=UTC
    )
    row = scope.one_or_none(
        RateLimitBucket,
        RateLimitBucket.sender_ref == sender_ref,
        RateLimitBucket.window_start == bucket_start,
    )
    if row is None:
        row = scope.add(
            RateLimitBucket(sender_ref=sender_ref, window_start=bucket_start, count=0)
        )
    row.count += 1
    scope.flush()
    if row.count > settings.rate_limit_messages:
        raise RateLimited(
            f"sender {sender_ref} exceeded {settings.rate_limit_messages} "
            f"messages per {window}s"
        )
    return row.count
