"""Time-driven and event-driven sweeps for A6, A7 and A8.

Section 4 / A7: "Runs as a weekly sweep, outputs a batch of drafts for one
approval action." A8 likewise is a weekly cron. A6 fires when a visit is marked
complete.

All three enqueue jobs rather than calling agents directly, so they inherit the
idempotency keys, the caps, the kill switch and the audit trail that everything
else in the runtime gets. A sweep that called the model directly would be a
second, unaudited pipeline.
"""
from __future__ import annotations

import logging
from datetime import datetime

from app.models import Booking, Tenant
from app.runtime import metrics, queue, recurrence
from app.runtime.validate import load_tenant_config

log = logging.getLogger("sweeps")


def sweep_review_requests(scope, now: datetime, limit: int = 25) -> int:
    """A6: one job per newly completed visit that is eligible to be asked.

    Eligibility is decided here, not by the agent. Section 4 / A6 lists
    "asked within 90 days -> ask = false" among the model's rules, and it is
    also enforced before the call, because the cost of getting this wrong is a
    one-star review that would never otherwise have existed.
    """
    review_link = (scope.session.get(Tenant, scope.tenant_id).config or {}).get(
        "review_link", ""
    )
    if not review_link:
        # No link means no ask that could possibly work. Better to do nothing
        # than to draft an ask with a missing URL in it.
        return 0

    queued = 0
    for booking in scope.all(Booking, Booking.state == "completed"):
        if booking.review_asked or queued >= limit:
            continue
        customer = recurrence.get_or_create_customer(scope, booking.customer_ref)
        gate = recurrence.review_suppression(customer, now)
        if gate.suppressed:
            continue
        job = queue.enqueue(
            scope, agent_id="A6",
            dedupe_key=f"review:{booking.id}",
            payload={
                "event": {"channel": "cron", "sender_ref": booking.customer_ref},
                "booking": {
                    "booking_id": booking.id, "service_id": booking.service_id,
                    "date": booking.starts_at.date().isoformat(),
                    "resource_id": booking.resource_id,
                    "customer_name": booking.customer_name,
                    "visit_count": booking.visit_count,
                },
                "internal_notes": booking.internal_notes or "",
                "review_link": review_link,
                "prior_asks": {
                    "last_asked_at": customer.last_review_ask_at.isoformat()
                    if customer.last_review_ask_at else None
                },
                "history": [],
            },
        )
        booking.review_asked = True          # one job per visit, ever
        recurrence.record_review_ask(scope, customer, now)
        if job:
            queued += 1
    scope.flush()
    return queued


def sweep_recurrence(scope, now: datetime, limit: int = 50) -> int:
    """A7: one job per customer the application has already judged due."""
    cfg = load_tenant_config(scope.session, scope.tenant_id)
    if not cfg.recall_rules:
        return 0

    queued = 0
    for candidate in recurrence.due_for_recall(scope, cfg.recall_rules, now)[:limit]:
        customer = recurrence.get_or_create_customer(scope, candidate["customer_ref"])
        history = [
            {**v, "days_since": (now.date() - datetime.fromisoformat(v["date"]).date()).days}
            for v in recurrence.visit_history(scope, customer.customer_ref)
        ]
        job = queue.enqueue(
            scope, agent_id="A7",
            # Weekly cadence, so the key is per customer per service per week.
            dedupe_key=f"recall:{customer.customer_ref}:{candidate['service_id']}"
                       f":{now.date().isocalendar().week}",
            payload={
                "event": {"channel": "cron", "sender_ref": customer.customer_ref},
                "customer": {
                    "name": customer.name, "language": customer.language,
                    "visit_count": len(history),
                    "last_visit": history[0]["date"] if history else None,
                },
                "visit_history": history,
                "contact_history": {
                    "nudge_count": customer.nudge_count,
                    "last_nudge_at": customer.last_nudge_at.isoformat()
                    if customer.last_nudge_at else None,
                },
                "opt_out": customer.opt_out,
            },
        )
        if job:
            recurrence.record_nudge(scope, customer, now)
            queued += 1
    scope.flush()
    return queued


def sweep_digest(scope, now: datetime) -> int:
    """A8: one digest per tenant per ISO week."""
    payload = metrics.digest_inputs(scope.session, scope.tenant_id, now)
    job = queue.enqueue(
        scope, agent_id="A8",
        dedupe_key=f"digest:{now.date().isocalendar().year}"
                   f"-W{now.date().isocalendar().week}",
        payload={"event": {"channel": "cron", "sender_ref": "owner"}, **payload},
    )
    return 1 if job else 0


def run_all(session, now: datetime | None = None) -> dict[str, int]:
    """Called by the worker on a slow cadence. Never raises on one tenant."""
    from sqlalchemy import select

    from app.db import TenantScope

    now = now or datetime.now(tz=None).astimezone()
    totals = {"A6": 0, "A7": 0, "A8": 0}
    for tenant in session.execute(select(Tenant)).scalars().all():
        if tenant.kill_switch:
            continue
        scope = TenantScope(session, tenant.id)
        cfg = load_tenant_config(session, tenant.id)
        try:
            if "A6" in cfg.agents_enabled:
                totals["A6"] += sweep_review_requests(scope, now)
            if "A7" in cfg.agents_enabled:
                totals["A7"] += sweep_recurrence(scope, now)
            if "A8" in cfg.agents_enabled:
                totals["A8"] += sweep_digest(scope, now)
            session.commit()
        except Exception:  # noqa: BLE001 - one tenant must not stop the sweep
            session.rollback()
            log.exception("sweep failed for tenant %s", tenant.id)
    return totals
