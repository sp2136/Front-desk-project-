"""A deterministic stand-in for a model, so the system can be experienced
end to end with no API key.

This is NOT a model and must never be mistaken for one. It is a few dozen
keyword rules that produce schema-valid output for each agent, which is enough
to exercise the runtime, the guard, the chain and the console — and tells you
nothing whatsoever about whether a real model would classify a Gujarati booking
request correctly.

It exists because the alternative demo is an empty queue: with LLM_PROVIDER=null
every message stops at model_unavailable, which is correct behaviour and a
terrible way to see what the product does.

Two deliberate properties:

  It is bad in realistic ways. It misses a named-resource request, it answers
  from the FAQ only on an exact-ish term hit, and it does not notice several
  red lines. A stub that behaved perfectly would make the eval gates look like
  bureaucracy rather than the thing standing between you and an incident.

  It never invents a number. Every time, price and slot it emits is copied from
  the facts it was handed, because the guard will reject it otherwise — and
  watching the guard reject the one draft that does invent something (§8 of
  scripts/demo.py) is half the point of the demo.
"""
from __future__ import annotations

import json
import re
import time

from app.runtime.llm import LLMResult

URGENT_TERMS = (
    "pain", "hurt", "hurting", "bleeding", "blood", "swelling", "swollen",
    "broken", "chipped", "accident", "emergency", "urgent", "crying",
    "dukhe", "dukhave", "dard", "lohi", "khoon", "sujan", "soojan",
    "turat", "jaldi", "takleef",
)
INJECTION_TERMS = (
    "ignore your instruction", "ignore your rules", "ignore all rules",
    "system:", "system note", "print everything", "your system prompt",
    "you are now", "pre-approved",
)


def _block(user: str, tag: str):
    marker = f"<{tag}>\n"
    if marker not in user:
        return None
    raw = user.split(marker, 1)[1].split(f"\n</{tag}>", 1)[0]
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return raw.strip()


def _body(user: str) -> str:
    event = _block(user, "event") or {}
    return (event.get("body", "") if isinstance(event, dict) else "") or ""


def _detect_language(text: str) -> str:
    if re.search(r"[\u0A80-\u0AFF]", text):
        return "gu"
    if re.search(r"[\u0900-\u097F]", text):
        return "hi"
    low = text.lower()
    gu_latn = ("aavi", "sakay", "chho", "chhe", "kaal", "vagye", "vagya", "kayo",
               "faavse", "kem", "majama", "joie", "dukhe")
    hi_latn = ("kitna", "kaise", "chahiye", "karna", "bataiye", "milega", "hoga")
    if any(w in low for w in gu_latn):
        return "gu-Latn"
    if any(w in low for w in hi_latn):
        return "hi-Latn"
    return "en"


def _a1(user: str) -> dict:
    text = _body(user)
    low = text.lower()
    catalogue = _block(user, "service_catalogue") or []

    escalate, reason = False, None
    if any(t in low for t in INJECTION_TERMS):
        escalate, reason = True, "instruction_in_user_content"

    if any(w in low for w in ("complaint", "waited", "rude", "terrible", "poor service")):
        intent, escalate, reason = "complaint", True, "sentiment_risk"
    elif any(w in low for w in ("cancel",)):
        intent = "cancel"
    elif any(w in low for w in ("reschedule", "move my", "change my appointment")):
        intent = "reschedule"
    elif any(w in low for w in ("cost", "price", "charge", "how much", "fees", "fee")):
        intent = "price_enquiry"
    elif any(w in low for w in ("open", "hours", "timing", "address", "where are you",
                               "khoolu", "parking")):
        intent = "location_hours"
    elif any(w in low for w in ("book", "appointment", "aavi sakay", "slot", "come in",
                               "available", "time", "vagye")):
        intent = "book"
    elif any(w in low for w in URGENT_TERMS):
        intent = "service_enquiry"
    else:
        intent = "service_enquiry"

    service_id, service_guess = None, None
    for row in catalogue if isinstance(catalogue, list) else []:
        name = str(row.get("name", "")).lower()
        if name and (name.split()[0] in low or row.get("id", "").split("_")[-1] in low):
            service_id = row.get("id")
            break
    if service_id is None and any(w in low for w in ("clean", "scaling", "polish")):
        service_id = "svc_cleaning"
    if service_id is None:
        service_guess = text[:60] or None

    part = None
    if any(w in low for w in ("morning", "savare")):
        part = "morning"
    elif any(w in low for w in ("evening", "saanje", "6 vagya", "after 6")):
        part = "evening"
    elif "afternoon" in low:
        part = "afternoon"

    return {
        "intent": intent,
        "service_id": service_id,
        "service_guess": service_guess,
        "raw_complaint_text": text if intent == "complaint" else None,
        "language": _detect_language(text),
        "customer": {"known": False, "id": None, "name": None},
        "time_window": {"earliest": None, "latest": None, "preferred_days": [],
                        "part_of_day": part},
        "blockers": [],
        "confidence": 0.82 if service_id else 0.76,
        "escalate": escalate, "reason": reason, "evidence": [],
    }


def _a2(user: str) -> dict:
    text = _body(user)
    low = text.lower()
    a1 = _block(user, "a1_output") or {}
    business = _block(user, "business_type") or ""

    hits = [t for t in URGENT_TERMS if t in low]
    if hits:
        level, escalate, reason = "immediate", True, "policy_boundary"
    elif business in ("dentist", "clinic") and any(
        w in low for w in ("tooth", "teeth", "gum", "jaw", "mouth", "filling", "crown")
    ) and any(w in low for w in ("sore", "sensitive", "uncomfortable", "problem")):
        # Section 4 / A2: for a dentist, any negative bodily mention floors at same_day.
        level, escalate, reason = "same_day", False, None
    elif str(a1.get("intent")) == "complaint":
        level, escalate, reason = "same_day", False, None
    else:
        level, escalate, reason = "routine", False, None

    return {"level": level, "matched_signals": hits[:4],
            "confidence": 0.9, "escalate": escalate, "reason": reason, "evidence": []}


def _a3(user: str) -> dict:
    avail = _block(user, "availability") or []
    ceiling = _block(user, "max_slot_options")
    try:
        ceiling = int(ceiling) if ceiling else 3
    except (TypeError, ValueError):
        ceiling = 3
    picked, days = [], set()
    for a in avail if isinstance(avail, list) else []:
        day = str(a.get("starts_at", ""))[:10]
        if day in days:
            continue
        days.add(day)
        picked.append({k: a[k] for k in ("slot_id", "starts_at", "resource_id",
                                         "resource_name", "duration_minutes")})
        if len(picked) >= ceiling:
            break
    return {
        "options": picked,
        "unavailable_note": None if picked else "nothing open in that window",
        "confidence": 0.88 if picked else 0.6,
        "escalate": not picked,
        "reason": None if picked else "missing_fact",
        "evidence": [{"claim": "slots are open", "source": "get_availability#1"}]
        if picked else [],
    }


def _fmt(iso: str) -> str:
    """Render a slot time the way a front desk would, keeping the date."""
    try:
        from datetime import datetime
        dt = datetime.fromisoformat(iso)
        return dt.strftime("%a %-d %b, %-I:%M %p")
    except (ValueError, TypeError):
        return iso


def _a5(user: str) -> dict:
    booking = _block(user, "booking") or {}
    customer = _block(user, "customer") or {}
    stage = _block(user, "reminder_stage") or "T-24h"
    when = _fmt(str(booking.get("starts_at", "")))
    lang = customer.get("language", "en")

    if stage == "T-2h":
        draft = f"Reminder: your appointment is at {when}."
    elif stage == "no_show_recovery":
        draft = ("We missed you today. Happy to find another time that suits you "
                 "better. Would a morning or an evening work?")
    else:
        draft = (f"Confirming your appointment on {when} with "
                 f"{booking.get('resource_name', 'us')}. Reply R to move it, "
                 "otherwise we will see you then.")
    return {"draft": draft, "language": lang, "channel_preference": "whatsapp",
            "confidence": 0.87, "escalate": False, "reason": None, "evidence": []}


def _a4(user: str) -> dict:
    text = _body(user)
    low = text.lower()
    a1 = _block(user, "a1_output") or {}
    faq = _block(user, "faq_answers") or []
    options_block = _block(user, "a3_options") or []
    policy = _block(user, "policy_block") or {}

    options = (options_block.get("options", []) if isinstance(options_block, dict)
               else options_block)
    note = options_block.get("unavailable_note") if isinstance(options_block, dict) else None

    intent = str(a1.get("intent", "service_enquiry"))
    lang = str(a1.get("language", _detect_language(text)))
    missing: list[str] = []
    facts_used: list[dict] = []

    if any(t in low for t in INJECTION_TERMS):
        return {
            "draft": "Thanks for your message. Someone from the clinic will "
                     "get back to you shortly.",
            "language": lang, "intent_handled": intent, "facts_used": [],
            "missing": ["staff confirmation"], "auto_send_eligible": False,
            "confidence": 0.5, "escalate": True,
            "reason": "instruction_in_user_content", "evidence": [],
        }

    if options:
        lines = ", ".join(
            f"{_fmt(str(o['starts_at']))} with {o['resource_name']}" for o in options
        )
        summary = _block(user, "availability_summary") or {}
        extra = ""
        if isinstance(summary, dict) and summary.get("not_listed_total"):
            # The count verbatim. Never "plenty", never "most of the week".
            extra = (f" We have {summary['not_listed_total']} other times free in the "
                     f"next {summary.get('horizon_days', 7)} days if none of those suit.")
        draft = (f"Thanks for getting in touch. We have {lines} available.{extra} "
                 "Which of those works best for you?")
        facts_used = [{"claim": "slot availability", "source": "a3_options"}]
    elif note:
        draft = ("Thanks for getting in touch. We do not have anything open in "
                 "that window. Would you like me to look at the following week?")
        missing = ["a wider date range to search"]
    elif isinstance(faq, list) and faq:
        answer = str(faq[0].get("answer", ""))
        if "PLACEHOLDER" in answer:
            draft = ("Thanks for asking. Let me check that with the clinic and "
                     "come straight back to you.")
            missing = [f"an approved answer for: {text[:40]}"]
        else:
            draft = f"{answer} Anything else before you come in?"
            facts_used = [{"claim": "faq answer", "source": str(faq[0].get("id", "faq"))}]
    elif intent == "price_enquiry":
        # Section 4 / A4: quote a price ONLY if the catalogue carries it as
        # published. The seeded catalogue carries none, so this names the gap
        # rather than improvising around it.
        draft = ("Thanks for asking. Let me confirm the current charge with the "
                 "clinic and come back to you today.")
        missing = ["the current published price for this service"]
    elif intent == "location_hours" and policy.get("hours"):
        draft = f"We are open {policy['hours']}. Would you like me to find you a time?"
        facts_used = [{"claim": "opening hours", "source": "policy_block"}]
    else:
        draft = ("Thanks for getting in touch. Could you tell me which day suits "
                 "you, and I will check what is free?")

    escalate = bool(missing)
    return {
        "draft": draft, "language": lang, "intent_handled": intent,
        "facts_used": facts_used, "missing": missing,
        "auto_send_eligible": not escalate,
        "confidence": 0.84 if not escalate else 0.6,
        "escalate": escalate, "reason": "missing_fact" if escalate else None,
        "evidence": facts_used,
    }


def _a6(user: str) -> dict:
    """A crude sentiment gate. Deliberately conservative: anything it cannot
    read confidently becomes unknown, which escalates rather than asks."""
    history = json.dumps(_block(user, "history") or [], default=str).lower()
    notes = json.dumps(_block(user, "internal_notes") or "", default=str).lower()
    booking = _block(user, "booking") or {}
    link = _block(user, "review_link") or ""
    blob = history + " " + notes

    negative = ("complaint", "waited", "late", "sorry", "apolog", "redo", "rework",
                "dispute", "refund", "pain", "unhappy", "poor", "cancel")
    positive = ("thank", "great", "lovely", "perfect", "happy", "excellent")

    if any(w in blob for w in negative):
        return {"sentiment": "negative", "ask": False, "route_to_owner": True,
                "draft": None,
                "owner_note": "Thread contains a complaint or an apology. "
                              "Worth a call before any review ask.",
                "confidence": 0.8, "escalate": True, "reason": "sentiment_risk",
                "evidence": []}
    if not blob.strip() or blob.strip() in ("[]", '""'):
        return {"sentiment": "unknown", "ask": False, "route_to_owner": False,
                "draft": None, "owner_note": None,
                "confidence": 0.4, "escalate": True, "reason": "low_confidence",
                "evidence": []}
    if any(w in blob for w in positive):
        name = booking.get("customer_name") or "there"
        service = booking.get("service_id", "your visit")
        return {"sentiment": "positive", "ask": True, "route_to_owner": False,
                "draft": f"Thanks for coming in, {name}. If you have a moment, "
                         f"a short review of your {service} would mean a lot: {link}",
                "owner_note": None,
                "confidence": 0.85, "escalate": False, "reason": None, "evidence": []}
    return {"sentiment": "neutral", "ask": False, "route_to_owner": False,
            "draft": None, "owner_note": None,
            "confidence": 0.7, "escalate": False, "reason": None, "evidence": []}


def _a7(user: str) -> dict:
    customer = _block(user, "customer") or {}
    history = _block(user, "visit_history") or []
    rules = _block(user, "recall_rules") or {}
    opt_out = _block(user, "opt_out")

    if opt_out is True:
        return {"due": False, "service_id": None, "days_since": 0, "draft": None,
                "suppress_reason": "opt_out", "confidence": 0.99,
                "escalate": False, "reason": None, "evidence": []}

    target, days_since = None, 0
    for visit in history if isinstance(history, list) else []:
        sid = visit.get("service_id")
        if sid in rules:
            target = sid
            days_since = int(visit.get("days_since", 0) or 0)
            break
    if target is None:
        return {"due": False, "service_id": None, "days_since": 0, "draft": None,
                "suppress_reason": "no_rule", "confidence": 0.9,
                "escalate": False, "reason": None, "evidence": []}

    name = customer.get("name") or "there"
    return {
        "due": True, "service_id": target, "days_since": days_since,
        # No health consequence, no urgency language. The practice's routine,
        # stated and left there.
        "draft": f"Hello {name}, our records show it has been a while since your "
                 f"last visit. We usually see patients around this point. "
                 "Would you like me to find you a time?",
        "suppress_reason": None, "confidence": 0.82,
        "escalate": False, "reason": None, "evidence": [],
    }


def _a8(user: str) -> dict:
    cur = _block(user, "metrics_current") or {}
    exc = _block(user, "exceptions") or {}
    not_measured = ["revenue", "booking conversion rate from enquiry"]

    leaks = {k: v for k, v in exc.items() if v}
    headline_name = "escalations_not_cleared" if leaks.get("escalations_not_cleared") \
        else "enquiries"
    headline_value = exc.get("escalations_not_cleared") if leaks.get(
        "escalations_not_cleared") else cur.get("enquiries", 0)

    lines = [f"{headline_name.replace('_', ' ')}: {headline_value}."]
    moved = [f"{k.replace('_', ' ')} {cur[k]}" for k in
             ("enquiries", "drafts_produced", "bookings_made", "messages_sent")
             if cur.get(k) is not None]
    if moved:
        lines.append("What moved: " + ", ".join(moved) + ".")
    if leaks:
        lines.append("What leaked: " +
                     ", ".join(f"{k.replace('_', ' ')} {v}" for k, v in leaks.items()) + ".")
    lines.append("Revenue is not being measured yet.")

    actions = []
    if leaks.get("escalations_not_cleared"):
        actions.append({"action": "Clear the open items in the queue",
                        "because_of": "escalations_not_cleared"})
    if cur.get("enquiries"):
        actions.append({"action": "Review this week's enquiries for repeat questions "
                                  "worth adding to the FAQ",
                        "because_of": "enquiries"})
    return {"digest": " ".join(lines),
            "headline_metric": {"name": headline_name, "value": headline_value},
            "actions": actions[:2], "not_measured": not_measured,
            "confidence": 0.8, "escalate": False, "reason": None, "evidence": []}


def _guard(user: str) -> dict:
    draft = (user.split("<draft>\n", 1)[1].split("\n</draft>", 1)[0].lower()
             if "<draft>" in user else "")
    violations = []
    for term, rule in (
        ("reserved", "unauthorised_commitment"),
        ("held for you", "unauthorised_commitment"),
        ("guarantee", "unauthorised_commitment"),
        ("waive", "unauthorised_commitment"),
        ("discount", "unauthorised_commitment"),
        ("rinse", "professional_advice"),
        ("painkiller", "professional_advice"),
        ("infection", "professional_advice"),
        ("abscess", "professional_advice"),
        ("cost price", "internal_information"),
    ):
        if term in draft:
            violations.append({"rule": rule, "quote": term})
    return {"verdict": "reject" if violations else "pass",
            "violations": violations, "confidence": 0.8}


_ROUTES = (
    ("intake triage agent", _a1),
    ("triage safety gate", _a2),
    ("select appointment options", _a3),
    ("draft one reply on behalf of", _a4),
    ("compose one appointment reminder", _a5),
    ("ask this customer for a public review", _a6),
    ("decide whether they are", _a7),
    ("weekly operating summary", _a8),
    ("release gate", _guard),
)


class StubProvider:
    """Implements the LLMProvider interface with rules instead of a model."""

    name = "stub"

    def complete(self, system: str, user: str, *, max_tokens: int = 1024,
                 model: str | None = None, temperature: float = 0.0) -> LLMResult:
        started = time.perf_counter()
        payload: dict | None = None
        for marker, fn in _ROUTES:
            if marker in system:
                payload = fn(user)
                break
        if payload is None:
            raise RuntimeError(
                "StubProvider could not identify the agent from its system prompt. "
                "A new agent needs a route in app/runtime/stub_provider.py."
            )
        text = json.dumps(payload)
        return LLMResult(
            text=text, model="stub-rules-v1",
            input_tokens=max(1, (len(system) + len(user)) // 4),
            output_tokens=max(1, len(text) // 4),
            latency_ms=int((time.perf_counter() - started) * 1000),
            stop_reason="end_turn",
        )
