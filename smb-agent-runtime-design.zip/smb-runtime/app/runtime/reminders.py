"""Deterministic reminder scheduling. Section 4 / A5.

"The schedule is deterministic and lives in the app: T-24h and T-2h by
default. The agent only chooses channel and phrasing."

Everything the agent must not be trusted with lives here: when a reminder is
due, whether it has already been sent, and whether the booking is still live.
A5 receives a stage and a booking and writes prose. It cannot send early, send
twice, or send to someone who cancelled, because it never decides any of those.

The word ceilings below are from A5's own rules. They are recorded on the run
and asserted in eval rather than enforced as a hard gate: a 25-word T-2h line
is a quality problem the owner notices, not a safety problem, and blocking a
send over word count would be the gate crying wolf.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from sqlalchemy import select

from app.models import Booking, Reminder
from app.schemas.agents import ReminderStage

# Offsets before the appointment, as the spec's defaults.
SCHEDULE: dict[str, timedelta] = {
    ReminderStage.T_24H: timedelta(hours=24),
    ReminderStage.T_2H: timedelta(hours=2),
}

WORD_CEILING: dict[str, int] = {
    ReminderStage.T_24H: 50,
    ReminderStage.T_2H: 20,
    ReminderStage.NO_SHOW_RECOVERY: 40,
}


@dataclass(frozen=True)
class DueReminder:
    booking_id: int
    stage: str
    due_at: datetime


def schedule_for_booking(scope, booking: Booking,
                         now: datetime | None = None) -> list[Reminder]:
    """Create the reminder rows for a new booking, skipping any already past.

    A booking made three hours before the appointment gets no T-24h reminder.
    Creating one and then suppressing it at send time would leave a row that
    looks like a failure in every report that counts them.

    `now` is injectable because a scheduler whose clock cannot be set is a
    scheduler whose edge cases cannot be tested, and the edge cases are the
    entire behaviour here.
    """
    now = now or datetime.now(UTC)
    created: list[Reminder] = []
    for stage, offset in SCHEDULE.items():
        due = booking.starts_at - offset
        if due.tzinfo is None:
            due = due.replace(tzinfo=UTC)
        if due <= now:
            continue
        existing = scope.one_or_none(
            Reminder, Reminder.booking_id == booking.id, Reminder.stage == stage
        )
        if existing:
            continue
        created.append(
            scope.add(Reminder(booking_id=booking.id, stage=stage, due_at=due,
                               state="scheduled"))
        )
    scope.flush()
    return created


def due_reminders(scope, now: datetime | None = None, limit: int = 50) -> list[DueReminder]:
    """Reminders whose time has come, for bookings that are still live."""
    now = now or datetime.now(UTC)
    rows = scope.session.execute(
        select(Reminder, Booking)
        .join(Booking, Booking.id == Reminder.booking_id)
        .where(
            Reminder.tenant_id == scope.tenant_id,
            Reminder.state == "scheduled",
            Reminder.due_at <= now,
            Booking.state == "confirmed",
        )
        .order_by(Reminder.due_at)
        .limit(limit)
    ).all()
    return [DueReminder(r.booking_id, r.stage, r.due_at) for r, _ in rows]


def mark_queued(scope, booking_id: int, stage: str) -> None:
    row = scope.one_or_none(
        Reminder, Reminder.booking_id == booking_id, Reminder.stage == stage
    )
    if row is not None:
        row.state = "queued"
        scope.flush()


def cancel_for_booking(scope, booking_id: int) -> int:
    """Drop outstanding reminders when a booking is cancelled or rescheduled."""
    rows = scope.all(
        Reminder, Reminder.booking_id == booking_id, Reminder.state == "scheduled"
    )
    for r in rows:
        r.state = "cancelled"
    scope.flush()
    return len(rows)


def word_count(text: str) -> int:
    return len(text.split())


def over_ceiling(stage: str, draft: str) -> bool:
    ceiling = WORD_CEILING.get(stage)
    return ceiling is not None and word_count(draft) > ceiling
