"""The REVIEW column of section 1.1: rule passes OR human approves OR queued.

Nothing reaches a customer except through a Decision row, and the executor
refuses to act on one that is not approved. That is the "exactly one write path"
of Law 1, made concrete.
"""
from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum

from app.models import Decision, OutboundMessage
from app.runtime import audit, autosend
from app.schemas.agents import GuardOutput, GuardVerdict
from app.schemas.envelope import Envelope
from app.schemas.tenant import TenantConfig


class DecisionKind(StrEnum):
    AUTO_SEND = "auto_send"
    QUEUED_FOR_HUMAN = "queued_for_human"
    BLOCKED = "blocked"
    ESCALATED = "escalated"
    NO_ACTION = "no_action"


def decide(scope, cfg: TenantConfig, *, run_id: int | None, envelope: Envelope,
           draft: str | None, intent: str | None, guard: GuardOutput | None,
           customer_facing: bool, a2_level: str | None = None,
           a2_required: bool = True, offered_options: list[dict] | None = None,
           offered_service_id: str | None = None) -> Decision:
    """Classify one agent output into a Decision. Writes nothing outbound."""

    kind = DecisionKind.QUEUED_FOR_HUMAN
    if envelope.escalate:
        kind = DecisionKind.ESCALATED
    elif guard is not None and guard.verdict is GuardVerdict.REJECT:
        kind = DecisionKind.BLOCKED
    elif draft is None:
        kind = DecisionKind.NO_ACTION
    elif customer_facing and intent and cfg.auto_send_allowed(intent):
        kind = DecisionKind.AUTO_SEND

    # Belt and braces on the whitelist: section 4's A4 table says anything where
    # A2 is not routine is never auto-sent, and complaint is never auto-sent at
    # all. Both are already encoded in the agent contracts, but the gate that
    # actually touches the customer re-checks rather than trusting upstream.
    if kind is DecisionKind.AUTO_SEND and intent == "complaint":
        kind = DecisionKind.ESCALATED

    # Section 2.4: the guard sits between ANY agent draft and ANY customer-facing
    # send. A tenant can configure guard_pass_required_for down to nothing, and
    # that is allowed -- but it buys human review, not unreviewed sending. With
    # no guard verdict on record, auto-send falls back to the staff queue rather
    # than proceeding ungated.
    if kind is DecisionKind.AUTO_SEND and guard is None:
        kind = DecisionKind.QUEUED_FOR_HUMAN

    # Section 4 / A4, final row of the whitelist table: "Anything where
    # A2 != routine | Never". An absent level counts as not routine -- a draft
    # whose safety gate never ran has not been cleared by it.
    if kind is DecisionKind.AUTO_SEND and autosend.blocked_by_urgency(
        a2_level, a2_required
    ):
        kind = DecisionKind.QUEUED_FOR_HUMAN

    # The agent's own auto_send_eligible is advisory, never decisive. It is a
    # useful signal about whether A4 thinks it had everything it needed, and
    # it is recorded; but the gates that matter are the tenant whitelist, the
    # guard verdict and A2's level, none of which the agent can see.
    agent_says_eligible = getattr(envelope, "auto_send_eligible", True)
    if kind is DecisionKind.AUTO_SEND and agent_says_eligible is False:
        kind = DecisionKind.QUEUED_FOR_HUMAN

    row = scope.add(
        Decision(
            run_id=run_id,
            kind=kind,
            intent=intent,
            draft=draft,
            guard_verdict=guard.verdict if guard else None,
            guard_violations=guard.model_dump(mode="json") if guard else None,
            escalation_reason=envelope.reason.value if envelope.reason else None,
            a2_level=a2_level,
            offered_options=offered_options or None,
            offered_service_id=offered_service_id,
            # A no_action decision is closed on creation. An internal agent like
            # A1 produces no customer-facing text, so there is nothing for a
            # human to approve -- and leaving these open would bury the items
            # that do need a person under one row per inbound message.
            outcome="closed" if kind is DecisionKind.NO_ACTION else "open",
        )
    )
    scope.flush()

    audit.record(
        scope,
        actor="runtime",
        action="decision_created",
        subject_type="decision",
        subject_id=row.id,
        data={
            "kind": kind.value,
            "intent": intent,
            "confidence": envelope.confidence,
            "escalate": envelope.escalate,
            "reason": envelope.reason.value if envelope.reason else None,
            "guard_verdict": guard.verdict.value if guard else None,
        },
    )
    return row


def _edit_distance_pct(draft: str, sent: str) -> float:
    """Section 1.4: "Edit distance between draft and sent. The real measure of
    whether a copilot helps." Levenshtein over characters, as a percentage of
    the draft length.
    """
    if not draft:
        return 100.0 if sent else 0.0
    prev = list(range(len(sent) + 1))
    for i, a in enumerate(draft, 1):
        cur = [i]
        for j, b in enumerate(sent, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a != b)))
        prev = cur
    return round(100.0 * prev[-1] / len(draft), 2)


def approve(
    scope, decision_id: int, *, approver: str, sent_text: str | None = None
) -> Decision:
    """Human approval. The only route by which a queued draft becomes sendable."""
    row = scope.one_or_none(Decision, Decision.id == decision_id)
    if row is None:
        raise KeyError(f"decision {decision_id} not found for tenant {scope.tenant_id}")
    if row.outcome != "open":
        raise ValueError(f"decision {decision_id} is already {row.outcome}")

    final = sent_text if sent_text is not None else (row.draft or "")
    row.approver = approver
    row.approved_at = datetime.now(UTC)
    row.sent_text = final
    row.edit_distance_pct = _edit_distance_pct(row.draft or "", final)
    row.outcome = "approved"
    scope.flush()

    audit.record(
        scope, actor=approver, action="decision_approved", subject_type="decision",
        subject_id=row.id,
        data={"edit_distance_pct": row.edit_distance_pct, "kind": row.kind},
    )
    return row


def reject(scope, decision_id: int, *, approver: str, note: str = "") -> Decision:
    row = scope.one_or_none(Decision, Decision.id == decision_id)
    if row is None:
        raise KeyError(f"decision {decision_id} not found")
    row.approver = approver
    row.approved_at = datetime.now(UTC)
    row.outcome = "rejected"
    scope.flush()
    audit.record(
        scope, actor=approver, action="decision_rejected", subject_type="decision",
        subject_id=row.id, data={"note": note},
    )
    return row


def enqueue_outbound(scope, cap_guard, decision: Decision, *, channel: str,
                     to_ref: str) -> OutboundMessage:
    """THE write path. Section 1.2: "There is exactly one write path and it is
    application code." This function is it for messaging.

    Refuses anything not auto_send-with-open-outcome or human-approved.
    """
    if decision.kind == DecisionKind.AUTO_SEND and decision.outcome == "open":
        body = decision.draft or ""
        decision.outcome = "approved"
        decision.approver = "auto_send_whitelist"
        decision.approved_at = datetime.now(UTC)
        decision.sent_text = body
        decision.edit_distance_pct = 0.0
    elif decision.outcome == "approved":
        body = decision.sent_text or decision.draft or ""
    else:
        raise ValueError(
            f"refusing to send decision {decision.id}: kind={decision.kind} "
            f"outcome={decision.outcome}"
        )

    if not body.strip():
        raise ValueError(f"refusing to send empty body for decision {decision.id}")

    msg = scope.add(
        OutboundMessage(decision_id=decision.id, channel=channel, to_ref=to_ref, body=body)
    )
    scope.flush()

    # If this message put slot options in front of the customer, record them so
    # their reply can be matched back to a real slot without a person reading
    # the thread. Recorded on SEND, not on draft: options the customer never
    # saw are not options they can accept.
    if decision.offered_options:
        from app.runtime import confirm

        confirm.record_offer(
            scope, customer_ref=to_ref, options=decision.offered_options,
            decision_id=decision.id, service_id=decision.offered_service_id,
        )
    cap_guard.record_message_sent(1)
    audit.record(
        scope, actor="executor", action="outbound_queued", subject_type="outbound_message",
        subject_id=msg.id,
        data={"decision_id": decision.id, "channel": channel, "chars": len(body)},
    )
    return msg
