"""Queue consumer.

Claims a lease, builds a TenantScope, runs the pipeline, routes the chain,
releases the lease. Deliberately single-threaded and boring: concurrency lives
in running more of these, not in making one clever.
"""
from __future__ import annotations

import logging
import os
import signal
import time
from datetime import datetime

from sqlalchemy import select

from app.db import SessionLocal, TenantScope, init_db
from app.runtime import (  # noqa: F401
    agents,
    alerts,
    chain,
    queue,
    reminders,
    review,
    sweeps,
    tool_impls,
)
from app.runtime.caps import CapGuard
from app.runtime.errors import CapExceeded, KillSwitchEngaged
from app.runtime.llm import get_provider
from app.runtime.pipeline import Pipeline
from app.runtime.validate import load_tenant_config
from app.schemas.agents import A2Output

log = logging.getLogger("worker")
_running = True


def _stop(*_a):  # pragma: no cover - signal glue
    global _running
    _running = False
    log.info("drain requested; finishing current job")


def _route_chain(scope, session, job, result) -> None:
    """Apply the section 4 chain rules to a completed agent run."""
    upstream_intent = (
        getattr(result.envelope, "intent", None)
        or (job.payload.get("upstream_a1") or {}).get("intent")
    )
    outcome = chain.next_steps(
        job.agent_id, result.envelope,
        upstream_intent=str(upstream_intent) if upstream_intent else None,
    )

    if outcome.alert and isinstance(result.envelope, A2Output):
        cfg = load_tenant_config(session, scope.tenant_id)
        alerts.raise_urgency_alert(
            scope, cfg,
            run_id=result.runs[-1] if result.runs else None,
            a2=result.envelope,
            event=job.payload.get("event", {}),
        )

    if outcome.preempt:
        log.info("job %s: chain pre-empted (%s)", job.id, outcome.alert)
        session.commit()
        return

    # A3 -> A4: attach the count of open times A3 did NOT offer, so A4 can
    # offer more without inventing how much more there is.
    if job.agent_id == "A3" and outcome.steps:
        cfg = load_tenant_config(session, scope.tenant_id)
        if cfg.availability_summary:
            from app.runtime.booking import availability_summary

            offered = {o.get("slot_id") for o in
                       (result.envelope.model_dump(mode="json").get("options") or [])}
            summary = availability_summary(
                scope,
                service_id=(job.payload.get("upstream_a1") or {}).get("service_id")
                or cfg.default_service_id,
                exclude_slot_ids=offered,
            )
            outcome = chain.ChainOutcome(
                steps=tuple(
                    chain.ChainStep(st.agent_id,
                                    {**st.payload_extra, "availability_summary": summary})
                    for st in outcome.steps
                ),
                preempt=outcome.preempt, alert=outcome.alert,
            )

    for step in outcome.steps:
        if step.agent_id not in agents.REGISTRY:
            # The route exists in the spec but the agent is not built yet.
            # Logged rather than swallowed, so a missing link is visible.
            log.info("job %s: next step %s is not built yet", job.id, step.agent_id)
            continue
        queue.enqueue(
            scope,
            agent_id=step.agent_id,
            dedupe_key=f"{job.idempotency_key}->{step.agent_id}",
            event_id=job.event_id,
            payload={**job.payload, **step.payload_extra},
        )
    session.commit()


def tick_reminders(worker_id: str = "scheduler", now: datetime | None = None) -> int:
    """Enqueue A5 jobs for every reminder whose time has come.

    Separate from run_once because it is time-driven rather than event-driven.
    Runs on the same loop for operational simplicity; split it into its own
    process when one worker can no longer keep up with both.

    `now` is injectable for the same reason schedule_for_booking's is: a
    scheduler whose clock cannot be set is a scheduler whose edge cases cannot
    be tested, and the edge cases are the entire behaviour.
    """
    from zoneinfo import ZoneInfo

    from app.models import Booking, Tenant

    session = SessionLocal()
    queued = 0
    try:
        for tenant in session.execute(select(Tenant)).scalars().all():
            if tenant.kill_switch:
                continue
            scope = TenantScope(session, tenant.id)
            # Customer-facing text must carry the clinic's own time. The stored
            # value is UTC, and handing it to A5 unconverted is how a Surat
            # patient is told to arrive at 4:30 in the morning. Same bug as
            # get_availability had; worth checking every path that renders a
            # stored timestamp into something a person reads.
            zone = ZoneInfo((tenant.config or {}).get("timezone", "Asia/Kolkata"))
            for due in reminders.due_reminders(scope, now=now):
                booking = scope.one_or_none(Booking, Booking.id == due.booking_id)
                if booking is None:
                    continue
                job = queue.enqueue(
                    scope, agent_id="A5",
                    # One job per (booking, stage), forever. The scheduler sees
                    # the same due row on every tick until it is marked queued,
                    # and the idempotency key is what stops twelve reminders.
                    dedupe_key=f"reminder:{due.booking_id}:{due.stage}",
                    payload={
                        "reminder_stage": due.stage,
                        "booking": {
                            "booking_id": booking.id,
                            "service_id": booking.service_id,
                            "starts_at": booking.starts_at.astimezone(zone).isoformat(),
                            "duration_minutes": booking.duration_min,
                            "resource_id": booking.resource_id,
                        },
                        "customer": {
                            "name": booking.customer_name,
                            "language": booking.language,
                            "visit_count": booking.visit_count,
                        },
                        "event": {"channel": "cron", "sender_ref": booking.customer_ref},
                    },
                )
                reminders.mark_queued(scope, due.booking_id, due.stage)
                if job:
                    queued += 1
            session.commit()
    except Exception:  # noqa: BLE001 - a scheduler must not die on one tenant
        session.rollback()
        log.exception("reminder tick failed")
    finally:
        session.close()
    if queued:
        log.info("queued %s reminder(s)", queued)
    return queued


def _deliver_if_auto_send(scope, session, job, result) -> None:
    """Send a draft the review gate cleared for auto-send.

    Without this the whitelist decided nothing: a decision was marked
    auto_send and then sat in the queue next to the ones genuinely waiting on
    a person, which is the opposite of what whitelisting it meant.
    """
    decision = result.decision
    if decision is None or decision.kind != review.DecisionKind.AUTO_SEND:
        return
    if decision.outcome != "open" or not (decision.draft or "").strip():
        return

    event = job.payload.get("event", {}) or {}
    to_ref = event.get("sender_ref")
    if not to_ref:
        return
    cfg = load_tenant_config(session, scope.tenant_id)
    try:
        review.enqueue_outbound(
            scope, CapGuard(scope, cfg), decision,
            channel=event.get("channel", cfg.staff_alert_channel), to_ref=to_ref,
        )
        session.commit()
        log.info("job %s: auto-sent decision %s", job.id, decision.id)
    except (ValueError, CapExceeded, KillSwitchEngaged) as exc:
        # A refused send is not a worker fault. The decision stays open and a
        # person sees it, which is the correct fallback for every one of these.
        session.rollback()
        decision.kind = review.DecisionKind.QUEUED_FOR_HUMAN
        session.commit()
        log.info("job %s: auto-send refused (%s); queued for a person", job.id, exc)


def run_once(worker_id: str, pipeline: Pipeline) -> int:
    """Process at most one job. Returns the number of jobs handled."""
    session = SessionLocal()
    try:
        jobs = queue.claim(session, worker_id, limit=1)
        if not jobs:
            return 0
        job = jobs[0]
        scope = TenantScope(session, job.tenant_id)
        try:
            result = pipeline.run(scope, job)
            session.commit()
            queue.complete(session, job.id, "done" if result.ok else "stopped", result.detail)
            if result.ok:
                _deliver_if_auto_send(scope, session, job, result)
                _route_chain(scope, session, job, result)
        except Exception as exc:  # noqa: BLE001 - worker must not die on one job
            session.rollback()
            log.exception("job %s failed", job.id)
            queue.fail(session, job, f"{type(exc).__name__}: {exc}")
        return 1
    finally:
        session.close()


def main() -> None:  # pragma: no cover - entrypoint
    logging.basicConfig(level=logging.INFO)
    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    init_db()
    from app.runtime.prompts import sync_to_db

    with SessionLocal() as s:
        written = sync_to_db(s)
        s.commit()
        if written:
            log.info("synced prompt bodies: %s", ", ".join(written))

    worker_id = os.getenv("WORKER_ID", f"worker-{os.getpid()}")
    pipeline = Pipeline(get_provider())
    log.info("worker %s up", worker_id)
    idle = 0
    last_tick = 0.0
    last_sweep = 0.0
    while _running:
        # Reminder scheduling is cheap and time-driven; a minute of latency on
        # a T-24h reminder is invisible, so it does not need its own loop.
        if time.monotonic() - last_tick > 60:
            tick_reminders(worker_id)
            # A6, A7 and A8 are slow sweeps: a weekly digest does not care
            # about a few minutes, and a recall nudge certainly does not.
            if time.monotonic() - last_sweep > 900:
                with SessionLocal() as s:
                    sweeps.run_all(s)
                last_sweep = time.monotonic()
            last_tick = time.monotonic()
        handled = run_once(worker_id, pipeline)
        idle = 0 if handled else min(idle + 1, 10)
        time.sleep(0.2 * idle if idle else 0)
    log.info("worker %s drained", worker_id)


if __name__ == "__main__":  # pragma: no cover
    main()
