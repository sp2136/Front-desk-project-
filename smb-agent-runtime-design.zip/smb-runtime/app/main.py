from __future__ import annotations

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api import admin, console, webhooks
from app.config import settings
from app.db import SessionLocal, init_db
from app.runtime import tool_impls  # noqa: F401  -- registers the tool contracts
from app.runtime.prompts import sync_to_db


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    with SessionLocal() as session:
        sync_to_db(session)
        session.commit()
    yield


app = FastAPI(
    title="SMB Digital Infrastructure -- Agent Runtime",
    version="0.1.0-stage0",
    description=(
        "Stage 0 of the build sequence in section 12: event queue, tenant context, "
        "tool scoping, schema validation, audit log, token and message caps, kill "
        "switch. No model is attached at this stage."
    ),
    lifespan=lifespan,
)
app.include_router(webhooks.router)
app.include_router(console.router)
app.include_router(admin.router)

# The sandbox UI has no authentication and exposes a reset button. Gating it on
# an env flag rather than on a deployment checklist is the difference between a
# demo on a laptop and an open console on the internet.
if os.getenv("SANDBOX", "").lower() in ("1", "true", "yes"):
    from app.api import dashboards, sandbox

    app.include_router(sandbox.router)
    # The dashboards are read-only, but /ops shows every tenant at once and
    # neither page authenticates. Behind the same flag until there is a real
    # login; an operator console is not something to leave open by default.
    app.include_router(dashboards.router)


@app.get("/healthz")
def healthz() -> dict:
    return {
        "status": "ok",
        "stage": 0,
        "llm_provider": settings.llm_provider,
        "global_kill_switch": settings.global_kill_switch,
    }
