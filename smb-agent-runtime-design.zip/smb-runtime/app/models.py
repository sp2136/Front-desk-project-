"""Tables. Every tenant-owned row carries tenant_id as a real column so the
isolation guard in db.py and the Postgres RLS policies in sql/ can both key on it.
"""
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.types import TypeDecorator


def utcnow() -> datetime:
    return datetime.now(UTC)


class UTCDateTime(TypeDecorator):
    """A timestamp that is always timezone-aware UTC in Python.

    SQLite has no timestamp type and silently drops tzinfo, so a value written
    as aware comes back naive. Every comparison between a stored timestamp and
    datetime.now(UTC) then raises TypeError -- and the ones that do not raise
    are worse, because a naive value treated as local time is a reminder fired
    at the wrong hour or a lock that looks expired when it is not.

    Normalising on the way in and out makes the application tz-aware whatever
    the backend, so dev on SQLite behaves like prod on Postgres. Fixing this
    per call site was the earlier approach and it leaked: the audit log needed
    its own workaround.
    """

    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            value = value.replace(tzinfo=UTC)
        return value.astimezone(UTC)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=UTC)
        return value.astimezone(UTC)


class Base(DeclarativeBase):
    pass


class TenantScoped:
    """Marker mixin. db.TenantScope refuses to query any model lacking it."""


class Tenant(Base):
    __tablename__ = "tenants"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(255))
    business_type: Mapped[str] = mapped_column(String(64))
    archetype: Mapped[str] = mapped_column(String(1))
    config: Mapped[dict] = mapped_column(JSON)
    kill_switch: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class InboundEventRow(Base, TenantScoped):
    __tablename__ = "inbound_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), ForeignKey("tenants.id"), index=True)
    channel: Mapped[str] = mapped_column(String(32))
    external_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    dedupe_key: Mapped[str] = mapped_column(String(320))
    sender_ref: Mapped[str] = mapped_column(String(255), index=True)
    body: Mapped[str] = mapped_column(Text, default="")
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    received_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    __table_args__ = (
        # Dedupe is a database constraint, not a prompt instruction and not an
        # application if-statement. Section 1.3: concurrent work must collide here.
        UniqueConstraint("tenant_id", "dedupe_key", name="uq_event_dedupe"),
        Index("ix_events_sender_time", "tenant_id", "sender_ref", "received_at"),
    )


class Job(Base, TenantScoped):
    """Queue row. Leased, not deleted, so a crashed worker cannot lose the event."""

    __tablename__ = "jobs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    event_id: Mapped[int | None] = mapped_column(
        ForeignKey("inbound_events.id"), nullable=True
    )
    agent_id: Mapped[str] = mapped_column(String(16))
    idempotency_key: Mapped[str] = mapped_column(String(320))
    state: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    available_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    locked_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    locked_until: Mapped[datetime | None] = mapped_column(
        UTCDateTime, nullable=True
    )
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    __table_args__ = (
        UniqueConstraint("idempotency_key", name="uq_job_idempotency"),
        Index("ix_jobs_claimable", "state", "available_at"),
    )


class AgentRun(Base, TenantScoped):
    """One model call. Section 1.4 requires prompt version and tool version on
    every call, or 'it got worse' is unanswerable."""

    __tablename__ = "agent_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    job_id: Mapped[int | None] = mapped_column(ForeignKey("jobs.id"), nullable=True)
    agent_id: Mapped[str] = mapped_column(String(16), index=True)
    attempt: Mapped[int] = mapped_column(Integer, default=1)
    prompt_id: Mapped[str] = mapped_column(String(64))
    prompt_version: Mapped[str] = mapped_column(String(32))
    prompt_sha256: Mapped[str] = mapped_column(String(64))
    toolbelt_version: Mapped[str] = mapped_column(String(64), default="")
    model: Mapped[str] = mapped_column(String(64), default="")
    input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, default=0)
    latency_ms: Mapped[int] = mapped_column(Integer, default=0)
    raw_output: Mapped[str | None] = mapped_column(Text, nullable=True)
    parsed_output: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    valid: Mapped[bool] = mapped_column(Boolean, default=False)
    validation_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class ToolCall(Base, TenantScoped):
    __tablename__ = "tool_calls"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    run_id: Mapped[int | None] = mapped_column(ForeignKey("agent_runs.id"), nullable=True)
    tool_name: Mapped[str] = mapped_column(String(64))
    tool_version: Mapped[str] = mapped_column(String(32))
    args: Mapped[dict] = mapped_column(JSON, default=dict)
    result_ref: Mapped[str] = mapped_column(String(64), default="")
    row_count: Mapped[int] = mapped_column(Integer, default=0)
    latency_ms: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class Decision(Base, TenantScoped):
    """The REVIEW column of section 1.1. Nothing reaches a customer without one."""

    __tablename__ = "decisions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    run_id: Mapped[int | None] = mapped_column(ForeignKey("agent_runs.id"), nullable=True)
    kind: Mapped[str] = mapped_column(String(32), index=True)
    intent: Mapped[str | None] = mapped_column(String(48), nullable=True)
    draft: Mapped[str | None] = mapped_column(Text, nullable=True)
    guard_verdict: Mapped[str | None] = mapped_column(String(16), nullable=True)
    guard_violations: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    escalation_reason: Mapped[str | None] = mapped_column(String(48), nullable=True)
    a2_level: Mapped[str | None] = mapped_column(String(16), nullable=True)
    # The slot options this draft actually offered, so a reply can be matched
    # back to a real slot id. Null for every draft that offered none.
    offered_options: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    offered_service_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    runtime_stop: Mapped[str | None] = mapped_column(String(48), nullable=True)
    approver: Mapped[str | None] = mapped_column(String(128), nullable=True)
    approved_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    sent_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    edit_distance_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    outcome: Mapped[str] = mapped_column(String(32), default="open", index=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class OutboundMessage(Base, TenantScoped):
    """Written only by the executor, only from an approved Decision."""

    __tablename__ = "outbound_messages"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    decision_id: Mapped[int] = mapped_column(ForeignKey("decisions.id"))
    channel: Mapped[str] = mapped_column(String(32))
    to_ref: Mapped[str] = mapped_column(String(255))
    body: Mapped[str] = mapped_column(Text)
    state: Mapped[str] = mapped_column(String(24), default="queued")
    provider_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    sent_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class UsageCounter(Base, TenantScoped):
    """Section 1.4 and 10: token cost and message volume per tenant per day,
    with a cap that disables the agent rather than silently billing you."""

    __tablename__ = "usage_counters"
    tenant_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    day: Mapped[str] = mapped_column(String(10), primary_key=True)  # YYYY-MM-DD, tenant tz
    input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, default=0)
    cost_micros: Mapped[int] = mapped_column(Integer, default=0)
    messages_sent: Mapped[int] = mapped_column(Integer, default=0)
    disabled_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    disabled_reason: Mapped[str | None] = mapped_column(String(48), nullable=True)


class AuditLog(Base, TenantScoped):
    """Append-only, hash-chained. Section 1.3 requires the chain of prompt
    version, tool calls, tokens, latency, approver and outcome; the hash makes a
    silent edit detectable, which matters the first time a client disputes what
    was sent in their name."""

    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)
    actor: Mapped[str] = mapped_column(String(128))
    action: Mapped[str] = mapped_column(String(64), index=True)
    subject_type: Mapped[str] = mapped_column(String(48))
    subject_id: Mapped[str] = mapped_column(String(64))
    data: Mapped[dict] = mapped_column(JSON, default=dict)
    prev_hash: Mapped[str] = mapped_column(String(64), default="")
    hash: Mapped[str] = mapped_column(String(64))


class PromptRow(Base):
    """Prompt store. Not tenant-scoped: no prompt is ever edited per client
    (section 0, placeholder convention). Only injected values differ."""

    __tablename__ = "prompts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    prompt_id: Mapped[str] = mapped_column(String(64), index=True)
    version: Mapped[str] = mapped_column(String(32))
    sha256: Mapped[str] = mapped_column(String(64))
    body: Mapped[str] = mapped_column(Text)
    active: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    __table_args__ = (UniqueConstraint("prompt_id", "version", name="uq_prompt_version"),)


class Resource(Base, TenantScoped):
    """A practitioner, stylist, chair or bay. Section 3's resource_slot model."""

    __tablename__ = "resources"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    name: Mapped[str] = mapped_column(String(255))
    skills: Mapped[dict] = mapped_column(JSON, default=list)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Slot(Base, TenantScoped):
    """One bookable unit of a resource's time.

    THE LOCK LIVES ON THIS ROW, NOT IN A SEPARATE TABLE.

    Section 1.3: "Two concurrent bookings must collide at the database, not in
    a prompt." A separate locks table needs a partial unique index to express
    "at most one live lock per slot", which SQLite and Postgres spell
    differently and which is easy to get subtly wrong. Putting lock_token and
    lock_expires_at on the slot itself turns acquisition into a single
    conditional UPDATE whose affected-row count is the answer: 1 means you won,
    0 means somebody else did. That is portable, atomic, and impossible to
    misread.
    """

    __tablename__ = "slots"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    resource_id: Mapped[str] = mapped_column(String(64), index=True)
    # NULL means "open for any service this resource is skilled in".
    #
    # A dentist has one calendar, not one per service. Binding every slot to a
    # single service would mean the 11:00 slot exists several times over -- once
    # per service -- which the uniqueness constraint below correctly refuses,
    # and which would also let the same eleven o'clock be sold twice under two
    # different service ids. A non-null service_id is still allowed, for a
    # resource whose time really is pre-committed (a theatre list, a bay booked
    # for one job type).
    service_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    starts_at: Mapped[datetime] = mapped_column(UTCDateTime, index=True)
    duration_min: Mapped[int] = mapped_column(Integer)
    booking_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    lock_token: Mapped[str | None] = mapped_column(String(64), nullable=True)
    lock_expires_at: Mapped[datetime | None] = mapped_column(
        UTCDateTime, nullable=True
    )
    __table_args__ = (
        UniqueConstraint("tenant_id", "resource_id", "starts_at", name="uq_slot_resource_time"),
        Index("ix_slots_lookup", "tenant_id", "service_id", "starts_at"),
    )


class Booking(Base, TenantScoped):
    __tablename__ = "bookings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    slot_id: Mapped[str] = mapped_column(String(64))
    service_id: Mapped[str] = mapped_column(String(64))
    resource_id: Mapped[str] = mapped_column(String(64))
    starts_at: Mapped[datetime] = mapped_column(UTCDateTime, index=True)
    duration_min: Mapped[int] = mapped_column(Integer)
    customer_ref: Mapped[str] = mapped_column(String(255), index=True)
    customer_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    language: Mapped[str] = mapped_column(String(16), default="en")
    visit_count: Mapped[int] = mapped_column(Integer, default=1)
    # confirmed | completed | cancelled | no_show. A6 triggers on completed;
    # A8 counts no_show as a leak.
    state: Mapped[str] = mapped_column(String(24), default="confirmed", index=True)
    internal_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    review_asked: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    __table_args__ = (UniqueConstraint("tenant_id", "slot_id", name="uq_booking_slot"),)


class Reminder(Base, TenantScoped):
    """One reminder stage for one booking.

    Section 4 / A5: "The schedule is deterministic and lives in the app: T-24h
    and T-2h by default. The agent only chooses channel and phrasing."

    The unique constraint is the whole idempotency story. A scheduler that runs
    every five minutes will find the same due booking many times over, and a
    customer who gets the same reminder twelve times is a customer who blocks
    the number.
    """

    __tablename__ = "reminders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    booking_id: Mapped[int] = mapped_column(Integer, index=True)
    stage: Mapped[str] = mapped_column(String(24))
    due_at: Mapped[datetime] = mapped_column(UTCDateTime, index=True)
    decision_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    state: Mapped[str] = mapped_column(String(24), default="scheduled", index=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    __table_args__ = (
        UniqueConstraint("tenant_id", "booking_id", "stage", name="uq_reminder_stage"),
    )


class Customer(Base, TenantScoped):
    """Per-customer state the suppression rules key on.

    A6 and A7 both have rules that are legal or reputational rather than
    stylistic -- never nudge someone who opted out, never ask the same person
    for a review twice in 90 days. Those live here and are enforced by
    application code BEFORE the agent is called, because "the model remembered"
    is not a defence.
    """

    __tablename__ = "customers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    customer_ref: Mapped[str] = mapped_column(String(255), index=True)
    name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    language: Mapped[str] = mapped_column(String(16), default="en")
    opt_out: Mapped[bool] = mapped_column(Boolean, default=False)
    dormant: Mapped[bool] = mapped_column(Boolean, default=False)
    nudge_count: Mapped[int] = mapped_column(Integer, default=0)
    last_nudge_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_nudge_reply_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_review_ask_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    __table_args__ = (
        UniqueConstraint("tenant_id", "customer_ref", name="uq_customer_ref"),
    )


class Offer(Base, TenantScoped):
    """Slot options that were actually sent to a customer, and are awaiting a reply.

    This exists so a customer's "2" or "friday works" can be matched back to a
    real slot id without a human reading the thread. Section 4 / A3 forbids the
    agent from reserving anything, and section 1.2 Law 1 puts every write in
    application code -- so the options are recorded here when the message goes
    out, and `runtime/confirm.py` turns a reply into a booking.

    Without this table the only way to close a booking is a person reading the
    thread and clicking, which is the staff work the whole archetype exists to
    remove.
    """

    __tablename__ = "offers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    customer_ref: Mapped[str] = mapped_column(String(255), index=True)
    decision_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    service_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    options: Mapped[dict] = mapped_column(JSON, default=list)
    state: Mapped[str] = mapped_column(String(24), default="open", index=True)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime, index=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class RateLimitBucket(Base, TenantScoped):
    __tablename__ = "rate_limit_buckets"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(64), index=True)
    sender_ref: Mapped[str] = mapped_column(String(255), index=True)
    window_start: Mapped[datetime] = mapped_column(UTCDateTime)
    count: Mapped[int] = mapped_column(Integer, default=0)
    __table_args__ = (
        UniqueConstraint("tenant_id", "sender_ref", "window_start", name="uq_rl_bucket"),
    )
