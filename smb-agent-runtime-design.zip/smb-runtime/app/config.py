"""Runtime settings. Everything that differs between dev, staging and prod lives here."""
from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class Settings:
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./smb_runtime.db")

    # Global kill switch. Flips every tenant off at once. Env-driven on purpose:
    # you must be able to stop the fleet without a deploy and without a DB write.
    global_kill_switch: bool = os.getenv("GLOBAL_KILL_SWITCH", "false").lower() == "true"

    # "null" until an agent's eval gates pass. "echo" in tests, "anthropic" live.
    llm_provider: str = os.getenv("LLM_PROVIDER", "null")

    # A1 and A2 are high-volume classifiers with short outputs; the small model
    # is the right default and the eval harness is how you find out whether it
    # holds. Override per agent in runtime/agents.py, globally here.
    default_model: str = os.getenv("DEFAULT_MODEL", "claude-haiku-5-5")

    # Section 2.4 calls the guard "a cheap second model call" that "costs almost
    # nothing". Separate setting so it can stay cheap when agents move up.
    guard_model: str = os.getenv("GUARD_MODEL", "claude-haiku-5-5")

    # Dedupe window for inbound events lacking a stable external id.
    dedupe_window_seconds: int = int(os.getenv("DEDUPE_WINDOW_SECONDS", "300"))

    # Per-sender inbound rate limit, applied before any model call.
    rate_limit_messages: int = int(os.getenv("RATE_LIMIT_MESSAGES", "20"))
    rate_limit_window_seconds: int = int(os.getenv("RATE_LIMIT_WINDOW_SECONDS", "3600"))

    # Queue lease. A job held longer than this is assumed dead and becomes claimable.
    job_lease_seconds: int = int(os.getenv("JOB_LEASE_SECONDS", "120"))
    max_job_attempts: int = int(os.getenv("MAX_JOB_ATTEMPTS", "3"))

    # Cost model, in micro-rupees per token, so cap arithmetic stays in integers.
    #
    # Derived from Claude Haiku 5.5 list pricing ($0.10 / $0.50 per million
    # tokens for prompts under 100k), converted at roughly INR 88/USD:
    #   input   $0.10/M -> INR 8.8/M  ->  9 micro-rupees per token
    #   output  $0.50/M -> INR 44/M   -> 44 micro-rupees per token
    #   cache read  ~10% of input     ->  1 micro-rupee per token
    #   cache write ~1.25x input      -> 11 micro-rupees per token
    #
    # These are LIST prices at one exchange rate on one day, which means they
    # are an estimate and will drift. Check your actual invoice before quoting
    # a per-message cost to a client, and set GUARD_MODEL / DEFAULT_MODEL to
    # whatever you actually run -- a Sonnet-tier model is roughly 30x these
    # numbers and the caps below would need to move with it.
    input_token_micros: int = int(os.getenv("INPUT_TOKEN_MICROS", "9"))
    output_token_micros: int = int(os.getenv("OUTPUT_TOKEN_MICROS", "44"))
    cache_read_token_micros: int = int(os.getenv("CACHE_READ_TOKEN_MICROS", "1"))

    console_api_key: str = os.getenv("CONSOLE_API_KEY", "dev-console-key")
    admin_api_key: str = os.getenv("ADMIN_API_KEY", "dev-admin-key")


settings = Settings()
