"""Prompt bodies, one module per agent, each carrying its own version string.

Bodies live in version-controlled Python rather than a database so that a
prompt change is a reviewable diff in a pull request. The database copy
(`prompts` table) is written on startup by `runtime.prompts.sync_to_db` and
exists so that six months from now an audit row naming sha `c3c3e988` can be
resolved back to the exact text that produced it.

Spec closing note: "Version them from the first commit, log the version on
every call, and never change a prompt and a tool in the same deploy."

VERSIONING RULE
  Bump the version on ANY change to a body, including whitespace. The sha is
  computed from the text and is the real identity; the semver string is for
  humans reading the eval report. Changing a body without bumping the version
  makes two different prompts share a label, and every metric in section 1.4
  that is grouped by version silently merges them.
"""
from __future__ import annotations

from app.prompts.a1_triage import A1_BODY, A1_VERSION
from app.prompts.a2_urgency import A2_BODY, A2_VERSION
from app.prompts.a3_slots import A3_BODY, A3_VERSION
from app.prompts.a4_reply import A4_BODY, A4_VERSION
from app.prompts.a5_reminder import A5_BODY, A5_VERSION
from app.prompts.a6_review import A6_BODY, A6_VERSION
from app.prompts.a7_recurrence import A7_BODY, A7_VERSION
from app.prompts.a8_analyst import A8_BODY, A8_VERSION

__all__ = ["A1_BODY", "A1_VERSION", "A2_BODY", "A2_VERSION",
           "A3_BODY", "A3_VERSION", "A4_BODY", "A4_VERSION",
           "A5_BODY", "A5_VERSION", "A6_BODY", "A6_VERSION",
           "A7_BODY", "A7_VERSION", "A8_BODY", "A8_VERSION"]
