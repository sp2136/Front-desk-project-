"""Eval runner, section 11.

Runs a frozen case file against an agent, through the SAME prompt assembly and
the SAME output contract the pipeline uses. Not a parallel implementation:
if the harness built its own prompt, a passing eval would say nothing about
production.

It deliberately does NOT use the queue, the tenant database rows or the caps.
An eval is a measurement of a prompt, and coupling it to infrastructure makes a
red result ambiguous between "the prompt regressed" and "the queue was slow".
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from zoneinfo import ZoneInfo

from pydantic import ValidationError

from app.config import settings
from app.eval.cases import EvalCase
from app.eval.scoring import CaseResult, Metric, check_case, gates_pass, summarise
from app.runtime import agents
from app.runtime.errors import ModelUnavailable
from app.runtime.llm import LLMProvider
from app.runtime.prompts import build_user_message
from app.runtime.prompts import store as prompt_store
from app.schemas.tenant import TenantConfig


@dataclass
class EvalReport:
    agent: str
    prompt_version: str
    prompt_sha256: str
    model: str
    case_file: str
    case_file_sha256: str
    started_at: str
    results: list[CaseResult] = field(default_factory=list)
    metrics: list[Metric] = field(default_factory=list)
    gates_ok: bool = False
    blocking: list[str] = field(default_factory=list)

    def render(self) -> str:
        lines = [
            "=" * 78,
            f"EVAL  {self.agent}  prompt {self.prompt_version}@{self.prompt_sha256[:12]}",
            f"      model {self.model}",
            f"      cases {self.case_file}  frozen@{self.case_file_sha256[:12]}",
            f"      run   {self.started_at}",
            "=" * 78,
            "",
        ]
        for m in self.metrics:
            lines.append("  " + m.display)

        failed = [r for r in self.results if not r.passed]
        lines += ["", f"  cases: {len(self.results)}  passed: "
                      f"{len(self.results) - len(failed)}  failed: {len(failed)}"]
        if failed:
            lines.append("")
            lines.append("  FAILURES")
            for r in failed:
                head = f"    {r.case_id} [{r.source}]"
                if r.error:
                    lines.append(f"{head}  ERROR {r.error}")
                for f in r.failures:
                    lines.append(f"{head}  {f}")

        slow = [r for r in self.results if r.over_latency_budget]
        if slow:
            lines.append("")
            lines.append(f"  over latency budget: {len(slow)} case(s)")
        dirty = [r for r in self.results if r.required_cleanup]
        if dirty:
            lines.append(f"  needed de-fencing:   {len(dirty)} case(s) "
                         "(preamble rule 5 violation; counts against schema validity)")

        lines += ["", "=" * 78]
        if self.gates_ok:
            lines.append("  GATES PASS -- this prompt version may go live for this agent.")
        else:
            lines.append("  GATES BLOCKED: " + ", ".join(self.blocking))
            lines.append("  Section 11.3: any other outcome blocks the launch.")
        lines.append("=" * 78)
        return "\n".join(lines)


def _system_context(cfg: TenantConfig) -> dict:
    now_local = datetime.now(UTC).astimezone(ZoneInfo(cfg.timezone))
    return {
        "tenant_name": cfg.tenant_name,
        "business_type": cfg.business_type,
        "city": cfg.city,
        "today": now_local.date().isoformat(),
        "languages": json.dumps(cfg.languages),
        "escalation_threshold": cfg.escalation_threshold,
        "event": "<event>",
        "history": "<history>",
    }


def _user_for(case: EvalCase, cfg: TenantConfig, spec: agents.AgentSpec,
              catalogue: list[dict]) -> str:
    blocks: dict[str, object] = {"event": case.event, "history": case.history}
    for pf in spec.prefetch:
        if pf.block == "service_catalogue":
            blocks["service_catalogue"] = catalogue
        elif pf.block == "customer_record":
            blocks["customer_record"] = None
    if spec.agent_id == "A2":
        blocks["a1_output"] = case.upstream_a1
        blocks["business_type"] = cfg.business_type
        blocks["urgency_keywords"] = cfg.urgency_keywords
    if spec.agent_id == "A3":
        blocks["a1_output"] = case.upstream_a1
        for name in ("availability", "resources", "customer_record", "policy_block"):
            if name in case.facts:
                blocks[name] = case.facts[name]
        blocks.setdefault("availability", [])
    if spec.agent_id == "A5":
        for name in ("booking", "customer", "policy_block", "reminder_stage"):
            if name in case.facts:
                blocks[name] = case.facts[name]
    if spec.agent_id == "A6":
        for name in ("booking", "internal_notes", "review_link", "prior_asks"):
            if name in case.facts:
                blocks[name] = case.facts[name]
        if "history" in case.facts:
            blocks["history"] = case.facts["history"]
    if spec.agent_id == "A7":
        for name in ("customer", "visit_history", "recall_rules",
                     "contact_history", "opt_out"):
            if name in case.facts:
                blocks[name] = case.facts[name]
    if spec.agent_id == "A4":
        blocks["a1_output"] = case.upstream_a1
        # The case supplies the approved facts directly, overriding the
        # pre-fetch defaults: an A4 eval is a test of how the agent uses a
        # known fact set, not a test of the FAQ retriever.
        for name in ("faq_answers", "service_facts", "policy_block", "a3_options"):
            if name in case.facts:
                blocks[name] = case.facts[name]
    return build_user_message(**blocks)


def run_eval(agent_id: str, cases: list[EvalCase], provider: LLMProvider,
             base_config: dict, case_file: str, case_file_sha: str,
             model: str | None = None) -> EvalReport:
    spec = agents.get(agent_id)
    cfg0 = TenantConfig(**base_config)
    assembled = prompt_store.assemble(agent_id, _system_context(cfg0))
    if assembled.unresolved:
        raise ValueError(f"unresolved placeholders in {agent_id}: {assembled.unresolved}")

    model = model or spec.model or settings.default_model
    report = EvalReport(
        agent=agent_id,
        prompt_version=assembled.version,
        prompt_sha256=assembled.sha256,
        model=model,
        case_file=case_file,
        case_file_sha256=case_file_sha,
        started_at=datetime.now(UTC).isoformat(timespec="seconds"),
    )

    catalogue = base_config.get("service_catalogue", [])

    for case in [c for c in cases if c.agent == agent_id]:
        cfg = TenantConfig(**{**base_config, **case.tenant_overrides})
        system = prompt_store.assemble(agent_id, _system_context(cfg)).text
        user = _user_for(case, cfg, spec, catalogue)
        result = CaseResult(case_id=case.case_id, agent=agent_id, source=case.source.value)

        started = time.perf_counter()
        try:
            llm = provider.complete(system, user, max_tokens=spec.max_tokens, model=model)
        except ModelUnavailable as exc:
            result.error = f"model_unavailable: {exc}"
            report.results.append(result)
            continue
        result.latency_ms = int((time.perf_counter() - started) * 1000)
        result.over_latency_budget = result.latency_ms > spec.latency_budget_ms
        result.required_cleanup = llm.required_cleanup

        try:
            envelope = spec.output_model.model_validate_json(llm.text)
        except ValidationError as exc:
            result.schema_valid_first_try = False
            result.failures.append(
                "schema: " + json.dumps(exc.errors(include_url=False), default=str)[:300]
            )
            report.results.append(result)
            continue

        # A model that emitted fences produced output the contract forbids, so
        # it does not count as valid on the first try even though it parsed
        # after cleanup. Section 11.2 gates this at 100%; quietly forgiving it
        # would move the number without moving the behaviour.
        result.schema_valid_first_try = not llm.required_cleanup
        result.parsed = envelope.model_dump(mode="json")
        report.results.append(check_case(case, result))

    report.metrics = summarise([c for c in cases if c.agent == agent_id], report.results)
    report.gates_ok, report.blocking = gates_pass(report.metrics)
    return report
