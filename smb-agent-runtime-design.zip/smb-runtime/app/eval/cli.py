"""Eval CLI.

    python -m app.eval.cli --agent A1 --cases evals/a1_cases.jsonl
    python -m app.eval.cli --agent A2 --cases evals/a2_cases.jsonl --provider anthropic
    python -m app.eval.cli --freeze evals/a1_cases.jsonl

Exits non-zero when the gates block, so it drops straight into CI. Section 11:
"When a prompt changes, the same file runs again."
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

from app.config import settings
from app.eval import cases as case_mod
from app.eval.harness import run_eval
from app.runtime import tool_impls  # noqa: F401
from app.runtime.llm import AnthropicProvider, EchoProvider, NullProvider

ROOT = pathlib.Path(__file__).resolve().parents[2]
DEFAULT_TENANT = ROOT / "seeds" / "tenant_dentist.json"


def _provider(name: str, replay: str | None):
    if replay:
        # Replay a recorded set of outputs keyed by case_id: lets a report be
        # regenerated, and the harness itself tested, without a model.
        # Keyed on the event body rather than a case id: injecting an id into
        # the event block would change what the model sees, so a replay would
        # not be a replay of the real call.
        recorded = json.loads(pathlib.Path(replay).read_text())

        def responder(system: str, user: str) -> str:
            payload = json.loads(user.split("<event>\n", 1)[1].split("\n</event>", 1)[0])
            return recorded[payload.get("body", "")]

        return EchoProvider(responder=responder)
    from app.runtime.stub_provider import StubProvider

    return {"null": NullProvider, "echo": EchoProvider, "stub": StubProvider,
            "anthropic": AnthropicProvider}[name]()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Run a frozen eval case file (section 11)")
    ap.add_argument("--agent", help="A1 | A2 | GUARD")
    ap.add_argument("--cases", help="path to a JSONL case file")
    ap.add_argument("--tenant", default=str(DEFAULT_TENANT))
    ap.add_argument("--provider", default=settings.llm_provider,
                    choices=["null", "echo", "stub", "anthropic"])
    ap.add_argument("--model", default=None)
    ap.add_argument("--replay", default=None, help="JSON of case_id -> raw output")
    ap.add_argument("--freeze", default=None, help="print a case file's sha256 and exit")
    ap.add_argument("--json", action="store_true", help="emit the report as JSON")
    args = ap.parse_args(argv)

    if args.freeze:
        print(case_mod.freeze(args.freeze))
        return 0

    if not args.agent or not args.cases:
        ap.error("--agent and --cases are required unless --freeze is given")

    if args.agent.upper() == "GUARD":
        from app.eval import guard_eval

        g_cases = guard_eval.load(args.cases)
        g_report = guard_eval.run_guard_eval(
            g_cases, _provider(args.provider, args.replay), args.cases,
            guard_eval.freeze(args.cases), model=args.model,
        )
        print(g_report.render())
        return 0 if g_report.gates_ok else 1

    cases = case_mod.load(args.cases)
    sha = case_mod.freeze(args.cases)
    tenant_cfg = json.loads(pathlib.Path(args.tenant).read_text())
    tenant_cfg["agents_enabled"] = [args.agent]

    report = run_eval(
        args.agent, cases, _provider(args.provider, args.replay),
        tenant_cfg, args.cases, sha, model=args.model,
    )

    if args.json:
        print(json.dumps({
            "agent": report.agent,
            "prompt_version": report.prompt_version,
            "prompt_sha256": report.prompt_sha256,
            "case_file_sha256": report.case_file_sha256,
            "gates_ok": report.gates_ok,
            "blocking": report.blocking,
            "metrics": [{"name": m.name, "value": m.value, "n": m.n,
                         "gate": m.gate, "passed": m.passed} for m in report.metrics],
            "failures": [{"case_id": r.case_id, "failures": r.failures, "error": r.error}
                         for r in report.results if not r.passed],
        }, indent=2))
    else:
        print(report.render())

    return 0 if report.gates_ok else 1


if __name__ == "__main__":
    sys.exit(main())
