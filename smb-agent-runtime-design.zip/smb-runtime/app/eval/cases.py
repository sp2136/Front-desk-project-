"""Eval case file format, section 11.1.

A case is one inbound message plus the hand-labelled correct output. The file
is JSONL, one case per line, and it is FROZEN: `freeze()` records a sha256 that
every report carries.

Section 11.1: "Freeze it. A case file that changes with every prompt edit
measures nothing." The hash is how you find out that it changed.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class CaseSource(StrEnum):
    REAL_TRAFFIC = "real_traffic"   # exported from a pilot tenant, hand-labelled
    REDTEAM = "redteam"             # section 11.3
    SYNTHETIC = "synthetic"         # written by hand; NOT a substitute for the above


class Expectation(BaseModel):
    """What correct looks like. Every field is optional: a red-team case may
    assert only that nothing was leaked, and a traffic case only the intent."""

    model_config = ConfigDict(extra="forbid")

    intent: str | None = None            # A1
    intent_handled: str | None = None    # A4 -- same metric, different field name
    language: str | None = None
    level: str | None = None                       # A2
    service_id: str | None = None

    escalate: bool | None = None
    reason: str | None = None

    # Ground truth for escalation recall, which is the metric that matters.
    # Kept separate from `escalate` so a case can say "a human was genuinely
    # needed here" without also asserting which reason code is correct.
    human_needed: bool | None = None

    # Red lines. Any of these appearing anywhere in the serialised output is a
    # violation, gated at zero.
    forbidden_substrings: list[str] = Field(default_factory=list)
    # No digit may appear in any output field unless it appears in the input
    # or in `facts`. Catches invented prices, durations and lead times.
    forbid_unsourced_numbers: bool = False

    # A4 only. Section 4 / A4 sets a hard ceiling of 80 words on a draft; a
    # 200-word reply is not a style problem, it is a draft the front desk will
    # rewrite, which is the one thing A4 is measured on.
    max_draft_words: int | None = None

    # A4 only. The missing-fact discipline: when the needed fact is absent,
    # the draft must name the gap rather than work around it.
    require_missing: bool | None = None

    # A3 only.
    max_options: int | None = None
    # Every option must exist verbatim in <availability>. This is A3's single
    # most important rule: an invented slot_id becomes a soft-lock attempt on a
    # slot that does not exist, and a rounded time becomes a customer told to
    # arrive at an hour nobody is open.
    options_from_availability: bool = False
    # Minimum number of distinct calendar days across the options, so "do not
    # offer three consecutive slots on one day" is measurable.
    options_on_distinct_days: int | None = None
    # A named resource with nothing open must be said explicitly.
    require_unavailable_note: bool | None = None

    # A6 only. Section 4 / A6: a negative thread must produce NO
    # customer-facing draft. Asserting "draft is absent" is the whole test for
    # the most dangerous agent in the archetype.
    sentiment: str | None = None
    ask: bool | None = None
    route_to_owner: bool | None = None
    no_draft: bool = False

    # A7 only.
    suppress_reason: str | None = None


class EvalCase(BaseModel):
    model_config = ConfigDict(extra="forbid")

    case_id: str
    agent: str
    source: CaseSource
    note: str = ""
    event: dict
    history: list[dict] = Field(default_factory=list)
    upstream_a1: dict = Field(default_factory=dict)   # A2 and A4 cases
    # A4 cases: the approved facts the draft is allowed to be built from.
    # Keys match the context block names: faq_answers, service_facts,
    # policy_block, a3_options.
    facts: dict = Field(default_factory=dict)
    tenant_overrides: dict = Field(default_factory=dict)
    expect: Expectation = Field(default_factory=Expectation)


def load(path: str | pathlib.Path) -> list[EvalCase]:
    lines = [
        ln for ln in pathlib.Path(path).read_text(encoding="utf-8").splitlines()
        if ln.strip() and not ln.lstrip().startswith("//")
    ]
    return [EvalCase.model_validate_json(ln) for ln in lines]


def freeze(path: str | pathlib.Path) -> str:
    """Content hash of the case file, recorded in every report."""
    return hashlib.sha256(
        pathlib.Path(path).read_bytes()
    ).hexdigest()


def dump(cases: list[EvalCase], path: str | pathlib.Path) -> None:
    pathlib.Path(path).write_text(
        "\n".join(json.dumps(c.model_dump(mode="json"), sort_keys=True) for c in cases)
        + "\n",
        encoding="utf-8",
    )
