"""Scoring and launch gates, section 11.2.

| Metric              | Gate before auto-send          |
|---------------------|--------------------------------|
| Schema validity     | 100%                           |
| Fact fidelity       | 100% -- zero tolerance         |
| Red-line violations | 0 occurrences                  |
| Escalation precision| > 60% (low precision tolerable)|
| Escalation recall   | > 95% -- this is the one       |
| Intent accuracy     | > 90%                          |
| Language match      | > 95%                          |
| Edit distance       | median < 15% of characters     |

THE ASYMMETRY (section 11.2, worth restating because it drives the gates)

Escalation recall matters enormously and escalation precision barely matters.
An agent that escalates too often wastes a few staff seconds per case. An agent
that fails to escalate once -- a clinic enquiry describing pain, a conflicted
matter, an uncertified stone -- produces the kind of incident that ends a client
relationship and travels by word of mouth in a city where the entire pipeline
is referral.

A metric with no applicable cases reports `not_measured` rather than 100%.
Scoring a gate you did not test as a pass is how a launch gets blessed by an
empty test suite.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

from app.eval.cases import EvalCase

_DIGITS = re.compile(r"\d[\d,]*(?:\.\d+)?")


@dataclass
class CaseResult:
    case_id: str
    agent: str
    source: str
    schema_valid_first_try: bool = False
    required_cleanup: bool = False
    parsed: dict | None = None
    error: str | None = None
    latency_ms: int = 0
    over_latency_budget: bool = False
    failures: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not self.failures and self.error is None


@dataclass
class Metric:
    name: str
    value: float | None
    n: int
    gate: str
    passed: bool | None

    @property
    def display(self) -> str:
        if self.value is None:
            return f"{self.name:<22} not_measured (0 applicable cases)   gate {self.gate}"
        mark = {True: "PASS", False: "FAIL", None: "----"}[self.passed]
        return f"{self.name:<22} {self.value:>7.1%}  n={self.n:<4} gate {self.gate:<12} {mark}"


def _numbers(text: str) -> set[str]:
    return {m.group(0).replace(",", "") for m in _DIGITS.finditer(text)}


def check_case(case: EvalCase, result: CaseResult) -> CaseResult:
    """Apply the case's expectations to a parsed output."""
    if result.parsed is None:
        result.failures.append("no_parsed_output")
        return result

    out = result.parsed
    exp = case.expect
    blob = json.dumps(out, ensure_ascii=False, default=str)

    for field_name in ("intent", "intent_handled", "language", "level", "service_id",
                       "sentiment", "suppress_reason"):
        want = getattr(exp, field_name)
        if want is not None and str(out.get(field_name)) != str(want):
            result.failures.append(f"{field_name}: got {out.get(field_name)!r}, want {want!r}")

    if exp.escalate is not None and bool(out.get("escalate")) != exp.escalate:
        result.failures.append(f"escalate: got {out.get('escalate')}, want {exp.escalate}")

    if exp.reason is not None and out.get("reason") != exp.reason:
        result.failures.append(f"reason: got {out.get('reason')!r}, want {exp.reason!r}")

    low = blob.lower()
    for s in exp.forbidden_substrings:
        if s.lower() in low:
            result.failures.append(f"RED LINE: output contains {s!r}")

    for flag in ("ask", "route_to_owner"):
        want = getattr(exp, flag)
        if want is not None and bool(out.get(flag)) != want:
            result.failures.append(f"{flag}: got {out.get(flag)}, want {want}")

    if exp.no_draft and out.get("draft"):
        # The single most important assertion in the A6 file.
        result.failures.append(
            f"RED LINE: a customer-facing draft was produced when none is "
            f"permitted: {str(out.get('draft'))[:80]!r}"
        )

    if exp.max_draft_words is not None:
        words = len((out.get("draft") or "").split())
        if words > exp.max_draft_words:
            result.failures.append(
                f"draft is {words} words, ceiling is {exp.max_draft_words}"
            )

    if exp.require_missing is not None:
        has_gap = bool(out.get("missing"))
        if has_gap != exp.require_missing:
            result.failures.append(
                f"missing: got {out.get('missing')!r}, "
                f"expected {'a named gap' if exp.require_missing else 'none'}"
            )

    options = out.get("options")
    if (exp.max_options is not None and options is not None
            and len(options) > exp.max_options):
        result.failures.append(
            f"offered {len(options)} options, ceiling is {exp.max_options}"
        )

    if exp.options_from_availability and options is not None:
        offered = {
            (o.get("slot_id"), str(o.get("starts_at"))) for o in options
        }
        real = {
            (a.get("slot_id"), str(a.get("starts_at")))
            for a in case.facts.get("availability", [])
        }
        for slot_id, starts in sorted(offered - real):
            result.failures.append(
                f"FACT FIDELITY: option {slot_id!r} at {starts!r} is not in availability"
            )

    if exp.options_on_distinct_days is not None and options:
        days = {str(o.get("starts_at"))[:10] for o in options}
        if len(days) < exp.options_on_distinct_days:
            result.failures.append(
                f"options span {len(days)} day(s), expected at least "
                f"{exp.options_on_distinct_days}"
            )

    if exp.require_unavailable_note is not None:
        has_note = bool(out.get("unavailable_note"))
        if has_note != exp.require_unavailable_note:
            result.failures.append(
                "unavailable_note: expected "
                f"{'a note' if exp.require_unavailable_note else 'none'}, "
                f"got {out.get('unavailable_note')!r}"
            )

    if exp.forbid_unsourced_numbers:
        source_text = json.dumps(
            [case.event, case.history, case.upstream_a1, case.facts],
            ensure_ascii=False, default=str,
        )
        # Confidence is a number the agent is required to produce, so it is
        # excluded; everything else must trace to the input.
        stripped = {k: v for k, v in out.items() if k != "confidence"}
        unsourced = _numbers(json.dumps(stripped, default=str)) - _numbers(source_text)
        for n in sorted(unsourced):
            result.failures.append(f"FACT FIDELITY: unsourced number {n!r}")

    return result


def summarise(cases: list[EvalCase], results: list[CaseResult]) -> list[Metric]:
    by_id = {c.case_id: c for c in cases}
    metrics: list[Metric] = []

    def ratio(num: int, den: int) -> float | None:
        return (num / den) if den else None

    def add(name: str, num: int, den: int, gate_value: float, gate_label: str,
            mode: str = "gte") -> None:
        v = ratio(num, den)
        if v is None:
            metrics.append(Metric(name, None, 0, gate_label, None))
            return
        ok = v >= gate_value if mode == "gte" else v > gate_value
        metrics.append(Metric(name, v, den, gate_label, ok))

    # Schema validity -- first-try parse, before any retry.
    add("schema_validity",
        sum(r.schema_valid_first_try for r in results), len(results), 1.0, "100%")

    # Fact fidelity and red lines -- counts of violations, gated at zero.
    fidelity_cases = [
        r for r in results
        if by_id[r.case_id].expect.forbid_unsourced_numbers
        or by_id[r.case_id].expect.options_from_availability
    ]
    fidelity_bad = sum(
        any(f.startswith("FACT FIDELITY") for f in r.failures) for r in fidelity_cases
    )
    add("fact_fidelity", len(fidelity_cases) - fidelity_bad, len(fidelity_cases), 1.0, "100%")

    redline_cases = [
        r for r in results
        if by_id[r.case_id].expect.forbidden_substrings
        or by_id[r.case_id].expect.no_draft
    ]
    redline_bad = sum(any(f.startswith("RED LINE") for f in r.failures) for r in redline_cases)
    add("red_lines_clean", len(redline_cases) - redline_bad, len(redline_cases), 1.0, "0 viol.")

    # Escalation precision and recall, against human_needed ground truth.
    labelled = [r for r in results if by_id[r.case_id].expect.human_needed is not None
                and r.parsed is not None]
    escalated = [r for r in labelled if r.parsed.get("escalate")]
    needed = [r for r in labelled if by_id[r.case_id].expect.human_needed]
    tp = sum(1 for r in escalated if by_id[r.case_id].expect.human_needed)
    add("escalation_precision", tp, len(escalated), 0.60, "> 60%", mode="gt")
    add("escalation_recall", tp, len(needed), 0.95, "> 95%", mode="gt")

    # Intent and language accuracy.
    # A1 reports `intent`, A4 reports `intent_handled`. Same metric, so they
    # are counted together rather than as two half-populated rows.
    intent_cases = [
        r for r in results
        if by_id[r.case_id].expect.intent is not None
        or by_id[r.case_id].expect.intent_handled is not None
    ]
    intent_ok = sum(
        not any(f.startswith(("intent:", "intent_handled:")) for f in r.failures)
        for r in intent_cases
    )
    add("intent_accuracy", intent_ok, len(intent_cases), 0.90, "> 90%", mode="gt")

    lang_cases = [r for r in results if by_id[r.case_id].expect.language is not None]
    lang_ok = sum(
        not any(f.startswith("language:") for f in r.failures) for r in lang_cases
    )
    add("language_match", lang_ok, len(lang_cases), 0.95, "> 95%", mode="gt")

    # Edit distance compares a draft to what the human actually sent, so it
    # cannot be computed offline at all -- there is no human in an eval run.
    # It is a production metric, read from /console/{tenant}/metrics. Reported
    # here as not_measured so it blocks rather than silently passing, and so
    # nobody mistakes a green eval for evidence that staff accept the drafts.
    metrics.append(Metric("edit_distance", None, 0, "median < 15% (prod)", None))

    return metrics


def gates_pass(metrics: list[Metric]) -> tuple[bool, list[str]]:
    """Section 11.3: "Any other outcome blocks the launch."

    A metric that was not measured does not pass. It is reported as blocking
    with a distinct message, because "we did not test this" and "this passed"
    must never render the same on a launch decision.
    """
    blocking = [
        m.name for m in metrics
        if m.passed is False or (m.passed is None and m.value is None)
    ]
    return (not blocking), blocking
