"""Engine, sessions, and the tenant isolation guard.

Section 1.3 names cross-tenant leakage "the one unsurvivable bug", and section
11.3 says tenant isolation must be tested in code, not only in prompt. Two
controls, both required:

  1. TenantScope, below. Every read an agent can reach goes through it. It
     refuses to build a query for a model that is not TenantScoped, and it
     injects the tenant_id filter itself so no caller can forget to.

  2. Postgres row-level security, in sql/rls.sql, keyed on the same column.
     Defence in depth: if a future developer bypasses TenantScope, RLS still
     holds. SQLite has no RLS, which is why dev parity stops at control 1 and
     production must be Postgres.
"""
from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any, TypeVar

from sqlalchemy import Select, create_engine, event, select, text
from sqlalchemy.orm import Session, sessionmaker

from app.config import settings
from app.models import Base, TenantScoped
from app.runtime.errors import TenantIsolationError

T = TypeVar("T")

_is_sqlite = settings.database_url.startswith("sqlite")
_connect_args = {"check_same_thread": False} if _is_sqlite else {}
engine = create_engine(settings.database_url, future=True, connect_args=_connect_args)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False, future=True)


if settings.database_url.startswith("sqlite"):

    @event.listens_for(engine, "connect")
    def _sqlite_pragmas(dbapi_conn, _record):  # pragma: no cover - driver glue
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.execute("PRAGMA journal_mode=WAL")
        cur.close()


def init_db() -> None:
    Base.metadata.create_all(engine)


def schema_drift() -> list[str]:
    """Tables and columns the models expect that the database does not have.

    `create_all` creates missing TABLES and silently ignores missing COLUMNS on
    tables that already exist. So upgrading the code over an existing SQLite
    file leaves a database that opens fine, serves most requests fine, and then
    returns 500 from any query touching a new column -- which in the UI looks
    like "the page will not load" rather than "the schema is behind".

    This is why that failure mode is worth detecting explicitly instead of
    waiting for the first stack trace: the symptom points nowhere near the
    cause. Real deployments get migrations (Alembic); the sandbox gets a reset.
    """
    from sqlalchemy import inspect

    inspector = inspect(engine)
    existing_tables = set(inspector.get_table_names())
    problems: list[str] = []

    for name, table in Base.metadata.tables.items():
        if name not in existing_tables:
            problems.append(f"missing table: {name}")
            continue
        have = {c["name"] for c in inspector.get_columns(name)}
        for column in table.columns:
            if column.name not in have:
                problems.append(f"missing column: {name}.{column.name}")
    return problems


def reset_schema() -> None:
    """Drop and recreate everything. Demo databases only."""
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)


@contextmanager
def session_scope() -> Iterator[Session]:
    s = SessionLocal()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


class TenantScope:
    """A session bound to exactly one tenant.

    Construct it once per job, hand it to tools, and there is no API surface
    through which a tool can read another tenant's rows.
    """

    def __init__(self, session: Session, tenant_id: str) -> None:
        if not tenant_id:
            raise TenantIsolationError("TenantScope requires a tenant_id")
        self._session = session
        self.tenant_id = tenant_id
        self._apply_session_guc()

    def _apply_session_guc(self) -> None:
        """Set the Postgres GUC that RLS policies read. No-op on SQLite."""
        if self._session.bind and self._session.bind.dialect.name == "postgresql":
            self._session.execute(
                text("SELECT set_config('app.tenant_id', :tid, true)"),
                {"tid": self.tenant_id},
            )

    @property
    def session(self) -> Session:
        """Raw session. Deliberately not handed to tools -- only the runtime's
        own writers use this."""
        return self._session

    def query(self, model: type[T]) -> Select:
        if not issubclass(model, TenantScoped):
            raise TenantIsolationError(
                f"{model.__name__} is not TenantScoped and cannot be queried through a scope"
            )
        return select(model).where(model.tenant_id == self.tenant_id)  # type: ignore[attr-defined]

    def all(self, model: type[T], *conditions: Any) -> list[T]:
        stmt = self.query(model)
        for c in conditions:
            stmt = stmt.where(c)
        return list(self._session.execute(stmt).scalars().all())

    def one_or_none(self, model: type[T], *conditions: Any) -> T | None:
        stmt = self.query(model)
        for c in conditions:
            stmt = stmt.where(c)
        return self._session.execute(stmt.limit(1)).scalars().first()

    def add(self, row: Any) -> Any:
        """Writes go through here so tenant_id can never be wrong or absent."""
        if isinstance(row, TenantScoped):
            existing = getattr(row, "tenant_id", None)
            if existing and existing != self.tenant_id:
                raise TenantIsolationError(
                    f"refusing to write {type(row).__name__} for tenant {existing} "
                    f"inside a scope for {self.tenant_id}"
                )
            row.tenant_id = self.tenant_id
        self._session.add(row)
        return row

    def flush(self) -> None:
        self._session.flush()
