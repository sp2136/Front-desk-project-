"""Agent output contracts.

Stage 0 ships the contracts, not the prompts. That is the whole point of the
sequencing in section 12: the runtime must be able to reject a malformed A1
output before anyone has written A1's prompt, otherwise the first thing you
test at stage 1 is two untested things at once.

The prompt bodies live in app/runtime/prompts.py and are empty at stage 0.
"""
from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.schemas.envelope import Envelope, Evidence


class Language(StrEnum):
    GU = "gu"
    GU_LATN = "gu-Latn"
    HI = "hi"
    HI_LATN = "hi-Latn"
    EN = "en"
    MIXED = "mixed"


class Intent(StrEnum):
    BOOK = "book"
    RESCHEDULE = "reschedule"
    CANCEL = "cancel"
    PRICE_ENQUIRY = "price_enquiry"
    SERVICE_ENQUIRY = "service_enquiry"
    LOCATION_HOURS = "location_hours"
    COMPLAINT = "complaint"
    FOLLOW_UP_EXISTING = "follow_up_existing"
    DOCUMENT_OR_REPORT = "document_or_report"
    SPAM = "spam"
    OTHER = "other"


class PartOfDay(StrEnum):
    MORNING = "morning"
    AFTERNOON = "afternoon"
    EVENING = "evening"


class CustomerRef(BaseModel):
    model_config = ConfigDict(extra="forbid")
    known: bool
    id: str | None = None
    name: str | None = None


class TimeWindow(BaseModel):
    model_config = ConfigDict(extra="forbid")
    earliest: datetime | None = None
    latest: datetime | None = None
    preferred_days: list[str] = Field(default_factory=list)
    part_of_day: PartOfDay | None = None


class A1Output(Envelope):
    """Intake Triage, section 4 / A1."""

    intent: Intent
    service_id: str | None = None
    service_guess: str | None = None
    raw_complaint_text: str | None = None
    language: Language
    customer: CustomerRef
    time_window: TimeWindow = Field(default_factory=TimeWindow)
    blockers: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _complaint_always_escalates(self) -> A1Output:
        # A1's escalation list: "Intent is complaint -- never auto-handled in any
        # archetype." Encoded here so a prompt regression cannot lose it.
        if self.intent == Intent.COMPLAINT and not self.escalate:
            raise ValueError("intent=complaint must set escalate=true")
        return self


class UrgencyLevel(StrEnum):
    IMMEDIATE = "immediate"
    SAME_DAY = "same_day"
    ROUTINE = "routine"


class A2Output(Envelope):
    """Urgency Detector, section 4 / A2.

    The output surface is deliberately a level, matched phrases and a flag, and
    nothing else. Section 4 / A2: "Remove any field that could be rendered to a
    customer, so a UI bug cannot leak a care instruction." extra="forbid" on
    Envelope is what enforces that against model drift.
    """

    level: UrgencyLevel
    matched_signals: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _immediate_escalates(self) -> A2Output:
        if self.level == UrgencyLevel.IMMEDIATE and not self.escalate:
            raise ValueError("level=immediate must set escalate=true")
        return self


# A phone message listing more than this stops being readable, whatever the
# tenant configures.
MAX_SLOT_OPTIONS_ABSOLUTE = 8


class SlotOption(BaseModel):
    model_config = ConfigDict(extra="forbid")
    slot_id: str = Field(min_length=1)
    starts_at: datetime
    resource_id: str
    resource_name: str
    duration_minutes: int = Field(gt=0)


class A3Output(Envelope):
    """Slot Proposer, section 4 / A3."""

    options: list[SlotOption] = Field(default_factory=list)
    unavailable_note: str | None = None

    @model_validator(mode="after")
    def _option_discipline(self) -> A3Output:
        # Section 4 / A3 says three. That is the DEFAULT, enforced per tenant
        # by the runtime (apply_option_ceiling below), the same way the
        # escalation threshold is. The schema keeps an absolute ceiling so a
        # misconfigured tenant cannot produce an unreadable message, and so a
        # model that ignores its instruction still fails validation.
        if len(self.options) > MAX_SLOT_OPTIONS_ABSOLUTE:
            raise ValueError(
                f"A3 may offer at most {MAX_SLOT_OPTIONS_ABSOLUTE} options"
            )
        # "If availability is empty for the window, return zero options and set
        # escalate = true, reason = missing_fact."
        if not self.options and not self.escalate:
            raise ValueError("zero options must set escalate=true")
        # Two options on identical timestamps are not a choice.
        starts = [o.starts_at for o in self.options]
        if len(set(starts)) != len(starts):
            raise ValueError("options must be at distinct times")
        return self


class ReminderStage(StrEnum):
    T_24H = "T-24h"
    T_2H = "T-2h"
    NO_SHOW_RECOVERY = "no_show_recovery"


class Channel(StrEnum):
    WHATSAPP = "whatsapp"
    SMS = "sms"
    EMAIL = "email"


class A5Output(Envelope):
    """Reminder Composer, section 4 / A5."""

    draft: str = Field(min_length=1)
    language: Language
    channel_preference: Channel


class A4Output(Envelope):
    """Reply Copilot, section 4 / A4.

    `draft` is the only field a customer ever sees, and the runtime finds it
    via getattr(envelope, "draft") -- which is how the guard pass and the
    review gate know this agent is customer-facing at all.
    """

    draft: str = Field(min_length=1)
    language: Language
    intent_handled: Intent
    facts_used: list[Evidence] = Field(default_factory=list)
    missing: list[str] = Field(default_factory=list)
    auto_send_eligible: bool = False

    @model_validator(mode="after")
    def _missing_fact_discipline(self) -> A4Output:
        # Section 4 / A4: "If a fact is missing, do not improvise around it.
        # Write the reply without it, set escalate = true, reason =
        # missing_fact, and name the gap in missing." Encoded so a prompt
        # regression cannot quietly drop the escalation and keep the gap.
        if self.missing and not self.escalate:
            raise ValueError("missing is non-empty but escalate is false")
        if self.missing and self.auto_send_eligible:
            raise ValueError("a draft with a named gap is never auto-send eligible")
        return self


class Sentiment(StrEnum):
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    NEGATIVE = "negative"
    UNKNOWN = "unknown"


class A6Output(Envelope):
    """Review Requester, section 4 / A6.

    Section 4 calls this "the most dangerous agent in this archetype" and says
    that without sentiment gating, do not ship it at all. The gate is therefore
    enforced here as well as in the prompt: a regression that loses it fails
    validation instead of manufacturing a one-star review.
    """

    sentiment: Sentiment
    ask: bool
    route_to_owner: bool = False
    draft: str | None = None
    owner_note: str | None = None

    @model_validator(mode="after")
    def _sentiment_gate(self) -> A6Output:
        if self.sentiment is Sentiment.NEGATIVE:
            if self.ask:
                raise ValueError("a negative thread must never be asked for a review")
            if self.draft:
                raise ValueError(
                    "a negative thread must produce NO customer-facing draft; "
                    "summarise for the owner in owner_note instead"
                )
            if not self.route_to_owner:
                raise ValueError("a negative thread must set route_to_owner=true")
        if self.sentiment is Sentiment.UNKNOWN:
            if self.ask:
                raise ValueError("unknown sentiment must not ask")
            if not self.escalate:
                raise ValueError("unknown sentiment must set escalate=true")
        if self.ask and not self.draft:
            raise ValueError("ask=true requires a draft")
        if not self.ask and self.draft:
            raise ValueError("ask=false must not carry a customer-facing draft")
        return self


class SuppressReason(StrEnum):
    OPT_OUT = "opt_out"
    TOO_RECENT = "too_recent"
    DORMANT = "dormant"
    NO_RULE = "no_rule"


class A7Output(Envelope):
    """Recurrence & Reactivation, section 4 / A7."""

    due: bool
    service_id: str | None = None
    days_since: int = Field(ge=0)
    draft: str | None = None
    suppress_reason: SuppressReason | None = None

    @model_validator(mode="after")
    def _nudge_discipline(self) -> A7Output:
        if self.due and not self.draft:
            raise ValueError("due=true requires a draft")
        if not self.due:
            if self.draft:
                raise ValueError("due=false must not carry a customer-facing draft")
            if self.suppress_reason is None:
                raise ValueError("due=false requires a suppress_reason")
        return self


class DigestAction(BaseModel):
    model_config = ConfigDict(extra="forbid")
    action: str = Field(min_length=1)
    # Section 4 / A8: every action is "tied to a specific number above". A
    # suggestion with no metric behind it is advice, and this agent does not
    # give advice.
    because_of: str = Field(min_length=1)


class HeadlineMetric(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1)
    value: float | int | str


class A8Output(Envelope):
    """Analyst, section 4 / A8."""

    digest: str = Field(min_length=1)
    headline_metric: HeadlineMetric
    actions: list[DigestAction] = Field(default_factory=list, max_length=2)
    not_measured: list[str] = Field(default_factory=list)


class GuardVerdict(StrEnum):
    PASS = "pass"
    REJECT = "reject"


class GuardViolation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    rule: str
    quote: str


class GuardOutput(BaseModel):
    """Section 2.4. Not an Envelope -- the guard is a release gate, not an agent,
    and it never escalates: it votes pass or reject."""

    model_config = ConfigDict(extra="forbid")
    verdict: GuardVerdict
    violations: list[GuardViolation] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)
