"""Tenant configuration -- the whole onboarding form from spec section 10.

No prompt is ever edited per client. Only these values change.
"""
from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, field_validator


class Archetype(StrEnum):
    SLOT_SERVICE = "A"
    ENROLLMENT_FUNNEL = "B"
    CONSULTATION_GATE = "C"
    INVENTORY_MATCH = "D"
    CATALOGUE_RFQ = "E"


class CapacityModel(StrEnum):
    RESOURCE_SLOT = "resource_slot"
    BATCH_SEAT = "batch_seat"
    DATE = "date"
    LISTING = "listing"
    MOQ = "moq"


# Section 10. business_type -> (archetype, entity, capacity model, default red lines).
# Restaurant is present but deliberately unbuildable; section 9 defers it.
BUSINESS_TYPES: dict[str, dict] = {
    "dentist": {"archetype": "A", "entity": "patient", "capacity": "resource_slot",
                "red_lines": ["no_clinical_advice", "no_diagnosis"]},
    "clinic": {"archetype": "A", "entity": "patient", "capacity": "resource_slot",
               "red_lines": ["no_symptom_triage", "no_care_instruction"]},
    "salon": {"archetype": "A", "entity": "customer", "capacity": "resource_slot",
              "red_lines": ["no_price_exception", "no_result_promise"]},
    "auto_garage": {"archetype": "A", "entity": "vehicle", "capacity": "resource_slot",
                    "red_lines": ["no_repair_cost_estimate", "no_safety_assurance"]},
    "gym": {"archetype": "B", "entity": "prospect", "capacity": "batch_seat",
            "red_lines": ["no_training_prescription", "no_diet_prescription",
                          "no_body_outcome_claim"]},
    "tuition_center": {"archetype": "B", "entity": "parent_student", "capacity": "batch_seat",
                       "red_lines": ["no_result_promise", "no_fee_negotiation"]},
    "ca_accountant": {"archetype": "C", "entity": "matter", "capacity": "resource_slot",
                      "red_lines": ["no_tax_position"]},
    "lawyer": {"archetype": "C", "entity": "matter", "capacity": "resource_slot",
               "red_lines": ["no_legal_opinion", "no_outcome_assessment"]},
    "real_estate_broker": {"archetype": "D", "entity": "requirement", "capacity": "listing",
                           "red_lines": ["no_unpublished_price", "no_title_or_approval_claim"]},
    "wedding_vendor": {"archetype": "D", "entity": "event", "capacity": "date",
                       "red_lines": ["no_package_quote", "no_date_held_claim"]},
    "textile_wholesaler": {"archetype": "E", "entity": "rfq", "capacity": "moq",
                           "red_lines": ["no_price", "no_lead_time_commitment"]},
    "manufacturer": {"archetype": "E", "entity": "rfq", "capacity": "moq",
                     "red_lines": ["no_price", "no_territory_crossing"]},
    "diamond": {"archetype": "E", "entity": "stone", "capacity": "moq",
                "red_lines": ["no_grade_without_cert", "no_origin_claim",
                              "no_investment_language"]},
    # Court hire is resource_slot, the same shape as a dental chair. Open-play
    # sessions are batch_seat and belong to Archetype B, which is unbuilt --
    # so this entry covers court hire only, and a tenant that lives on
    # organised sessions is not yet servable.
    "pickleball": {"archetype": "A", "entity": "booking", "capacity": "resource_slot",
                   "red_lines": ["no_injury_advice", "no_coaching_promise"]},
    "restaurant": {"archetype": "A", "entity": "booking", "capacity": "resource_slot",
                   "red_lines": ["no_allergen_guidance"], "deferred": True},
}

LANGUAGES = {"gu", "gu-Latn", "hi", "hi-Latn", "en"}


class TenantConfig(BaseModel):
    """Validated form of the config keys in section 10."""

    model_config = ConfigDict(extra="forbid")

    tenant_id: str = Field(min_length=1)
    tenant_name: str = Field(min_length=1)
    archetype: Archetype
    business_type: str
    city: str = "Surat"
    languages: list[str] = Field(min_length=1)
    timezone: str = "Asia/Kolkata"
    entity_type: str
    capacity_model: CapacityModel
    red_lines: list[str] = Field(default_factory=list)
    auto_send_whitelist: list[str] = Field(default_factory=list)
    escalation_threshold: float = Field(default=0.75, ge=0.0, le=1.0)
    agents_enabled: list[str] = Field(default_factory=list)

    # Section 10: "The two caps are not optional."  Hence no defaults that could
    # be read as unlimited, and a hard floor below which configuration is a typo.
    daily_token_cap_inr: int = Field(ge=1)
    daily_message_cap: int = Field(ge=1)
    kill_switch: bool = False

    # Section 4 / A2: "{{urgency_keywords}} tenant-configured terms, in all
    # three languages". Tenant-specific because "urgent" in a salon and
    # "urgent" in a clinic are not the same claim.
    urgency_keywords: list[str] = Field(default_factory=list)

    # Where an A2 `immediate` alert goes. Staff-facing, so it bypasses the guard
    # pass and does not count against the customer message cap. An empty list
    # means the alert is recorded but nobody is paged, which is a configuration
    # error worth catching in onboarding rather than at 11pm.
    staff_alert_channel: str = "whatsapp"
    staff_alert_targets: list[str] = Field(default_factory=list)

    # Section 4 / A4: price_enquiry widens "only once the owner confirms the
    # catalogue is current". A date rather than a boolean, because the answer
    # goes stale and "confirmed in March" is useful information in October.
    catalogue_confirmed_at: str | None = None

    # Per-tenant presentation. CONFIGURATION, not generated code.
    #
    # One runtime serves all fourteen business types (section 0), and that
    # holds for the interface too: the owner dashboard renders these values,
    # it is not rebuilt per client. A per-tenant generated frontend would be
    # fourteen codebases to review, patch and keep accessible, which is the
    # cost the config-driven design exists to avoid.
    brand_primary: str = "#1f6f4a"
    brand_accent: str = "#8a5a00"
    brand_display_name: str | None = None
    brand_tagline: str | None = None
    brand_entity_plural: str | None = None   # "patients", "players", "members"
    review_link: str | None = None

    # The service a booking takes when the customer did not name one.
    #
    # This is the tenant's STATED POLICY, not an inference. "Unspecified
    # bookings are consultations" is how a clinic actually works, and
    # svc_consult is in its own catalogue; guessing "cleaning" from a message
    # that mentions no service would be the inference, and that is what the
    # confirmation path still refuses.
    #
    # Null means "do not assume" -- a confirmation with no identified service
    # then falls through to a person. Leave it null where the business has
    # several materially different first appointments and getting it wrong
    # matters.
    default_service_id: str | None = None

    # Section 4 / A3: "Never offer more than 3 options. Choice paralysis costs
    # bookings." Three is the default and the spec's reasoning holds for a
    # clinic, where availability is genuinely scarce and a choice of three is a
    # real choice.
    #
    # It does not hold everywhere. A courts venue with 144 open hours this week
    # offering three of them reads as "almost nothing is free", which is the
    # opposite of true and loses the booking for the opposite reason. So the
    # ceiling is per tenant, capped at 8 because a WhatsApp message listing
    # more than that stops being readable on a phone.
    max_slot_options: int = Field(default=3, ge=1, le=8)

    # When true, A4 may add one line summarising the availability NOT listed
    # ("plus 20 more times this week"), computed by the runtime. A count is a
    # fact; "lots of availability" is not.
    availability_summary: bool = False

    recall_rules: dict[str, object] = Field(default_factory=dict)
    freshness_policy_days: int | None = None
    secure_upload_url: str | None = None
    guard_pass_required_for: list[str] = Field(default_factory=lambda: ["all_customer_facing"])

    @field_validator("languages")
    @classmethod
    def _known_languages(cls, v: list[str]) -> list[str]:
        unknown = set(v) - LANGUAGES
        if unknown:
            raise ValueError(f"unknown language codes: {sorted(unknown)}")
        return v

    @field_validator("business_type")
    @classmethod
    def _known_business_type(cls, v: str) -> str:
        if v not in BUSINESS_TYPES:
            raise ValueError(f"unknown business_type: {v}")
        if BUSINESS_TYPES[v].get("deferred"):
            raise ValueError(
                f"business_type '{v}' is deferred (spec section 9) and not in pilot scope"
            )
        return v

    def guard_required(self, customer_facing: bool) -> bool:
        if "none" in self.guard_pass_required_for:
            return False
        if "all_customer_facing" in self.guard_pass_required_for:
            return customer_facing
        return True

    def auto_send_allowed(self, intent: str) -> bool:
        return intent in self.auto_send_whitelist
