"""The output envelope from spec section 2.2.

Every agent output embeds this. The runtime validates against it, rejects on
failure, retries once with the error appended, and escalates on second failure.
"""
from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, model_validator


class EscalationReason(StrEnum):
    """Exactly the enum in section 2.2. Do not extend this to describe runtime
    failures -- those are recorded separately as RuntimeStop.kind, because an
    agent's reason for escalating and the runtime's reason for stopping are
    different facts and conflating them makes the escalation-reason distribution
    in section 1.4 useless."""

    MISSING_FACT = "missing_fact"
    AMBIGUOUS_REQUEST = "ambiguous_request"
    OUT_OF_SCOPE = "out_of_scope"
    POLICY_BOUNDARY = "policy_boundary"
    SENTIMENT_RISK = "sentiment_risk"
    INSTRUCTION_IN_USER_CONTENT = "instruction_in_user_content"
    LOW_CONFIDENCE = "low_confidence"
    HIGH_VALUE = "high_value"
    UNKNOWN_ENTITY = "unknown_entity"


class Evidence(BaseModel):
    """Provenance for one factual claim. Section 2.2: for every factual claim,
    the tool call or context field it came from."""

    model_config = ConfigDict(extra="forbid")

    claim: str = Field(min_length=1)
    source: str = Field(min_length=1, description="tool call ref or context field name")


class Envelope(BaseModel):
    """Base class for every agent output contract.

    extra="forbid" is deliberate. A model that invents an extra field is a model
    drifting from its contract, and we want that to fail loudly in eval rather
    than pass silently into production where a UI might render it.
    """

    model_config = ConfigDict(extra="forbid")

    confidence: float = Field(ge=0.0, le=1.0)
    escalate: bool
    reason: EscalationReason | None = None
    evidence: list[Evidence] = Field(default_factory=list)

    @model_validator(mode="after")
    def _reason_required_when_escalating(self) -> Envelope:
        if self.escalate and self.reason is None:
            raise ValueError("reason is required when escalate is true")
        if not self.escalate and self.reason is not None:
            raise ValueError("reason must be null when escalate is false")
        return self


def apply_option_ceiling(env: Envelope, ceiling: int) -> Envelope:
    """Trim an A3 output to the tenant's configured option count.

    Enforced in the runtime rather than trusted to the prompt, for the same
    reason the escalation threshold is: the prompt asks, the runtime decides.
    Trimming keeps the first N, which A3 has already been told to spread across
    days -- so the survivors are still a spread rather than a morning's worth.
    """
    options = getattr(env, "options", None)
    if options is None or len(options) <= ceiling:
        return env
    return env.model_copy(update={"options": options[:ceiling]})


def apply_threshold(env: Envelope, threshold: float) -> Envelope:
    """Section 2.2: set escalate = true whenever confidence < escalation_threshold.

    Enforced in the runtime rather than trusted to the prompt. The model is asked
    to do this itself as well; belt and braces, because this is the single control
    that turns a low-confidence answer into a human decision.
    """
    if env.confidence < threshold and not env.escalate:
        return env.model_copy(
            update={"escalate": True, "reason": EscalationReason.LOW_CONFIDENCE}
        )
    return env
