"""Normalised inbound event. Every channel in section 1.1 collapses to this."""
from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class Channel(StrEnum):
    WHATSAPP = "whatsapp"
    WEB_FORM = "web_form"
    INSTAGRAM = "instagram"
    MISSED_CALL = "missed_call"
    CRON = "cron"
    STAFF_ENTRY = "staff_entry"


class InboundEvent(BaseModel):
    """What the webhook layer produces and the pipeline consumes.

    external_id is the channel's own message id where one exists. When it does
    not (web forms, missed calls), dedupe falls back to a content hash inside a
    time window -- see validate.py.
    """

    model_config = ConfigDict(extra="forbid")

    tenant_id: str
    channel: Channel
    external_id: str | None = None
    sender_ref: str = Field(min_length=1, description="phone, handle or form session")
    sender_name: str | None = None
    body: str = ""
    media_refs: list[str] = Field(default_factory=list)
    received_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    raw: dict = Field(default_factory=dict)

    def content_hash(self) -> str:
        """Stable hash of the parts a duplicate would share."""
        material = "|".join(
            [self.tenant_id, self.channel, self.sender_ref, self.body, *sorted(self.media_refs)]
        )
        return hashlib.sha256(material.encode("utf-8")).hexdigest()

    def dedupe_key(self) -> str:
        if self.external_id:
            return f"{self.channel}:{self.external_id}"
        return f"{self.channel}:hash:{self.content_hash()}"
