"""Staff console API. The approval queue plus the observability of section 1.4.

This is the surface the PWA talks to. Keeping it this thin is deliberate: the
console can be rebuilt, replaced by a WhatsApp approval flow, or wrapped in a
native app without any of the runtime changing.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import desc, func, select
from sqlalchemy.orm import Session

from app.api.deps import get_session, require_console_key
from app.db import TenantScope
from app.models import AgentRun, Decision
from app.runtime import audit, autosend, review
from app.runtime.caps import CapGuard
from app.runtime.validate import load_tenant_config

router = APIRouter(prefix="/console", tags=["console"],
                   dependencies=[Depends(require_console_key)])


class QueueItem(BaseModel):
    decision_id: int
    kind: str
    intent: str | None
    draft: str | None
    escalation_reason: str | None
    runtime_stop: str | None
    guard_verdict: str | None
    created_at: str


class ApprovePayload(BaseModel):
    approver: str
    sent_text: str | None = None


class RejectPayload(BaseModel):
    approver: str
    note: str = ""


@router.get("/{tenant_id}/queue", response_model=list[QueueItem])
def queue_list(tenant_id: str, limit: int = 50, session: Session = Depends(get_session)):
    scope = TenantScope(session, tenant_id)
    rows = session.execute(
        scope.query(Decision).where(Decision.outcome == "open")
        .order_by(desc(Decision.created_at)).limit(limit)
    ).scalars().all()
    return [
        QueueItem(
            decision_id=r.id, kind=r.kind, intent=r.intent, draft=r.draft,
            escalation_reason=r.escalation_reason, runtime_stop=r.runtime_stop,
            guard_verdict=r.guard_verdict, created_at=r.created_at.isoformat(),
        )
        for r in rows
    ]


@router.post("/{tenant_id}/decisions/{decision_id}/approve")
def approve(tenant_id: str, decision_id: int, body: ApprovePayload,
            session: Session = Depends(get_session)):
    scope = TenantScope(session, tenant_id)
    try:
        row = review.approve(scope, decision_id, approver=body.approver,
                             sent_text=body.sent_text)
    except (KeyError, ValueError) as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    return {"decision_id": row.id, "outcome": row.outcome,
            "edit_distance_pct": row.edit_distance_pct}


@router.post("/{tenant_id}/decisions/{decision_id}/reject")
def reject(tenant_id: str, decision_id: int, body: RejectPayload,
           session: Session = Depends(get_session)):
    scope = TenantScope(session, tenant_id)
    try:
        row = review.reject(scope, decision_id, approver=body.approver, note=body.note)
    except KeyError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc)) from exc
    return {"decision_id": row.id, "outcome": row.outcome}


@router.get("/{tenant_id}/autosend-readiness")
def autosend_readiness(tenant_id: str, session: Session = Depends(get_session)):
    """Section 4 / A4's "Condition to widen", as evidence rather than a feeling.

    Shows, per intent: what the tenant currently auto-sends, what the policy
    requires, and how far off the approval rate is. Widening the whitelist
    should be a decision someone defends with this screen open.
    """
    cfg = load_tenant_config(session, tenant_id)
    rows = []
    for intent in sorted(autosend.POLICY):
        approved = session.execute(
            select(func.count()).where(
                Decision.tenant_id == tenant_id, Decision.intent == intent,
                Decision.outcome == "approved", Decision.approver != "auto_send_whitelist")
        ).scalar_one()
        resolved = session.execute(
            select(func.count()).where(
                Decision.tenant_id == tenant_id, Decision.intent == intent,
                Decision.outcome.in_(["approved", "rejected"]),
                Decision.approver != "auto_send_whitelist")
        ).scalar_one()
        r = autosend.readiness(
            intent, approved=approved, resolved=resolved,
            catalogue_confirmed=bool(cfg.catalogue_confirmed_at),
        )
        rows.append({
            "intent": intent,
            "currently_auto_sent": intent in cfg.auto_send_whitelist,
            "eligible_to_widen": r.eligible,
            "reason": r.reason,
            "approval_rate": round(r.approval_rate, 3) if r.approval_rate else None,
            "drafts_reviewed": r.drafts,
            "drafts_still_needed": r.needed_drafts,
        })
    return {"tenant_id": tenant_id, "intents": rows}


@router.get("/{tenant_id}/metrics")
def metrics(tenant_id: str, session: Session = Depends(get_session)):
    """The five numbers section 1.4 says you need from day one."""
    scope = TenantScope(session, tenant_id)
    cfg = load_tenant_config(session, tenant_id)

    by_kind = dict(
        session.execute(
            select(Decision.kind, func.count())
            .where(Decision.tenant_id == tenant_id).group_by(Decision.kind)
        ).all()
    )
    approved = session.execute(
        select(func.count()).where(Decision.tenant_id == tenant_id,
                                   Decision.outcome == "approved")
    ).scalar_one()
    resolved = session.execute(
        select(func.count()).where(Decision.tenant_id == tenant_id,
                                   Decision.outcome.in_(["approved", "rejected"]))
    ).scalar_one()
    # Section 11.2 gates "median < 15% of characters". The mean is the wrong
    # statistic here and flatters the agent: one draft rewritten from scratch
    # among twenty light edits barely moves a median and drags a mean upward,
    # while twenty rewrites and one clean draft do the reverse. SQLite has no
    # percentile function, so it is computed in Python over a column that is
    # one row per reviewed draft.
    edits = sorted(
        session.execute(
            select(Decision.edit_distance_pct)
            .where(Decision.tenant_id == tenant_id,
                   Decision.edit_distance_pct.isnot(None))
        ).scalars().all()
    )
    median_edit = None
    if edits:
        mid = len(edits) // 2
        median_edit = (edits[mid] if len(edits) % 2
                       else (edits[mid - 1] + edits[mid]) / 2)
    escalation_reasons = dict(
        session.execute(
            select(Decision.escalation_reason, func.count())
            .where(Decision.tenant_id == tenant_id, Decision.escalation_reason.isnot(None))
            .group_by(Decision.escalation_reason)
        ).all()
    )
    schema_rejects = session.execute(
        select(func.count()).where(AgentRun.tenant_id == tenant_id, AgentRun.valid.is_(False))
    ).scalar_one()

    # Guard observability. Section 2.4 calls the guard the highest-value piece
    # of the safety story; a safety control whose rate nobody can see is not a
    # control. A rising blocked_rate is either a prompt regression upstream or
    # a guard getting stricter, and the rule histogram says which.
    guard_counts = dict(
        session.execute(
            select(Decision.guard_verdict, func.count())
            .where(Decision.tenant_id == tenant_id, Decision.guard_verdict.isnot(None))
            .group_by(Decision.guard_verdict)
        ).all()
    )
    guarded = sum(guard_counts.values())
    rules: dict[str, int] = {}
    for (payload,) in session.execute(
        select(Decision.guard_violations)
        .where(Decision.tenant_id == tenant_id, Decision.guard_violations.isnot(None))
    ).all():
        for v in (payload or {}).get("violations", []):
            name = v.get("rule", "unknown")
            rules[name] = rules.get(name, 0) + 1

    ok, broken_at = audit.verify_chain(scope)
    return {
        "decisions_by_kind": by_kind,
        "approval_rate": round(approved / resolved, 3) if resolved else None,
        "median_edit_distance_pct": round(median_edit, 2)
        if median_edit is not None else None,
        "edit_distance_gate_ok": (median_edit < 15.0) if median_edit is not None else None,
        "escalation_reasons": escalation_reasons,
        "schema_rejects": schema_rejects,
        "usage": CapGuard(scope, cfg).snapshot(),
        "guard": {
            "drafts_guarded": guarded,
            "blocked_rate": round(guard_counts.get("reject", 0) / guarded, 3)
            if guarded else None,
            "violations_by_rule": rules,
        },
        "audit_chain_intact": ok,
        "audit_chain_broken_at": broken_at,
    }
