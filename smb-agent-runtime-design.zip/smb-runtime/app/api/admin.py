"""Tenant administration. Onboarding a client is filling in section 10's form."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import get_session, require_admin_key
from app.db import TenantScope
from app.models import Tenant
from app.runtime import audit
from app.schemas.tenant import BUSINESS_TYPES, TenantConfig

router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(require_admin_key)])


class KillSwitchPayload(BaseModel):
    engaged: bool
    actor: str
    note: str = ""


@router.get("/business-types")
def business_types():
    """The archetype map of section 3, as data. Drives the onboarding form."""
    return BUSINESS_TYPES


class TenantCreate(BaseModel):
    """The section 10 form, plus the operational context the read tools serve.

    Kept as two fields because they have different owners and different review
    cadences: `config` is the agent-layer contract and changes rarely; `context`
    is the clinic's own catalogue and FAQ and changes whenever they do.
    """

    config: TenantConfig
    context: dict = {}


@router.post("/tenants", status_code=status.HTTP_201_CREATED)
def create_tenant(body: TenantCreate, session: Session = Depends(get_session)):
    cfg = body.config
    if session.get(Tenant, cfg.tenant_id):
        raise HTTPException(status.HTTP_409_CONFLICT, "tenant already exists")
    row = Tenant(
        id=cfg.tenant_id, name=cfg.tenant_name, business_type=cfg.business_type,
        archetype=cfg.archetype.value,
        config={**cfg.model_dump(mode="json"), **body.context},
        kill_switch=cfg.kill_switch,
    )
    session.add(row)
    session.flush()
    audit.record(TenantScope(session, cfg.tenant_id), actor="admin", action="tenant_created",
                 subject_type="tenant", subject_id=cfg.tenant_id,
                 data={"business_type": cfg.business_type, "archetype": cfg.archetype.value,
                       "agents_enabled": cfg.agents_enabled})
    return {"tenant_id": row.id, "archetype": row.archetype}


@router.get("/tenants/{tenant_id}")
def get_tenant(tenant_id: str, session: Session = Depends(get_session)):
    row = session.get(Tenant, tenant_id)
    if not row:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "unknown tenant")
    return {"tenant_id": row.id, "config": row.config, "kill_switch": row.kill_switch}


@router.post("/tenants/{tenant_id}/kill-switch")
def kill_switch(tenant_id: str, body: KillSwitchPayload,
                session: Session = Depends(get_session)):
    """Section 1.3: instant kill switch. One call, no deploy, audited."""
    row = session.get(Tenant, tenant_id)
    if not row:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "unknown tenant")
    row.kill_switch = body.engaged
    cfg = dict(row.config or {})
    cfg["kill_switch"] = body.engaged
    row.config = cfg
    session.flush()
    audit.record(TenantScope(session, tenant_id), actor=body.actor, action="kill_switch",
                 subject_type="tenant", subject_id=tenant_id,
                 data={"engaged": body.engaged, "note": body.note})
    return {"tenant_id": tenant_id, "kill_switch": body.engaged}
