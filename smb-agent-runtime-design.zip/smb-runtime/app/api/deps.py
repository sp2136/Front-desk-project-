from __future__ import annotations

from collections.abc import Iterator

from fastapi import Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

from app.config import settings
from app.db import SessionLocal, TenantScope


def get_session() -> Iterator[Session]:
    s = SessionLocal()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def require_console_key(x_api_key: str = Header(default="")) -> None:
    if x_api_key != settings.console_api_key:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid console key")


def require_admin_key(x_api_key: str = Header(default="")) -> None:
    if x_api_key != settings.admin_api_key:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid admin key")


def scope_for(tenant_id: str, session: Session = Depends(get_session)) -> TenantScope:
    return TenantScope(session, tenant_id)
