"""Inbound channel webhooks. The EVENT column of section 1.1.

These endpoints do exactly three things: normalise, persist with dedupe, and
enqueue. No model call happens in the request path -- the webhook must return
fast enough that WhatsApp does not retry, and a slow model call is precisely
how you get duplicate deliveries.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import get_session
from app.db import TenantScope
from app.runtime import audit, confirm, queue
from app.runtime.errors import DuplicateEvent, RateLimited
from app.runtime.validate import enforce_rate_limit, load_tenant_config, persist_event
from app.schemas.events import Channel, InboundEvent

router = APIRouter(prefix="/webhooks", tags=["webhooks"])

# Which agent an inbound event wakes. Section 4: A1 is the head of the chain.
ENTRY_AGENT = {"A": "A1", "B": "B1", "C": "C1", "D": "D1", "E": "E1"}


class IngestResponse(BaseModel):
    accepted: bool
    event_id: int | None = None
    job_id: int | None = None
    reason: str | None = None


@router.post("/{tenant_id}/{channel}", response_model=IngestResponse)
def ingest(tenant_id: str, channel: Channel, payload: dict,
           session: Session = Depends(get_session)) -> IngestResponse:
    scope = TenantScope(session, tenant_id)
    try:
        cfg = load_tenant_config(session, tenant_id)
    except KeyError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "unknown tenant") from exc

    event = InboundEvent(
        tenant_id=tenant_id,
        channel=channel,
        external_id=payload.get("external_id"),
        sender_ref=payload.get("sender_ref") or payload.get("from") or "unknown",
        sender_name=payload.get("sender_name"),
        body=payload.get("body", ""),
        media_refs=payload.get("media_refs", []),
        raw=payload,
    )

    try:
        enforce_rate_limit(scope, event.sender_ref)
    except RateLimited as exc:
        audit.record(scope, actor="runtime", action="rate_limited", subject_type="sender",
                     subject_id=event.sender_ref, data={"channel": channel})
        return IngestResponse(accepted=False, reason=str(exc))

    try:
        row = persist_event(scope, event)
    except DuplicateEvent as exc:
        return IngestResponse(accepted=False, reason=str(exc))

    # Before waking the agent chain: is this simply the customer accepting one
    # of the slots we already offered them? That is application code matching
    # strings, not a model, and it closes the booking with nobody from the
    # business involved. Section 4 / A3's "app takes a soft lock with TTL, then
    # commits on confirmation" is this, and routing it through A1-A4 again
    # would mean a person clicking to confirm what the customer already chose.
    booking, match = confirm.try_confirm(
        scope, customer_ref=event.sender_ref, body=event.body,
        customer_name=event.sender_name,
    )
    if booking is not None:
        audit.record(scope, actor="app", action="confirmed_without_staff",
                     subject_type="booking", subject_id=booking.id,
                     data={"matched_on": match.reason})
        return IngestResponse(accepted=True, event_id=row.id,
                              reason=f"booked #{booking.id} ({match.reason})")

    agent_id = ENTRY_AGENT[cfg.archetype.value]
    job = queue.enqueue(
        scope,
        agent_id=agent_id,
        dedupe_key=event.dedupe_key(),
        event_id=row.id,
        payload={"event": event.model_dump(mode="json")},
    )
    audit.record(scope, actor="runtime", action="event_received", subject_type="inbound_event",
                 subject_id=row.id,
                 data={"channel": channel, "agent_id": agent_id,
                       "job_id": job.id if job else None})
    return IngestResponse(accepted=True, event_id=row.id, job_id=job.id if job else None)
