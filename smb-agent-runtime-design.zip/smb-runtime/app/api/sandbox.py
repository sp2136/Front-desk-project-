"""A sandbox UI so the product can be experienced, not just tested.

Mounted ONLY when SANDBOX=1. These endpoints have no authentication, show one
hard-coded tenant and expose a reset button, which is exactly right for a demo
on a laptop and exactly wrong anywhere else. Gating it on an env flag rather
than trusting a deployment checklist is the difference between a demo and an
open console.

What it shows: the patient's phone and the front desk side by side, so cause
and effect are visible in one screen. A customer message goes in on the left,
the chain runs, and whatever comes out lands in the queue on the right -- where
a human has to approve it before the patient ever sees it.
"""
from __future__ import annotations

import json
import pathlib
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy import desc, func, select
from sqlalchemy.orm import Session

from app.api.deps import get_session
from app.db import TenantScope
from app.models import (
    AuditLog,
    Booking,
    Decision,
    InboundEventRow,
    OutboundMessage,
    Reminder,
    Tenant,
)
from app.runtime import autosend, queue, review
from app.runtime.caps import CapGuard
from app.runtime.errors import DuplicateEvent, RateLimited
from app.runtime.validate import enforce_rate_limit, load_tenant_config, persist_event
from app.schemas.events import Channel, InboundEvent

router = APIRouter(prefix="/sandbox", tags=["sandbox"])

TENANT_ID = "t_smile_dental"
CUSTOMER = "+919812345678"
ROOT = pathlib.Path(__file__).resolve().parents[2]
PAGE = pathlib.Path(__file__).resolve().parent / "sandbox.html"


class MessageIn(BaseModel):
    body: str


class ApproveIn(BaseModel):
    text: str | None = None
    approver: str = "front_desk"


def _seed_tenant(session: Session, cfg_name: str, ctx_name: str) -> None:
    cfg = json.loads((ROOT / "seeds" / cfg_name).read_text())
    if session.get(Tenant, cfg["tenant_id"]) is not None:
        return
    ctx = {k: v for k, v in
           json.loads((ROOT / "seeds" / ctx_name).read_text()).items()
           if not k.startswith("_")}
    session.add(Tenant(
        id=cfg["tenant_id"], name=cfg["tenant_name"],
        business_type=cfg["business_type"], archetype=cfg["archetype"],
        config={**cfg, **ctx},
    ))
    session.commit()


def _ensure_tenant(session: Session) -> None:
    """Create the demo tenants and the clinic's slots on first load.

    Two tenants, not one, so /ops shows a fleet rather than a row -- and so the
    brand config is visibly doing something on /owner. They differ only in
    configuration: same runtime, same prompts, same code.
    """
    _seed_tenant(session, "tenant_dentist.json", "tenant_dentist_context.json")
    _seed_tenant(session, "tenant_pickleball.json", "tenant_pickleball_context.json")
    from app.models import Slot
    if session.execute(select(func.count()).select_from(Slot)).scalar_one() == 0:
        from scripts.seed_slots import seed
        seed(TENANT_ID, days=8)


@router.get("", response_class=HTMLResponse)
@router.get("/", response_class=HTMLResponse)
def page(session: Session = Depends(get_session)) -> HTMLResponse:
    _ensure_tenant(session)
    return HTMLResponse(PAGE.read_text(encoding="utf-8"))


@router.post("/api/message")
def send_message(body: MessageIn, session: Session = Depends(get_session)):
    """The patient sends a WhatsApp message. Same path as the real webhook."""
    _ensure_tenant(session)
    scope = TenantScope(session, TENANT_ID)
    cfg = load_tenant_config(session, TENANT_ID)

    event = InboundEvent(
        tenant_id=TENANT_ID, channel=Channel.WHATSAPP,
        external_id=f"sandbox-{datetime.now().timestamp()}",
        sender_ref=CUSTOMER, body=body.body.strip(),
    )
    try:
        enforce_rate_limit(scope, CUSTOMER)
    except RateLimited as exc:
        return {"accepted": False, "reason": str(exc)}
    try:
        row = persist_event(scope, event)
    except DuplicateEvent as exc:
        return {"accepted": False, "reason": str(exc)}

    # Same deterministic confirmation check as the real webhook.
    from app.runtime import confirm

    booking, match = confirm.try_confirm(
        scope, customer_ref=CUSTOMER, body=event.body, customer_name="Mehul",
        language="gu-Latn",
    )
    if booking is not None:
        when = booking.starts_at.astimezone(
            __import__("zoneinfo").ZoneInfo(cfg.timezone)
        ).strftime("%a %-d %b, %-I:%M %p")
        decision = scope.add(Decision(
            kind=review.DecisionKind.AUTO_SEND, intent="book",
            draft=f"Booked for {when}. See you then.",
            a2_level="routine", outcome="open",
        ))
        scope.flush()
        msg = review.enqueue_outbound(
            scope, CapGuard(scope, cfg), decision, channel="whatsapp", to_ref=CUSTOMER
        )
        msg.state = "sent"
        msg.sent_at = datetime.now(booking.starts_at.tzinfo)
        session.commit()
        return {"accepted": True, "event_id": row.id,
                "booked": booking.id, "reason": match.reason}

    from app.api.webhooks import ENTRY_AGENT
    job = queue.enqueue(
        scope, agent_id=ENTRY_AGENT[cfg.archetype.value],
        dedupe_key=event.dedupe_key(), event_id=row.id,
        payload={"event": event.model_dump(mode="json")},
    )
    return {"accepted": True, "event_id": row.id, "job_id": job.id if job else None}


@router.get("/api/state")
def state(session: Session = Depends(get_session)):
    """Everything both panes need, in one poll."""
    from app.db import schema_drift

    drift = schema_drift()
    if drift:
        # Named explicitly, because a 500 here renders as two empty panes and
        # sends you looking at the JavaScript.
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            "The database is behind the code (" + "; ".join(drift[:3])
            + "). Restart with: python scripts/sandbox.py --fresh",
        )
    _ensure_tenant(session)
    scope = TenantScope(session, TENANT_ID)
    cfg = load_tenant_config(session, TENANT_ID)

    inbound = [
        {"direction": "in", "body": e.body, "at": e.received_at.isoformat()}
        for e in scope.all(InboundEventRow)
    ]
    outbound = [
        {"direction": "out", "body": m.body, "at": (m.sent_at or m.created_at).isoformat()}
        for m in scope.all(OutboundMessage)
        if m.channel == "whatsapp" and m.to_ref == CUSTOMER
    ]
    thread = sorted(inbound + outbound, key=lambda m: m["at"])

    open_rows = session.execute(
        scope.query(Decision).where(Decision.outcome == "open")
        .order_by(desc(Decision.id)).limit(30)
    ).scalars().all()
    queue_items = [
        {
            "id": d.id, "kind": d.kind, "intent": d.intent, "draft": d.draft,
            "a2_level": d.a2_level, "guard_verdict": d.guard_verdict,
            "guard_violations": [
                v["rule"] for v in (d.guard_violations or {}).get("violations", [])
            ],
            "escalation_reason": d.escalation_reason, "runtime_stop": d.runtime_stop,
            "created_at": d.created_at.isoformat(),
        }
        for d in open_rows
    ]

    alerts = [
        {"to": m.to_ref, "body": m.body, "at": m.created_at.isoformat()}
        for m in scope.all(OutboundMessage) if m.to_ref != CUSTOMER
    ]
    bookings = [
        {"id": b.id, "service": b.service_id, "resource": b.resource_id,
         "starts_at": b.starts_at.isoformat(), "visit": b.visit_count}
        for b in scope.all(Booking)
    ]
    reminders = [
        {"booking_id": r.booking_id, "stage": r.stage,
         "due_at": r.due_at.isoformat(), "state": r.state}
        for r in scope.all(Reminder)
    ]

    resolved = session.execute(
        select(func.count()).where(Decision.tenant_id == TENANT_ID,
                                   Decision.outcome.in_(["approved", "rejected"]))
    ).scalar_one()
    approved = session.execute(
        select(func.count()).where(Decision.tenant_id == TENANT_ID,
                                   Decision.outcome == "approved")
    ).scalar_one()
    edits = sorted(session.execute(
        select(Decision.edit_distance_pct).where(
            Decision.tenant_id == TENANT_ID, Decision.edit_distance_pct.isnot(None))
    ).scalars().all())
    median_edit = None
    if edits:
        mid = len(edits) // 2
        median_edit = edits[mid] if len(edits) % 2 else (edits[mid - 1] + edits[mid]) / 2

    readiness = [
        {"intent": i, "auto": i in cfg.auto_send_whitelist,
         "eligible": r.eligible, "reason": r.reason}
        for i in ("location_hours", "service_enquiry", "book", "price_enquiry", "complaint")
        for r in [autosend.readiness(i, approved=approved, resolved=resolved)]
    ]

    return {
        "tenant": {"name": cfg.tenant_name, "city": cfg.city,
                   "languages": cfg.languages, "red_lines": cfg.red_lines,
                   "whitelist": cfg.auto_send_whitelist,
                   "agents": cfg.agents_enabled},
        "thread": thread,
        "queue": queue_items,
        "alerts": alerts,
        "bookings": bookings,
        "reminders": reminders,
        "metrics": {
            "approval_rate": round(approved / resolved, 3) if resolved else None,
            "median_edit_distance_pct": median_edit,
            "resolved": resolved,
            "usage": CapGuard(scope, cfg).snapshot(),
            "audit_rows": session.execute(
                select(func.count()).where(AuditLog.tenant_id == TENANT_ID)
            ).scalar_one(),
        },
        "readiness": readiness,
    }


@router.post("/api/decisions/{decision_id}/approve")
def approve(decision_id: int, body: ApproveIn, session: Session = Depends(get_session)):
    """Approve and deliver. The ONLY route by which a draft reaches the patient."""
    scope = TenantScope(session, TENANT_ID)
    cfg = load_tenant_config(session, TENANT_ID)
    try:
        row = review.approve(scope, decision_id, approver=body.approver,
                             sent_text=body.text)
        msg = review.enqueue_outbound(
            scope, CapGuard(scope, cfg), row, channel="whatsapp", to_ref=CUSTOMER
        )
    except (KeyError, ValueError) as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc

    # A real deployment hands this to the messaging provider. The sandbox marks
    # it delivered so the patient's phone updates.
    msg.state = "sent"
    msg.sent_at = datetime.now(row.approved_at.tzinfo)
    session.commit()
    return {"decision_id": row.id, "edit_distance_pct": row.edit_distance_pct}


@router.post("/api/decisions/{decision_id}/reject")
def reject(decision_id: int, body: ApproveIn, session: Session = Depends(get_session)):
    scope = TenantScope(session, TENANT_ID)
    try:
        row = review.reject(scope, decision_id, approver=body.approver)
    except KeyError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc)) from exc
    return {"decision_id": row.id, "outcome": row.outcome}


@router.post("/api/book")
def book_slot(session: Session = Depends(get_session)):
    """Simulate the patient tapping a confirm link on the first open option.

    This is the application write path, not an agent: soft lock, then commit.
    """
    from app.runtime import reminders as rem
    from app.runtime.booking import (
        SlotUnavailable,
        acquire_soft_lock,
        available_slots,
        commit_booking,
    )

    scope = TenantScope(session, TENANT_ID)
    open_slots = available_slots(scope, service_id="svc_cleaning", limit=1)
    if not open_slots:
        raise HTTPException(status.HTTP_409_CONFLICT, "nothing open")
    try:
        lock = acquire_soft_lock(scope, open_slots[0].id, ttl_s=600)
        booking = commit_booking(scope, lock, customer_ref=CUSTOMER,
                                 service_id="svc_cleaning", customer_name="Mehul",
                                 language="gu-Latn")
        rem.schedule_for_booking(scope, booking)
    except SlotUnavailable as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    session.commit()
    return {"booking_id": booking.id, "starts_at": booking.starts_at.isoformat()}


@router.post("/api/reminders/fire")
def fire_reminders(session: Session = Depends(get_session)):
    """Pull the next reminder forward so A5 can be watched without waiting a day."""
    scope = TenantScope(session, TENANT_ID)
    rows = [r for r in scope.all(Reminder) if r.state == "scheduled"]
    if not rows:
        raise HTTPException(status.HTTP_409_CONFLICT, "no scheduled reminders")
    rows.sort(key=lambda r: r.due_at)
    rows[0].due_at = datetime.now(rows[0].due_at.tzinfo) - timedelta(minutes=1)
    session.commit()
    from app.workers.runner import tick_reminders
    return {"queued": tick_reminders("sandbox"), "stage": rows[0].stage}


@router.post("/api/reset")
def reset(session: Session = Depends(get_session)):
    """Wipe this tenant's activity, keeping the tenant and its calendar."""
    from app.models import AgentRun, Job, Slot, ToolCall
    scope = TenantScope(session, TENANT_ID)
    for model in (OutboundMessage, Decision, ToolCall, AgentRun, Job,
                  InboundEventRow, Reminder, Booking, AuditLog):
        for row in scope.all(model):
            session.delete(row)
    for slot in scope.all(Slot):
        slot.booking_id = None
        slot.lock_token = None
        slot.lock_expires_at = None
    session.commit()
    return {"reset": True}
