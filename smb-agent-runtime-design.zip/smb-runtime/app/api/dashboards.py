"""Two dashboards, for two different readers.

  /ops    The platform operator. Every tenant at once, agent health, spend,
          schema validity, queue depth, prompt versions. The question it
          answers is "is the fleet behaving, and which tenant is not".

  /owner  One business owner. Their enquiries, bookings, no-shows, what is
          waiting on their staff. No prompt versions, no token counts, no
          schema validity -- an owner neither knows nor should care what a
          schema rejection is.

Kept as separate pages deliberately. The temptation is one dashboard with a
role filter, and it always produces a page that serves whoever it was last
designed for. The two readers want different nouns: the operator thinks in
agents and tenants, the owner thinks in patients and Thursdays.

Both are read-only. Neither needs the guard, neither writes, and nothing here
is reachable by an agent.
"""
from __future__ import annotations

import pathlib
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import HTMLResponse, Response
from sqlalchemy import desc, func, select
from sqlalchemy.orm import Session

from app.api.deps import get_session
from app.config import settings
from app.db import TenantScope
from app.models import (
    AgentRun,
    AuditLog,
    Booking,
    Customer,
    Decision,
    Job,
    OutboundMessage,
    Reminder,
    Tenant,
)
from app.runtime import agents as agent_registry
from app.runtime import autosend, metrics
from app.runtime.caps import CapGuard
from app.runtime.prompts import store as prompt_store
from app.runtime.validate import load_tenant_config

router = APIRouter(prefix="", tags=["dashboards"])
HERE = pathlib.Path(__file__).resolve().parent


def _now() -> datetime:
    return datetime.now(tz=None).astimezone()


# ---------------------------------------------------------------------------
# Operator dashboard
# ---------------------------------------------------------------------------


@router.get("/surat-smb.css")
def stylesheet() -> Response:
    """The Surat SMB design system, shared by every page."""
    return Response(
        (HERE / "surat-smb.css").read_text(encoding="utf-8"),
        media_type="text/css",
        headers={"Cache-Control": "no-cache"},
    )


@router.get("/", response_class=HTMLResponse)
def index_page() -> HTMLResponse:
    """A landing page, so the three views are discoverable from one URL."""
    return HTMLResponse((HERE / "index.html").read_text(encoding="utf-8"))


@router.get("/ops", response_class=HTMLResponse)
def ops_page() -> HTMLResponse:
    return HTMLResponse((HERE / "ops.html").read_text(encoding="utf-8"))


@router.get("/api/ops/overview")
def ops_overview(session: Session = Depends(get_session)):
    now = _now()
    week = metrics.Window("7d", now - timedelta(days=7), now)

    tenants = session.execute(select(Tenant)).scalars().all()
    rows = []
    for t in tenants:
        cfg = load_tenant_config(session, t.id)
        scope = TenantScope(session, t.id)
        m = metrics.window_metrics(session, t.id, week)
        exc = metrics.exceptions_for(session, t.id)
        snap = CapGuard(scope, cfg).snapshot()
        chain_ok, broken_at = True, None
        try:
            from app.runtime import audit
            chain_ok, broken_at = audit.verify_chain(scope)
        except Exception:  # noqa: BLE001 - a dashboard must not fail on one tenant
            chain_ok, broken_at = False, None
        rows.append({
            "tenant_id": t.id,
            "name": t.name,
            "business_type": t.business_type,
            "archetype": t.archetype,
            "kill_switch": t.kill_switch,
            "agents_enabled": cfg.agents_enabled,
            "whitelist": cfg.auto_send_whitelist,
            "enquiries_7d": m["enquiries"],
            "drafts_7d": m["drafts_produced"],
            "approval_rate": m["approval_rate"],
            "median_edit_pct": m["median_edit_distance_pct"],
            "schema_validity": m["schema_validity"],
            "blocked_by_guard": m["blocked_by_guard"],
            "median_latency_ms": m["median_latency_ms"],
            "spend_inr": snap["spend_inr"],
            "cap_inr": snap["token_cap_inr"],
            "pct_of_cap": snap["pct_of_token_cap"],
            "disabled_reason": snap["disabled_reason"],
            "open_items": exc["escalations_not_cleared"],
            "dead_jobs": exc["jobs_abandoned"],
            "audit_chain_intact": chain_ok,
            "audit_chain_broken_at": broken_at,
        })

    # Per-agent health across the whole fleet. This is the view that answers
    # "did the last prompt change make things worse", which is the question
    # section 1.4 exists to make answerable.
    agent_rows = []
    for agent_id, spec in sorted(agent_registry.REGISTRY.items()):
        runs = session.execute(
            select(func.count()).select_from(AgentRun).where(
                AgentRun.agent_id == agent_id, AgentRun.created_at >= week.start)
        ).scalar_one()
        invalid = session.execute(
            select(func.count()).select_from(AgentRun).where(
                AgentRun.agent_id == agent_id, AgentRun.valid.is_(False),
                AgentRun.created_at >= week.start)
        ).scalar_one()
        lat = sorted(session.execute(
            select(AgentRun.latency_ms).where(
                AgentRun.agent_id == agent_id, AgentRun.valid.is_(True),
                AgentRun.created_at >= week.start)
        ).scalars().all())
        over = sum(1 for x in lat if x > spec.latency_budget_ms)
        versions = sorted({
            f"{r.prompt_version}@{r.prompt_sha256[:8]}" for r in session.execute(
                select(AgentRun).where(AgentRun.agent_id == agent_id).limit(200)
            ).scalars().all()
        })
        agent_rows.append({
            "agent_id": agent_id,
            "job": spec.job,
            "stage": spec.stage,
            "customer_facing": spec.customer_facing,
            "prompt_version": prompt_store._bodies.get(agent_id, ("—", "", False))[0],
            "has_body": prompt_store.has_body(agent_id),
            "runs_7d": runs,
            "schema_rejects_7d": invalid,
            "schema_validity": round(1 - invalid / runs, 3) if runs else None,
            "latency_budget_ms": spec.latency_budget_ms,
            "median_latency_ms": (lat[len(lat) // 2] if lat else None),
            "over_budget_7d": over,
            "versions_seen": versions,
        })

    queue_depth = dict(session.execute(
        select(Job.state, func.count()).group_by(Job.state)
    ).all())

    return {
        "generated_at": now.isoformat(),
        "provider": settings.llm_provider,
        "global_kill_switch": settings.global_kill_switch,
        "tenants": rows,
        "agents": agent_rows,
        "queue_depth": queue_depth,
        "fleet": {
            "tenants": len(rows),
            "enquiries_7d": sum(r["enquiries_7d"] for r in rows),
            "drafts_7d": sum(r["drafts_7d"] for r in rows),
            "spend_inr_today": round(sum(r["spend_inr"] for r in rows), 2),
            "open_items": sum(r["open_items"] for r in rows),
            "dead_jobs": sum(r["dead_jobs"] for r in rows),
            "tenants_disabled": sum(1 for r in rows if r["disabled_reason"]),
            "chains_broken": sum(1 for r in rows if not r["audit_chain_intact"]),
        },
    }


# ---------------------------------------------------------------------------
# Owner dashboard
# ---------------------------------------------------------------------------


@router.get("/owner", response_class=HTMLResponse)
@router.get("/owner/{tenant_id}", response_class=HTMLResponse)
def owner_page(tenant_id: str | None = None) -> HTMLResponse:
    return HTMLResponse((HERE / "owner.html").read_text(encoding="utf-8"))


@router.get("/api/owner/tenants")
def owner_tenants(session: Session = Depends(get_session)):
    return [
        {"tenant_id": t.id, "name": t.name, "business_type": t.business_type}
        for t in session.execute(select(Tenant)).scalars().all()
    ]


@router.get("/api/owner/{tenant_id}")
def owner_overview(tenant_id: str, session: Session = Depends(get_session)):
    tenant = session.get(Tenant, tenant_id)
    if tenant is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "unknown tenant")

    cfg = load_tenant_config(session, tenant_id)
    scope = TenantScope(session, tenant_id)
    now = _now()
    this_week = metrics.Window("this week", now - timedelta(days=7), now)
    last_week = metrics.Window("last week", now - timedelta(days=14), now - timedelta(days=7))
    cur = metrics.window_metrics(session, tenant_id, this_week)
    prev = metrics.window_metrics(session, tenant_id, last_week)
    exc = metrics.exceptions_for(session, tenant_id)

    waiting = session.execute(
        scope.query(Decision).where(Decision.outcome == "open")
        .order_by(desc(Decision.id)).limit(20)
    ).scalars().all()

    upcoming = sorted(
        [b for b in scope.all(Booking) if b.state == "confirmed" and b.starts_at >= now],
        key=lambda b: b.starts_at,
    )[:12]

    digest = session.execute(
        scope.query(AgentRun).where(AgentRun.agent_id == "A8", AgentRun.valid.is_(True))
        .order_by(desc(AgentRun.id)).limit(1)
    ).scalars().first()

    entity = cfg.brand_entity_plural or f"{cfg.entity_type}s"
    return {
        "brand": {
            "name": cfg.brand_display_name or cfg.tenant_name,
            "tagline": cfg.brand_tagline,
            "primary": cfg.brand_primary,
            "accent": cfg.brand_accent,
            "entity_plural": entity,
            "city": cfg.city,
            "business_type": cfg.business_type,
        },
        "headline": {
            "waiting_on_you": exc["escalations_not_cleared"],
            "enquiries_this_week": cur["enquiries"],
            "bookings_this_week": cur["bookings_made"],
            "no_shows_this_week": cur["no_shows"],
        },
        "compare": [
            {"name": "Enquiries", "now": cur["enquiries"], "then": prev["enquiries"]},
            {"name": "Bookings", "now": cur["bookings_made"], "then": prev["bookings_made"]},
            {"name": "Replies sent", "now": cur["messages_sent"],
             "then": prev["messages_sent"]},
            {"name": "No-shows", "now": cur["no_shows"], "then": prev["no_shows"],
             "lower_is_better": True},
        ],
        "leaks": {k: v for k, v in exc.items() if v},
        "waiting": [
            {"id": d.id, "kind": d.kind, "intent": d.intent, "draft": d.draft,
             "why": d.escalation_reason or d.runtime_stop or d.guard_verdict,
             "created_at": d.created_at.isoformat()}
            for d in waiting
        ],
        "upcoming": [
            {"id": b.id, "service": b.service_id, "with": b.resource_id,
             "when": b.starts_at.isoformat(), "who": b.customer_name,
             "visit": b.visit_count}
            for b in upcoming
        ],
        "reminders": [
            {"booking_id": r.booking_id, "stage": r.stage, "due_at": r.due_at.isoformat(),
             "state": r.state}
            for r in sorted(scope.all(Reminder), key=lambda r: r.due_at)[:12]
        ],
        "customers": {
            "total": len(scope.all(Customer)),
            "opted_out": sum(1 for c in scope.all(Customer) if c.opt_out),
            "dormant": sum(1 for c in scope.all(Customer) if c.dormant),
        },
        "digest": digest.parsed_output if digest else None,
        "automation": [
            {"intent": i, "auto": i in cfg.auto_send_whitelist,
             "eligible": r.eligible, "reason": r.reason}
            for i in ("location_hours", "service_enquiry", "book", "price_enquiry",
                      "complaint")
            for r in [autosend.readiness(
                i,
                approved=session.execute(
                    select(func.count()).where(
                        Decision.tenant_id == tenant_id, Decision.intent == i,
                        Decision.outcome == "approved")).scalar_one(),
                resolved=session.execute(
                    select(func.count()).where(
                        Decision.tenant_id == tenant_id, Decision.intent == i,
                        Decision.outcome.in_(["approved", "rejected"]))).scalar_one(),
                catalogue_confirmed=bool(cfg.catalogue_confirmed_at))]
        ],
        "trust": {
            "nothing_auto_sent": not cfg.auto_send_whitelist,
            "audit_rows": session.execute(
                select(func.count()).where(AuditLog.tenant_id == tenant_id)).scalar_one(),
            "messages_sent_total": session.execute(
                select(func.count()).where(
                    OutboundMessage.tenant_id == tenant_id)).scalar_one(),
        },
    }
