# Eval case files

Section 11: *"A prompt without an eval set is a guess you cannot defend."*

```bash
python -m app.eval.cli --agent A1    --cases evals/a1_cases.jsonl    --provider anthropic
python -m app.eval.cli --agent A2    --cases evals/a2_cases.jsonl    --provider anthropic
python -m app.eval.cli --agent A4    --cases evals/a4_cases.jsonl    --provider anthropic
python -m app.eval.cli --agent GUARD --cases evals/guard_cases.jsonl --provider anthropic
python -m app.eval.cli --freeze evals/a1_cases.jsonl        # record the hash
```

Exits non-zero when the gates block, so it drops straight into CI.

## What is here, and what is deliberately missing

**Here:** every red-team case from §11.3, encoded verbatim. These do not depend
on anyone's real traffic — they are the same for any Archetype A tenant, and
they are the cases that must pass before a launch.

**Missing, and it must stay missing until you supply it:** the real-traffic
half. §11.1 is specific:

> Export the last 100–200 real inbound messages from the pilot tenant, with the
> response the human actually gave. Hand-label the correct output for 40 of
> them. This is a day of work and it is the most valuable day you will spend on
> the agent layer. Include at least 10 cases in Roman-script Gujarati or mixed
> script, and at least 5 voice-note transcriptions, because that is what the
> traffic actually looks like.

The handful of cases marked `"source": "synthetic"` are smoke tests for the
harness. **They are not an eval set.** They were written by the same kind of
system being tested, which means they encode its assumptions about what a Surat
dental enquiry looks like, and an agent scoring 100% against them has
demonstrated nothing except internal consistency. Passing the gates on
synthetic cases alone is the failure mode §11 exists to prevent.

Concretely: `intent_accuracy` and `language_match` computed over invented
messages are not evidence. Treat a green report as "the plumbing works" until
the real-traffic cases land.

## a4_cases.jsonl

A4 cases carry a `facts` block — the approved facts the draft is allowed to be
built from. That is deliberate: an A4 eval tests how the agent *uses* a known
fact set, not how well the FAQ retriever found one. Retrieval quality is a
separate problem and mixing them makes a red result ambiguous.

Two expectations exist only here. `max_draft_words` enforces §4/A4's hard
ceiling of 80 — a 200-word reply is not a style problem, it is a draft the
front desk will rewrite, and rewriting is the one thing A4 is measured on.
`require_missing` enforces the missing-fact discipline: when the needed fact is
absent, the draft must name the gap rather than work around it.

`edit_distance` is reported as `not_measured` in every A4 eval and always will
be. It compares a draft to what a human actually sent, and there is no human in
an eval run. Read it from `/console/{tenant}/metrics` in production. Do not
read a green A4 eval as evidence that staff accept the drafts.

## guard_cases.jsonl

Different shape, because the guard is not an agent: a case is a **draft** plus
the **source facts** it should have been built from, and the label is simply
whether the draft must be blocked.

The file needs both polarities. Fifteen must-reject cases alone would be passed
perfectly by a guard that blocks everything, so the five must-pass cases are
what make `false_reject_rate` measurable. Do not delete them to make a report
look better.

When A4 lands at Stage 3, add its real rejected drafts here. Drafts a model
actually produced and a human actually blocked are worth more than any number
of invented ones, for the same reason real inbound traffic beats synthetic.

## Freezing

> Freeze it. A case file that changes with every prompt edit measures nothing.

Every report carries the file's sha256. When it changes, you changed the ruler,
and the comparison to last week's number is void. Record the hash in the commit
that freezes it:

| file | frozen sha256 | date | cases |
|---|---|---|---|
| a1_cases.jsonl | _run `--freeze` and record here_ | | |
| a2_cases.jsonl | _run `--freeze` and record here_ | | |
| a4_cases.jsonl | _run `--freeze` and record here_ | | |
| guard_cases.jsonl | _run `--freeze` and record here_ | | |
