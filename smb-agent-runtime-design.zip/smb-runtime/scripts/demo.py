"""End-to-end walkthrough of the runtime with no API key required.

Proves, in order:
  1. Onboarding a tenant is filling in the section 10 form.
  2. An inbound WhatsApp message is ingested once; the retry is deduped.
  3. With LLM_PROVIDER=null the pipeline stops cleanly and the customer who did
     not get an answer is visible, not silently dropped.
  4. The A1 -> A2 chain runs and records everything section 1.4 asks for.
  5. An urgent message pre-empts the chain and pages staff -- with no care
     instruction anywhere in the alert.
  6. Caps, kill switch and the audit chain behave.

    python scripts/demo.py
"""
from __future__ import annotations

import json
import os
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
os.environ.setdefault("DATABASE_URL", "sqlite:///./demo.db")

from app.db import SessionLocal, TenantScope, engine, init_db  # noqa: E402
from app.models import (  # noqa: E402
    AgentRun,
    AuditLog,
    Base,
    Decision,
    Job,
    OutboundMessage,
    Tenant,
)
from app.runtime import audit, queue, tool_impls  # noqa: F401,E402
from app.runtime.caps import CapGuard  # noqa: E402
from app.runtime.llm import EchoProvider, NullProvider  # noqa: E402
from app.runtime.pipeline import Pipeline  # noqa: E402
from app.runtime.prompts import store, sync_to_db  # noqa: E402
from app.runtime.tools import build_toolbelt, registry  # noqa: E402
from app.runtime.validate import load_tenant_config, persist_event  # noqa: E402
from app.schemas.events import Channel, InboundEvent  # noqa: E402
from app.schemas.tenant import TenantConfig  # noqa: E402
from app.workers.runner import run_once  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parents[1]


def a1_out(**kw) -> str:
    base = {"intent": "book", "service_id": "svc_cleaning", "service_guess": None,
            "raw_complaint_text": None, "language": "gu-Latn",
            "customer": {"known": False, "id": None, "name": None},
            "time_window": {"earliest": None, "latest": None, "preferred_days": [],
                            "part_of_day": "evening"},
            "blockers": [], "confidence": 0.91, "escalate": False, "reason": None,
            "evidence": [{"claim": "cleaning is an approved service",
                          "source": "get_service_catalogue#1"}]}
    base.update(kw)
    return json.dumps(base)


def a2_out(level: str, signals: list[str], **kw) -> str:
    base = {"level": level, "matched_signals": signals, "confidence": 0.93,
            "escalate": level == "immediate",
            "reason": "policy_boundary" if level == "immediate" else None,
            "evidence": []}
    base.update(kw)
    return json.dumps(base)


def hr(title: str) -> None:
    print(f"\n{'=' * 72}\n{title}\n{'=' * 72}")


def ingest(scope, session, body: str, external_id: str, agent: str = "A1"):
    event = InboundEvent(tenant_id=scope.tenant_id, channel=Channel.WHATSAPP,
                         external_id=external_id, sender_ref="+919812345678", body=body)
    row = persist_event(scope, event)
    job = queue.enqueue(scope, agent_id=agent, dedupe_key=event.dedupe_key(),
                        event_id=row.id, payload={"event": event.model_dump(mode="json")})
    session.commit()
    return event, row, job


def main() -> None:
    Base.metadata.drop_all(engine)
    init_db()
    session = SessionLocal()
    print("synced prompts:", ", ".join(sync_to_db(session)) or "none")
    session.commit()

    # ------------------------------------------------------------------ 1
    hr("1. Onboard a tenant -- section 10's form, nothing else")
    cfg = TenantConfig(**json.loads((ROOT / "seeds" / "tenant_dentist.json").read_text()))
    ctx = {k: v for k, v in
           json.loads((ROOT / "seeds" / "tenant_dentist_context.json").read_text()).items()
           if not k.startswith("_")}
    session.add(Tenant(id=cfg.tenant_id, name=cfg.tenant_name,
                       business_type=cfg.business_type, archetype=cfg.archetype.value,
                       config={**cfg.model_dump(mode="json"), **ctx}))
    session.commit()
    scope = TenantScope(session, cfg.tenant_id)
    print(f"   {cfg.tenant_name}  archetype={cfg.archetype.value}  "
          f"entity={cfg.entity_type}  capacity={cfg.capacity_model.value}")
    print(f"   red lines: {cfg.red_lines}")
    print(f"   agents enabled: {cfg.agents_enabled}")
    print(f"   auto-send whitelist at launch: {cfg.auto_send_whitelist}")
    print(f"   caps: INR {cfg.daily_token_cap_inr}/day, {cfg.daily_message_cap} msgs/day")
    a1 = store.assemble("A1", {"tenant_name": cfg.tenant_name,
                               "business_type": cfg.business_type, "city": cfg.city,
                               "today": "2026-10-10", "languages": json.dumps(cfg.languages),
                               "escalation_threshold": cfg.escalation_threshold,
                               "event": "<event>", "history": "<history>"})
    print(f"   A1 prompt {a1.version}@{a1.sha256[:12]}  ({len(a1.text)} chars, "
          f"unresolved={list(a1.unresolved)})")

    # ------------------------------------------------------------------ 2
    hr("2. Inbound WhatsApp, Roman-script Gujarati -- ingest once, dedupe the retry")
    event, row, job = ingest(scope, session, "kaal aavi sakay? saanje 6 vagya pachi",
                             "wamid.HBgM")
    print(f"   accepted  event_id={row.id}  dedupe_key={row.dedupe_key}")
    try:
        persist_event(scope, event)
    except Exception as exc:
        print(f"   retry rejected by the database constraint: {type(exc).__name__}")
    print(f"   queued job {job.id} -> A1  ({job.idempotency_key})")

    # ------------------------------------------------------------------ 3
    hr("3. LLM_PROVIDER=null -- the runtime runs, nothing is invented")
    stopped = Pipeline(NullProvider()).run(scope, job)
    session.commit()
    queue.complete(session, job.id, "stopped", stopped.detail)
    print(f"   stopped: {stopped.stopped}")
    print(f"   open decision {stopped.decision.id} records the unanswered customer")

    # ------------------------------------------------------------------ 4
    hr("4. The A1 -> A2 chain on a routine booking enquiry")
    ingest(scope, session, "kaal aavi sakay? saanje 6 vagya pachi mate", "wamid.ROUTINE")
    pipeline = Pipeline(EchoProvider(script=[a1_out(), a2_out("routine", [])]))
    while run_once("demo-worker", pipeline):
        pass

    s2 = SessionLocal()
    sc2 = TenantScope(s2, cfg.tenant_id)
    for run in sorted((r for r in sc2.all(AgentRun) if r.valid), key=lambda r: r.id):
        print(f"   {run.agent_id} attempt {run.attempt}  valid={run.valid}  "
              f"prompt={run.prompt_version}@{run.prompt_sha256[:8]}  "
              f"tools={run.toolbelt_version[:8]}  tok={run.input_tokens}/{run.output_tokens}")
    print("   jobs:", {j.agent_id: j.state for j in sc2.all(Job)})
    print("   A2 returned routine -> next step is A3 Slot Proposer, which is stage 4")

    # ------------------------------------------------------------------ 5
    hr("5. An urgent message -- A2 pre-empts the chain and pages staff")
    ingest(sc2, s2, "bahu dukhe che, turat joie che", "wamid.URGENT")
    urgent = Pipeline(EchoProvider(script=[
        a1_out(intent="service_enquiry", service_id=None,
               service_guess="bahu dukhe che", confidence=0.84),
        a2_out("immediate", ["bahu dukhe che", "turat"]),
    ]))
    while run_once("demo-worker", urgent):
        pass

    s3 = SessionLocal()
    sc3 = TenantScope(s3, cfg.tenant_id)
    alerts = [m for m in sc3.all(OutboundMessage)]
    print(f"   staff alerts queued: {len(alerts)} -> {[m.to_ref for m in alerts]}")
    if alerts:
        print("   alert body:")
        for line in alerts[0].body.splitlines():
            print(f"     | {line}")
    print("   no customer-facing draft exists for this thread, by design")

    # ------------------------------------------------------------------ 6
    hr("6. Caps, audit chain, tool layer")
    guard = CapGuard(sc3, load_tenant_config(s3, cfg.tenant_id))
    snap = guard.snapshot()
    print(f"   spend today: INR {snap['spend_inr']} of {snap['token_cap_inr']} "
          f"({snap['pct_of_token_cap']}% of cap)")
    print(f"   customer messages sent: {snap['messages_sent']} of {snap['message_cap']} "
          "(staff alerts do not count)")
    ok, broken = audit.verify_chain(sc3)
    print(f"   audit chain: {len(sc3.all(AuditLog))} rows, intact={ok}, broken_at={broken}")
    print(f"   decisions: {[(d.kind, d.outcome) for d in sc3.all(Decision)]}")
    reads = [n for n in registry.names() if n not in registry.write_tools()]
    print(f"   read tools available to agents: {reads}")
    try:
        build_toolbelt(["commit_booking"], sc3)
    except Exception as exc:
        print(f"   write tool refused structurally: {type(exc).__name__}")

    # ------------------------------------------------------------------ 7
    hr("7. The guard pass -- stage 2, sitting in front of any future send")
    from app.runtime.guard import run_guard
    from app.runtime.sourcefacts import SourceFacts

    facts = SourceFacts().add("service_catalogue", [
        {"id": "svc_cleaning", "name": "Scaling and polishing",
         "duration_min": 45, "published_price": 1500, "price_qualifier": "starting from"},
    ])
    print("   source facts: the catalogue row the runtime actually retrieved")
    print("                 (not the agent's own evidence array -- that is circular)")
    for label, draft in (
        ("sourced  ", "Scaling starts from 1500 and takes 45 minutes. Friday suit you?"),
        ("invented ", "Scaling is 2500 rupees and we can finish in 20 minutes."),
        ("advice   ", "Rinse with warm salt water tonight, then come tomorrow."),
        ("gu-Latn  ", "Kal saanje aavi sakay chho. Kayo time faavse?"),
    ):
        # No model attached, so the model layer fails closed. Only the rule
        # layer can PASS here -- which is itself the behaviour to notice.
        out = run_guard(NullProvider(), draft, facts, cfg.red_lines, cfg.languages)
        rules = ",".join(v.rule for v in out.violations) or "-"
        print(f"   {label} {out.verdict.value:<7} {rules}")
    print("   note: 'advice' and 'gu-Latn' both read as guard_unavailable, not pass.")
    print("         With no model the gate fails closed -- 2.4: reject when uncertain.")

    # ------------------------------------------------------------------ 8
    hr("8. A4 Reply Copilot -- stage 3, human-approve only")
    from app.runtime import autosend
    from app.runtime.review import approve

    guard_pass = json.dumps({"verdict": "pass", "violations": [], "confidence": 0.9})

    def a4_out(draft: str, intent: str, **kw) -> str:
        base = {"draft": draft, "language": "en", "intent_handled": intent,
                "facts_used": [], "missing": [], "auto_send_eligible": True,
                "confidence": 0.92, "escalate": False, "reason": None, "evidence": []}
        base.update(kw)
        return json.dumps(base)

    # 8a. A draft that states hours the tenant never published.
    ingest(sc3, s3, "what time do you open tomorrow?", "wamid.HOURS")
    # Built once, outside the loop: a provider constructed inside the while
    # condition would be rebuilt every iteration and replay its script from
    # the start, handing A4 the response written for A1.
    p8a = Pipeline(EchoProvider(script=[
        a1_out(intent="location_hours", service_id=None, confidence=0.93),
        a4_out("We are open 10:00 to 19:00 tomorrow. Shall I find you a time?",
               "location_hours"),
        guard_pass,
    ]))
    while run_once("demo-worker", p8a):
        pass

    # 8b. A draft that stays inside what was actually retrieved.
    ingest(sc3, s3, "do you have parking outside?", "wamid.PARK")
    p8b = Pipeline(EchoProvider(script=[
        a1_out(intent="service_enquiry", service_id=None, confidence=0.9),
        a2_out("routine", []),
        a4_out("Happy to help. Could you tell me which day you are coming in?",
               "service_enquiry"),
        guard_pass,
    ]))
    while run_once("demo-worker", p8b):
        pass

    s4 = SessionLocal()
    sc4 = TenantScope(s4, cfg.tenant_id)
    drafted = sorted([d for d in sc4.all(Decision) if d.draft], key=lambda d: d.id)
    for d in drafted:
        print(f"   decision {d.id}  {d.kind}/{d.outcome}  guard={d.guard_verdict}  "
              f"a2={d.a2_level}")
        print(f"     {d.draft}")
        for v in (d.guard_violations or {}).get("violations", []):
            print(f"     -> {v['rule']}: {v['quote']}")

    print()
    print("   The first draft was BLOCKED. The seed policy block has no opening")
    print("   hours -- every value in it is still PLACEHOLDER -- so 10:00 and 19:00")
    print("   came from nowhere and the rule layer caught them. That is what the")
    print("   unfilled seed costs you, surfaced before a customer sees it.")
    print()
    print("   The second stayed inside the facts it was given, so it reached the")
    print("   staff queue. The whitelist is empty at stage 3, so even a clean")
    print("   guarded draft waits for a person -- section 12: human-approve only.")

    queued = [d for d in drafted if d.kind == "queued_for_human"]
    if queued:
        row = approve(sc4, queued[0].id, approver="front_desk_01",
                      sent_text="Happy to help! Which day are you coming in?")
        s4.commit()
        print(f"\n   approved with an edit -> edit distance {row.edit_distance_pct}%")
        print("   (section 1.4: the real measure of whether a copilot helps)")

    print()
    print("   auto-send readiness -- section 4 / A4's 'condition to widen':")
    for intent in ("location_hours", "service_enquiry", "book", "price_enquiry",
                   "complaint"):
        r = autosend.readiness(intent, approved=0, resolved=0)
        label = "eligible" if r.eligible else "blocked "
        print(f"     {intent:<16} {label}  {r.reason}")
    s4.close()

    # ------------------------------------------------------------------ 9
    hr("9. A3 Slot Proposer + the booking write path -- stage 4")
    from app.runtime import reminders
    from app.runtime.booking import (
        SlotUnavailable,
        acquire_soft_lock,
        available_slots,
        commit_booking,
    )
    from scripts.seed_slots import seed

    made = seed(cfg.tenant_id, days=6)
    print(f"   seeded {made} open slots across 2 resources")

    s5 = SessionLocal()
    sc5 = TenantScope(s5, cfg.tenant_id)
    open_now = available_slots(sc5, service_id="svc_cleaning", limit=3)
    print("   get_availability -- the only source of truth A3 may read:")
    for sl in open_now:
        print(f"     {sl.id.split(':')[0]:<8} {sl.starts_at.isoformat()}  {sl.duration_min}m")

    print()
    print("   Two customers want the same slot. Section 1.3: they must collide")
    print("   at the database, not in a prompt.")
    target = open_now[0].id
    lock = acquire_soft_lock(sc5, target, ttl_s=600)
    s5.commit()
    print(f"     customer A -> lock acquired, expires {lock.expires_at.isoformat()}")
    try:
        acquire_soft_lock(sc5, target, ttl_s=600)
    except SlotUnavailable as exc:
        print(f"     customer B -> refused: {exc}")
    print(f"     slot still offered by get_availability? "
          f"{target in {x.id for x in available_slots(sc5)}}")

    booking = commit_booking(sc5, lock, customer_ref="+919812345678",
                             service_id="svc_cleaning",
                             customer_name="Mehul", language="gu-Latn")
    s5.commit()
    print(f"     customer A confirmed -> booking {booking.id}, "
          f"visit #{booking.visit_count}")

    created = reminders.schedule_for_booking(sc5, booking)
    s5.commit()
    print()
    print("   Reminder schedule is deterministic and lives in the app "
          "(section 4 / A5):")
    for r in created:
        print(f"     {r.stage:<8} due {r.due_at.isoformat()}")
    print(f"     due right now: {len(reminders.due_reminders(sc5))} "
          "(nothing yet -- the appointment is days away)")
    print("     A5 only writes the text; it cannot send early, twice, or to")
    print("     someone who cancelled, because it decides none of those.")
    s5.close()

    for s in (session, s2, s3):
        s.close()
    print("\nRuntime behaving as specified. Run scripts/eval_demo.py for the "
          "section 11 and 2.4 gates.\n")


if __name__ == "__main__":
    main()
