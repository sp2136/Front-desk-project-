"""Run the whole thing on one port, with a browser UI.

    python scripts/sandbox.py          # then open http://localhost:8000/sandbox

Starts the API, the queue worker and the reminder scheduler in one process.
That is a demo convenience and not how to deploy it: in production the worker
is a separate process so it can be scaled, restarted and drained on its own.

By default it runs on LLM_PROVIDER=stub -- rules, not a model, so there is
something to click without an API key. Set ANTHROPIC_API_KEY and pass
--provider anthropic to use the real thing, but run the evals first.
"""
from __future__ import annotations

import argparse
import os
import pathlib
import sys
import threading
import time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

ROOT = pathlib.Path(__file__).resolve().parents[1]


def main() -> int:
    ap = argparse.ArgumentParser(description="Run the sandbox UI")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--provider", default="stub",
                    choices=["stub", "anthropic", "null"])
    ap.add_argument("--db", default=str(ROOT / "sandbox.db"))
    ap.add_argument("--fresh", action="store_true", help="delete the database first")
    ap.add_argument("--no-open", action="store_true",
                    help="do not open browser tabs on start")
    args = ap.parse_args()

    if args.fresh:
        for suffix in ("", "-wal", "-shm"):
            pathlib.Path(args.db + suffix).unlink(missing_ok=True)

    os.environ["SANDBOX"] = "1"
    os.environ["DATABASE_URL"] = f"sqlite:///{args.db}"
    os.environ["LLM_PROVIDER"] = args.provider
    if args.provider == "anthropic" and not os.getenv("ANTHROPIC_API_KEY"):
        print("ANTHROPIC_API_KEY is not set.")
        return 1

    import uvicorn

    from app.db import init_db, reset_schema, schema_drift
    from app.main import app
    from app.runtime.llm import get_provider
    from app.runtime.pipeline import Pipeline
    from app.workers.runner import run_once, tick_reminders

    init_db()

    # An existing sandbox.db from an older version of the code opens fine and
    # then 500s on the first query touching a new column -- which presents as
    # "the page will not load". The sandbox holds demo data only, so the right
    # response is to rebuild it and say so, rather than to serve a broken UI.
    drift = schema_drift()
    if drift:
        print()
        print("  The existing database is behind the code:")
        for item in drift[:6]:
            print(f"    - {item}")
        if len(drift) > 6:
            print(f"    ... and {len(drift) - 6} more")
        print("  Rebuilding it (demo data only; your tenants are re-seeded).")
        print()
        reset_schema()

    stop = threading.Event()

    def worker() -> None:
        pipeline = Pipeline(get_provider())
        last_tick = 0.0
        while not stop.is_set():
            try:
                if time.monotonic() - last_tick > 20:
                    tick_reminders("sandbox")
                    last_tick = time.monotonic()
                if not run_once("sandbox-worker", pipeline):
                    time.sleep(0.25)
            except Exception as exc:  # noqa: BLE001 - never kill the demo
                print(f"  worker error: {type(exc).__name__}: {exc}")
                time.sleep(1)

    threading.Thread(target=worker, daemon=True).start()

    url = f"http://localhost:{args.port}/"
    print()
    print("=" * 68)
    print("  Sandbox running")
    print("=" * 68)
    print(f"  Open:     {url}")
    print(f"    sandbox  http://localhost:{args.port}/sandbox")
    print(f"    operator http://localhost:{args.port}/ops")
    print(f"    owner    http://localhost:{args.port}/owner")
    print(f"    api docs http://localhost:{args.port}/docs")
    print(f"  Model:    {args.provider}", end="")
    if args.provider == "stub":
        print("  (rules, not a model -- see app/runtime/stub_provider.py)")
    else:
        print()
    print(f"  Database: {args.db}")
    print()
    print("  Ctrl-C to stop.")
    print()

    if not args.no_open:
        # All three views at once, which is the only way to see cause and
        # effect: a message in the sandbox moves both dashboards.
        def _open() -> None:
            import webbrowser
            time.sleep(1.5)
            for path in ("/sandbox", "/ops", "/owner"):
                try:
                    webbrowser.open_new_tab(f"http://localhost:{args.port}{path}")
                    time.sleep(0.4)
                except Exception:  # noqa: BLE001 - headless is fine, links printed above
                    return

        threading.Thread(target=_open, daemon=True).start()

    try:
        uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning")
    finally:
        stop.set()
    return 0


if __name__ == "__main__":
    sys.exit(main())
