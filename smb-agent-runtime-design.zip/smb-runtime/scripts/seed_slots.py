"""Generate resources and open slots for a tenant, so A3 has availability to read.

    python scripts/seed_slots.py [tenant_id] [days]

Real deployments populate `slots` from the clinic's own calendar. This exists
so the demo and a first manual run have something to propose.
"""
from __future__ import annotations

import pathlib
import sys
from datetime import UTC, datetime, timedelta
from zoneinfo import ZoneInfo

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from app.db import SessionLocal, TenantScope, init_db  # noqa: E402
from app.models import Resource, Slot  # noqa: E402

RESOURCES = [
    ("r_shah", "Dr Shah", ["svc_consult", "svc_cleaning", "svc_filling", "svc_rct"]),
    ("r_mehta", "Dr Mehta", ["svc_consult", "svc_cleaning", "svc_whitening"]),
]
OPEN_HOUR, CLOSE_HOUR, STEP_MIN = 10, 19, 45


def seed(tenant_id: str = "t_smile_dental", days: int = 10, tz: str = "Asia/Kolkata") -> int:
    init_db()
    session = SessionLocal()
    scope = TenantScope(session, tenant_id)
    zone = ZoneInfo(tz)
    today = datetime.now(zone).date()

    for rid, name, skills in RESOURCES:
        if session.get(Resource, rid) is None:
            scope.add(Resource(id=rid, name=name, skills=skills))
    session.flush()

    made = 0
    for day in range(1, days + 1):
        date = today + timedelta(days=day)
        if date.weekday() == 6:        # closed Sunday
            continue
        for rid, _, _skills in RESOURCES:
            # One slot per resource per time, service-agnostic: a practitioner
            # has one calendar. Which services can fill it is decided by the
            # resource's skills at availability time.
            hour, minute = OPEN_HOUR, 0
            while hour < CLOSE_HOUR:
                local = datetime(date.year, date.month, date.day, hour, minute,
                                 tzinfo=zone)
                slot_id = f"{rid}:{local.isoformat()}"
                if scope.one_or_none(Slot, Slot.id == slot_id) is None:
                    scope.add(Slot(
                        id=slot_id, resource_id=rid, service_id=None,
                        starts_at=local.astimezone(UTC),
                        duration_min=STEP_MIN,
                    ))
                    made += 1
                minute += STEP_MIN
                hour, minute = hour + minute // 60, minute % 60
    session.commit()
    session.close()
    return made


if __name__ == "__main__":
    tid = sys.argv[1] if len(sys.argv) > 1 else "t_smile_dental"
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    print(f"created {seed(tid, n)} slot(s) for {tid}")
