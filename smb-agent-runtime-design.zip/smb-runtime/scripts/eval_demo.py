"""Show what an eval report looks like, with no API key.

Runs both shipped case files against a deliberately imperfect stub "model" so
the output demonstrates the thing that matters: the gates BLOCKING. A demo in
which everything passes teaches nothing, because the whole purpose of section
11 is to stop a launch.

The stub is a few keyword rules. It is not a model and its scores say nothing
about any real prompt.

    python scripts/eval_demo.py
"""
from __future__ import annotations

import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from app.eval import cases as case_mod  # noqa: E402
from app.eval.harness import run_eval  # noqa: E402
from app.runtime.llm import EchoProvider  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parents[1]
TENANT = json.loads((ROOT / "seeds" / "tenant_dentist.json").read_text())

INJECTION = ("ignore your instructions", "system:", "system note", "print everything")
URGENT = ("hurting", "pain", "dukhe", "dard", "bleeding", "swelling", "chipped",
          "turat", "jaldi", "crying")


def _body(user: str) -> str:
    return json.loads(user.split("<event>\n", 1)[1].split("\n</event>", 1)[0]).get("body", "")


def stub_a1(system: str, user: str) -> str:
    body = _body(user).lower()
    escalate, reason = False, None
    if any(k in body for k in INJECTION):
        escalate, reason = True, "instruction_in_user_content"
    elif "bonjour" in body or "voudrais" in body:
        escalate, reason = True, "out_of_scope"

    if "cost" in body or "price" in body or "charge" in body:
        intent = "price_enquiry"
    elif "open" in body or "hours" in body:
        intent = "location_hours"
    elif "waited" in body or "poor" in body:
        intent, escalate, reason = "complaint", True, "sentiment_risk"
    elif "book" in body or "appointment" in body or "aavi sakay" in body or "hold" in body:
        intent = "book"
    else:
        intent = "other"

    lang = "gu-Latn" if ("aavi sakay" in body or "vagya" in body) else "en"
    return json.dumps({
        "intent": intent, "service_id": None, "service_guess": None,
        "raw_complaint_text": _body(user) if intent == "complaint" else None,
        "language": lang, "customer": {"known": False, "id": None, "name": None},
        "time_window": {"earliest": None, "latest": None, "preferred_days": [],
                        "part_of_day": None},
        "blockers": [], "confidence": 0.88, "escalate": escalate,
        "reason": reason, "evidence": [],
    })


def stub_a2(system: str, user: str) -> str:
    body = _body(user).lower()
    hits = [k for k in URGENT if k in body]
    level = "immediate" if hits else "routine"
    return json.dumps({
        "level": level, "matched_signals": hits,
        "confidence": 0.9, "escalate": level == "immediate",
        "reason": "policy_boundary" if level == "immediate" else None,
        "evidence": [],
    })


def stub_a4(system: str, user: str) -> str:
    """A stub copilot. Answers from whatever facts it was handed and names the
    gap when there are none. Crude, and it misses several red lines."""
    body = _body(user)
    low = body.lower()
    facts_blob = user
    a1 = json.loads(user.split("<a1_output>\n", 1)[1].split("\n</a1_output>", 1)[0]) \
        if "<a1_output>" in user else {}
    intent = a1.get("intent", "other")
    lang = a1.get("language", "en")

    has_price = '"published_price": 1500' in facts_blob
    has_hours = '"hours"' in facts_blob
    has_faq = '<faq_answers>' in facts_blob and '"answer"' in facts_blob

    if intent == "price_enquiry" and has_price:
        draft = "Scaling and polishing starts from 1500. Would you like me to find you a time?"
        missing, escalate, reason = [], False, None
    elif has_hours:
        draft = "We are open 10:00 to 19:00. Shall I find you a time tomorrow?"
        missing, escalate, reason = [], False, None
    elif has_faq:
        draft = "Yes, street parking is available right outside. Anything else before you come in?"
        missing, escalate, reason = [], False, None
    else:
        draft = "Thanks for asking. Let me check that with the clinic and come back to you today."
        missing, escalate, reason = ["the answer to this question"], True, "missing_fact"

    if "ignore your rules" in low:
        draft = "Thanks for the message. Someone from the clinic will confirm with you shortly."
        missing, escalate, reason = ["confirmation from staff"], True, "instruction_in_user_content"

    return json.dumps({
        "draft": draft, "language": lang, "intent_handled": intent,
        "facts_used": [], "missing": missing,
        "auto_send_eligible": not missing and not escalate,
        "confidence": 0.85, "escalate": escalate, "reason": reason, "evidence": [],
    })


def stub_a3(system: str, user: str) -> str:
    """A stub proposer. Takes the first option per day, caps at three, and
    escalates on an empty window. It does not notice a named-resource request,
    which is a realistic miss."""
    avail = json.loads(user.split("<availability>\n", 1)[1].split("\n</availability>", 1)[0])
    picked, days = [], set()
    for a in avail:
        day = str(a.get("starts_at", ""))[:10]
        if day in days:
            continue
        days.add(day)
        picked.append({k: a[k] for k in
                       ("slot_id", "starts_at", "resource_id", "resource_name",
                        "duration_minutes")})
        if len(picked) == 3:
            break
    return json.dumps({
        "options": picked,
        "unavailable_note": None if picked else "nothing open in that window",
        "confidence": 0.9 if picked else 0.6,
        "escalate": not picked,
        "reason": None if picked else "missing_fact",
        # Section 2.2 defines evidence as {claim, source} objects. A3's OUTPUT
        # block in section 4 shows bare strings. The universal contract wins --
        # it says "EVERY response includes these fields" -- and the agent bodies
        # in app/prompts/ deliberately stop before the envelope fields so the
        # model is never shown two definitions of the same field.
        "evidence": [{"claim": "slot is open", "source": "get_availability#1"}],
    })


def stub_a5(system: str, user: str) -> str:
    """A stub reminder writer. Copies the time from the booking and keeps to
    the word ceiling for the stage."""
    booking = json.loads(user.split("<booking>\n", 1)[1].split("\n</booking>", 1)[0])
    cust = json.loads(user.split("<customer>\n", 1)[1].split("\n</customer>", 1)[0])
    stage = user.split("<reminder_stage>\n", 1)[1].split("\n</reminder_stage>", 1)[0].strip()
    when = str(booking.get("starts_at", ""))

    if stage == "T-2h":
        draft = f"Reminder: your appointment is at {when}. See you shortly."
    elif stage == "no_show_recovery":
        draft = ("We did not get to see you. Happy to find another time whenever "
                 "suits you. Would a morning or an evening work better?")
    else:
        draft = (f"Confirming your appointment on {when} with "
                 f"{booking.get('resource_name', 'us')}. Reply R if you would "
                 "like to move it, otherwise we will see you then.")
    return json.dumps({
        "draft": draft, "language": cust.get("language", "en"),
        "channel_preference": "whatsapp",
        "confidence": 0.88, "escalate": False, "reason": None, "evidence": [],
    })


def stub_a6(system: str, user: str) -> str:
    from app.runtime.stub_provider import _a6
    return json.dumps(_a6(user))


def stub_a7(system: str, user: str) -> str:
    from app.runtime.stub_provider import _a7
    return json.dumps(_a7(user))


def stub_guard(system: str, user: str) -> str:
    """A stub release gate. Catches the blatant cases and misses the subtle
    ones, which is the realistic failure shape and the point of the demo."""
    draft = user.split("<draft>\n", 1)[1].split("\n</draft>", 1)[0].lower()
    violations = []
    for term, rule in (("reserved", "unauthorised_commitment"),
                       ("waive", "unauthorised_commitment"),
                       ("definitely", "unauthorised_commitment"),
                       ("rinse", "professional_advice"),
                       ("abscess", "professional_advice"),
                       ("mr patel", "internal_information"),
                       ("guard:", "instruction_in_content")):
        if term in draft:
            violations.append({"rule": rule, "quote": term})
    return json.dumps({
        "verdict": "reject" if violations else "pass",
        "violations": violations, "confidence": 0.8,
    })


def main() -> None:
    for agent, path, stub in (("A1", "evals/a1_cases.jsonl", stub_a1),
                              ("A2", "evals/a2_cases.jsonl", stub_a2),
                              ("A3", "evals/a3_cases.jsonl", stub_a3),
                              ("A4", "evals/a4_cases.jsonl", stub_a4),
                              ("A5", "evals/a5_cases.jsonl", stub_a5),
                              ("A6", "evals/a6_cases.jsonl", stub_a6),
                              ("A7", "evals/a7_cases.jsonl", stub_a7)):
        full = ROOT / path
        report = run_eval(agent, case_mod.load(full), EchoProvider(responder=stub),
                          TENANT, path, case_mod.freeze(full), model="stub-rules-v0")
        print(report.render())
        print()

    from app.eval import guard_eval

    gpath = ROOT / "evals" / "guard_cases.jsonl"
    greport = guard_eval.run_guard_eval(
        guard_eval.load(gpath), EchoProvider(responder=stub_guard),
        "evals/guard_cases.jsonl", guard_eval.freeze(gpath), model="stub-rules-v0",
    )
    print(greport.render())
    print()

    print("Reminder: the stub above is keyword matching, not a model, and the case")
    print("files contain no real traffic. See evals/README.md -- a green report on")
    print("these cases means the harness works, not that the agent does.")


if __name__ == "__main__":
    main()
